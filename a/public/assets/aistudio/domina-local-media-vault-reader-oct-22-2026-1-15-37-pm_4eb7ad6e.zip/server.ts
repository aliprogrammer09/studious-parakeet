import express from 'express';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { createServer as createViteServer } from 'vite';
import {
  AppearanceConfig,
  DirectoryConfig,
  MediaItem,
  MediaPageItem,
  MediaType,
} from './src/types/media';
import {
  DEFAULT_APPEARANCE,
  DEFAULT_DIRECTORIES,
} from './src/data/seedLibrary';
import { parseImageDimensionsFromBuffer } from './src/utils/imageHeaderParser';

const PORT = 3000;
const WORKSPACE_ROOT = process.cwd();
const VAULT_ROOT = path.join(WORKSPACE_ROOT, 'vault');
const DB_FILE_PATH = path.join(VAULT_ROOT, 'domina-db.json');

const IMAGE_EXTENSIONS = new Set([
  '.png',
  '.jpg',
  '.jpeg',
  '.webp',
  '.gif',
  '.avif',
  '.bmp',
  '.svg',
]);

const VIDEO_EXTENSIONS = new Set([
  '.mp4',
  '.webm',
  '.mkv',
  '.mov',
  '.avi',
  '.m4v',
  '.ogv',
]);

const MIME_MAP: Record<string, string> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.avif': 'image/avif',
  '.bmp': 'image/bmp',
  '.svg': 'image/svg+xml',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.mkv': 'video/x-matroska',
  '.mov': 'video/quicktime',
  '.avi': 'video/x-msvideo',
  '.m4v': 'video/mp4',
  '.ogv': 'video/ogg',
};

interface VaultDatabase {
  version: string;
  directories: DirectoryConfig;
  appearance: AppearanceConfig;
  mediaItems: MediaItem[];
}

function stableIdFromPath(type: string, filePath: string): string {
  const hash = crypto
    .createHash('sha1')
    .update(`${type}:${filePath}`)
    .digest('hex')
    .slice(0, 14);
  return `${type}-${hash}`;
}

async function ensureVaultStructure(): Promise<void> {
  await fsp.mkdir(path.join(VAULT_ROOT, 'images'), { recursive: true });
  await fsp.mkdir(path.join(VAULT_ROOT, 'videos'), { recursive: true });
  await fsp.mkdir(path.join(VAULT_ROOT, 'comics'), { recursive: true });
  await fsp.mkdir(path.join(VAULT_ROOT, 'imagesets'), { recursive: true });
}

async function loadDatabase(): Promise<VaultDatabase> {
  await ensureVaultStructure();
  try {
    const raw = await fsp.readFile(DB_FILE_PATH, 'utf-8');
    const parsed = JSON.parse(raw) as Partial<VaultDatabase>;
    return {
      version: '2.0.0',
      directories: { ...DEFAULT_DIRECTORIES, ...(parsed.directories || {}) },
      appearance: { ...DEFAULT_APPEARANCE, ...(parsed.appearance || {}) },
      mediaItems: Array.isArray(parsed.mediaItems) ? parsed.mediaItems : [],
    };
  } catch {
    const initial: VaultDatabase = {
      version: '2.0.0',
      directories: { ...DEFAULT_DIRECTORIES },
      appearance: { ...DEFAULT_APPEARANCE },
      mediaItems: [],
    };
    await saveDatabase(initial);
    return initial;
  }
}

async function saveDatabase(db: VaultDatabase): Promise<void> {
  await ensureVaultStructure();
  await fsp.writeFile(DB_FILE_PATH, JSON.stringify(db, null, 2), 'utf-8');
}

async function readImageDimensions(
  filePath: string
): Promise<{ width: number; height: number }> {
  try {
    const handle = await fsp.open(filePath, 'r');
    try {
      const buffer = Buffer.alloc(65536);
      const { bytesRead } = await handle.read(buffer, 0, 65536, 0);
      const dims = parseImageDimensionsFromBuffer(
        new Uint8Array(buffer.buffer, buffer.byteOffset, bytesRead)
      );
      if (dims) return dims;
    } finally {
      await handle.close();
    }
  } catch {
    // ignore read error
  }
  return { width: 1920, height: 1080 };
}

async function walkFilesRecursive(dirPath: string): Promise<string[]> {
  const results: string[] = [];
  try {
    const entries = await fsp.readdir(dirPath, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.name.startsWith('.')) continue;
      const fullPath = path.join(dirPath, entry.name);
      if (entry.isDirectory()) {
        const nested = await walkFilesRecursive(fullPath);
        results.push(...nested);
      } else if (entry.isFile()) {
        results.push(fullPath);
      }
    }
  } catch {
    // Directory might not exist or be inaccessible
  }
  return results;
}

function buildFileApiUrl(filePath: string): string {
  return `/api/file?path=${encodeURIComponent(filePath)}`;
}

function sanitizeTagsFromPath(rootDir: string, filePath: string, defaultTag: string): string[] {
  const rel = path.relative(rootDir, path.dirname(filePath));
  const tags = new Set<string>([defaultTag]);
  if (rel && rel !== '.' && !rel.startsWith('..')) {
    for (const segment of rel.split(path.sep)) {
      const cleaned = segment
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9-_]+/g, '-')
        .replace(/^-+|-+$/g, '');
      if (cleaned) tags.add(cleaned);
    }
  }
  return Array.from(tags);
}

/**
 * Scans Comics or Image Sets directory:
 * Each subfolder inside the selected directory represents a comic or image set.
 * The folder name acts as the Comic/Set title, and its contents are the ordered image pages.
 */
async function scanCollectionDirectory(
  rootDir: string,
  collectionType: 'comic' | 'imageset',
  existingByPath: Map<string, MediaItem>
): Promise<MediaItem[]> {
  const results: MediaItem[] = [];
  try {
    const stat = await fsp.stat(rootDir);
    if (!stat.isDirectory()) return results;
  } catch {
    return results;
  }

  // Find all subfolders (immediate or nested) that contain image files
  const folderToImages = new Map<string, string[]>();
  const allFiles = await walkFilesRecursive(rootDir);

  for (const filePath of allFiles) {
    const ext = path.extname(filePath).toLowerCase();
    if (!IMAGE_EXTENSIONS.has(ext)) continue;
    const parentDir = path.dirname(filePath);
    // Only treat subfolders inside rootDir (or rootDir itself if user placed files directly)
    if (!folderToImages.has(parentDir)) {
      folderToImages.set(parentDir, []);
    }
    folderToImages.get(parentDir)!.push(filePath);
  }

  for (const [folderPath, imageFiles] of folderToImages.entries()) {
    // Natural sort files so page_1, page_2, ..., page_10 order properly
    const sortedFiles = [...imageFiles].sort((a, b) =>
      path.basename(a).localeCompare(path.basename(b), undefined, {
        numeric: true,
        sensitivity: 'base',
      })
    );
    if (sortedFiles.length === 0) continue;

    const folderName =
      folderPath === rootDir
        ? path.basename(rootDir)
        : path.basename(folderPath);
    const itemId = stableIdFromPath(collectionType, folderPath);
    const existing = existingByPath.get(folderPath);

    const pages: MediaPageItem[] = [];
    let totalBytes = 0;
    let latestMtime = new Date(0);

    for (let i = 0; i < sortedFiles.length; i++) {
      const imgPath = sortedFiles[i];
      let sizeBytes = 0;
      try {
        const st = await fsp.stat(imgPath);
        sizeBytes = st.size;
        if (st.mtime > latestMtime) latestMtime = st.mtime;
      } catch {
        // ignore
      }
      totalBytes += sizeBytes;
      const dims = await readImageDimensions(imgPath);
      const ext = path.extname(imgPath).replace('.', '').toUpperCase() || 'IMG';
      const url = buildFileApiUrl(imgPath);
      const fname = path.basename(imgPath);
      const existingPage = existing?.pages?.find(
        (p) => p.filename === fname || p.pageNumber === i + 1
      );

      pages.push({
        id: `${itemId}-page-${i + 1}`,
        pageNumber: i + 1,
        title: `Page ${String(i + 1).padStart(2, '0')}`,
        filename: fname,
        localPath: imgPath,
        url,
        width: dims.width,
        height: dims.height,
        sizeBytes,
        format: ext,
        rating: existingPage?.rating ?? 0,
        isFavorite: existingPage?.isFavorite ?? false,
        tags: existingPage?.tags ?? [],
        notes: existingPage?.notes ?? '',
      });
    }

    const firstPage = pages[0];
    const defaultTags = sanitizeTagsFromPath(
      rootDir,
      sortedFiles[0],
      collectionType === 'comic' ? 'comic' : 'imageset'
    );

    results.push({
      id: existing?.id || itemId,
      type: collectionType,
      title: existing?.title || folderName.replace(/[-_]+/g, ' '),
      filename: folderName,
      localPath: folderPath,
      folderPath: path.dirname(folderPath),
      thumbnailUrl: firstPage.url,
      mediaUrl: firstPage.url,
      rating: existing?.rating ?? 0,
      isFavorite: existing?.isFavorite ?? false,
      notes: existing?.notes,
      tags: existing && existing.tags.length > 0 ? existing.tags : defaultTags,
      dateAdded:
        existing?.dateAdded ||
        (latestMtime.getTime() > 0
          ? latestMtime.toISOString()
          : new Date().toISOString()),
      sizeBytes: totalBytes,
      format: 'FOLDER',
      width: firstPage.width,
      height: firstPage.height,
      pages,
      pageCount: pages.length,
      lastReadPage:
        collectionType === 'comic'
          ? existing?.lastReadPage
            ? Math.min(pages.length, Math.max(1, existing.lastReadPage))
            : 1
          : undefined,
      readPages:
        collectionType === 'comic'
          ? Array.isArray(existing?.readPages)
            ? existing.readPages.filter((p) => p >= 1 && p <= pages.length)
            : []
          : undefined,
      lastReadAt: collectionType === 'comic' ? existing?.lastReadAt : undefined,
      artist: existing?.artist,
      series: existing?.series,
    });
  }

  return results;
}

/**
 * Full filesystem scan across all 4 configured directories.
 */
async function scanFilesystemLibrary(
  directories: DirectoryConfig,
  existingItems: MediaItem[]
): Promise<MediaItem[]> {
  const existingByPath = new Map<string, MediaItem>();
  for (const item of existingItems) {
    existingByPath.set(item.localPath, item);
  }

  const nextItems: MediaItem[] = [];

  // 1. Scan Single Images (recursive)
  const imageFiles = await walkFilesRecursive(directories.imagesPath);
  for (const filePath of imageFiles) {
    const ext = path.extname(filePath).toLowerCase();
    if (!IMAGE_EXTENSIONS.has(ext)) continue;

    let sizeBytes = 0;
    let mtimeIso = new Date().toISOString();
    try {
      const st = await fsp.stat(filePath);
      sizeBytes = st.size;
      mtimeIso = st.mtime.toISOString();
    } catch {
      continue;
    }

    const dims = await readImageDimensions(filePath);
    const existing = existingByPath.get(filePath);
    const filename = path.basename(filePath);
    const cleanTitle = path
      .basename(filePath, ext)
      .replace(/[-_]+/g, ' ')
      .trim();
    const url = buildFileApiUrl(filePath);
    const defaultTags = sanitizeTagsFromPath(
      directories.imagesPath,
      filePath,
      'image'
    );

    nextItems.push({
      id: existing?.id || stableIdFromPath('image', filePath),
      type: 'image',
      title: existing?.title || cleanTitle || filename,
      filename,
      localPath: filePath,
      folderPath: path.dirname(filePath),
      thumbnailUrl: url,
      mediaUrl: url,
      rating: existing?.rating ?? 0,
      isFavorite: existing?.isFavorite ?? false,
      notes: existing?.notes,
      tags: existing && existing.tags.length > 0 ? existing.tags : defaultTags,
      dateAdded: existing?.dateAdded || mtimeIso,
      sizeBytes,
      format: ext.replace('.', '').toUpperCase() || 'IMG',
      width: dims.width,
      height: dims.height,
      artist: existing?.artist,
    });
  }

  // 2. Scan Single Videos (recursive)
  const videoFiles = await walkFilesRecursive(directories.videosPath);
  for (const filePath of videoFiles) {
    const ext = path.extname(filePath).toLowerCase();
    if (!VIDEO_EXTENSIONS.has(ext)) continue;

    let sizeBytes = 0;
    let mtimeIso = new Date().toISOString();
    try {
      const st = await fsp.stat(filePath);
      sizeBytes = st.size;
      mtimeIso = st.mtime.toISOString();
    } catch {
      continue;
    }

    const existing = existingByPath.get(filePath);
    const filename = path.basename(filePath);
    const cleanTitle = path
      .basename(filePath, ext)
      .replace(/[-_]+/g, ' ')
      .trim();
    const url = buildFileApiUrl(filePath);
    const defaultTags = sanitizeTagsFromPath(
      directories.videosPath,
      filePath,
      'video'
    );

    nextItems.push({
      id: existing?.id || stableIdFromPath('video', filePath),
      type: 'video',
      title: existing?.title || cleanTitle || filename,
      filename,
      localPath: filePath,
      folderPath: path.dirname(filePath),
      thumbnailUrl: existing?.thumbnailUrl || '',
      mediaUrl: url,
      rating: existing?.rating ?? 0,
      isFavorite: existing?.isFavorite ?? false,
      notes: existing?.notes,
      tags: existing && existing.tags.length > 0 ? existing.tags : defaultTags,
      dateAdded: existing?.dateAdded || mtimeIso,
      sizeBytes,
      format: ext.replace('.', '').toUpperCase() || 'VIDEO',
      width: existing?.width || 1920,
      height: existing?.height || 1080,
      durationSeconds: existing?.durationSeconds || 0,
      fps: existing?.fps || 60,
      codec: existing?.codec || ext.replace('.', '').toUpperCase(),
      artist: existing?.artist,
    });
  }

  // 3. Scan Comics (subfolder per comic)
  const comics = await scanCollectionDirectory(
    directories.comicsPath,
    'comic',
    existingByPath
  );
  nextItems.push(...comics);

  // 4. Scan Image Sets (subfolder per image set)
  const imageSets = await scanCollectionDirectory(
    directories.imageSetsPath,
    'imageset',
    existingByPath
  );
  nextItems.push(...imageSets);

  return nextItems;
}

async function startServer() {
  const app = express();

  // Initialize DB on startup
  let db = await loadDatabase();
  if (db.directories.autoScanOnStartup) {
    const scanned = await scanFilesystemLibrary(db.directories, db.mediaItems);
    db.mediaItems = scanned;
    db.directories.lastIndexedAt = new Date().toISOString();
    await saveDatabase(db);
  }

  // POST /api/upload-raw - Register BEFORE express.json() so binary bodies are parsed as Buffer
  app.post(
    '/api/upload-raw',
    express.raw({ type: () => true, limit: '500mb' }),
    async (req, res) => {
      try {
        const mediaType = String(
          req.query.type || req.query.category || 'image'
        ) as MediaType;
        const relativePath = String(req.query.relativePath || 'file.bin')
          .replace(/^[/\\]+/, '')
          .replace(/\.\./g, '');

        const baseDir =
          mediaType === 'video'
            ? db.directories.videosPath
            : mediaType === 'comic'
            ? db.directories.comicsPath
            : mediaType === 'imageset'
            ? db.directories.imageSetsPath
            : db.directories.imagesPath;

        let finalRelative = relativePath;
        if (
          (mediaType === 'comic' || mediaType === 'imageset') &&
          !relativePath.includes('/')
        ) {
          const collectionFolder = String(
            req.query.collectionName || 'Imported_Collection'
          ).replace(/[^a-zA-Z0-9-_ ]/g, '_');
          finalRelative = path.join(collectionFolder, relativePath);
        }

        const destPath = path.join(baseDir, finalRelative);
        await fsp.mkdir(path.dirname(destPath), { recursive: true });
        const dataBuffer = Buffer.isBuffer(req.body)
          ? req.body
          : Buffer.from(req.body || '');
        await fsp.writeFile(destPath, dataBuffer);

        res.json({ ok: true, savedPath: destPath });
      } catch (err) {
        res.status(500).json({
          ok: false,
          error: err instanceof Error ? err.message : 'Upload failed',
        });
      }
    }
  );

  app.use(express.json({ limit: '50mb' }));

  // GET /api/state - Return full persisted state
  app.get('/api/state', async (_req, res) => {
    res.json(db);
  });

  // POST /api/scan - Rescan local directories on disk
  app.post('/api/scan', async (req, res) => {
    try {
      if (req.body && req.body.directories) {
        db.directories = { ...db.directories, ...req.body.directories };
      }
      const scanned = await scanFilesystemLibrary(
        db.directories,
        db.mediaItems
      );
      db.mediaItems = scanned;
      db.directories.lastIndexedAt = new Date().toISOString();
      await saveDatabase(db);
      res.json({
        ok: true,
        mediaItems: db.mediaItems,
        directories: db.directories,
        totalCount: db.mediaItems.length,
      });
    } catch (err) {
      res.status(500).json({
        ok: false,
        error: err instanceof Error ? err.message : 'Scan failed',
      });
    }
  });

  // GET /api/fs/browse?dir=... - Browse real directories on the machine
  app.get('/api/fs/browse', async (req, res) => {
    const rawDir = String(req.query.dir || WORKSPACE_ROOT);
    const resolvedDir = path.resolve(rawDir);
    try {
      const entries = await fsp.readdir(resolvedDir, { withFileTypes: true });
      const subdirectories: Array<{ name: string; path: string }> = [];
      let imageCount = 0;
      let videoCount = 0;

      for (const entry of entries) {
        if (entry.name.startsWith('.')) continue;
        const full = path.join(resolvedDir, entry.name);
        if (entry.isDirectory()) {
          subdirectories.push({ name: entry.name, path: full });
        } else if (entry.isFile()) {
          const ext = path.extname(entry.name).toLowerCase();
          if (IMAGE_EXTENSIONS.has(ext)) imageCount += 1;
          if (VIDEO_EXTENSIONS.has(ext)) videoCount += 1;
        }
      }

      subdirectories.sort((a, b) =>
        a.name.localeCompare(b.name, undefined, { numeric: true })
      );

      res.json({
        currentPath: resolvedDir,
        parentPath: path.dirname(resolvedDir),
        subdirectories,
        imageCount,
        videoCount,
      });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'Cannot read directory',
        currentPath: resolvedDir,
        parentPath: path.dirname(resolvedDir),
        subdirectories: [],
        imageCount: 0,
        videoCount: 0,
      });
    }
  });

  // POST /api/fs/mkdir - Create a directory on disk
  app.post('/api/fs/mkdir', async (req, res) => {
    const targetPath = path.resolve(String(req.body?.path || ''));
    try {
      await fsp.mkdir(targetPath, { recursive: true });
      res.json({ ok: true, path: targetPath });
    } catch (err) {
      res.status(400).json({
        ok: false,
        error: err instanceof Error ? err.message : 'Failed to create folder',
      });
    }
  });

  // GET /api/file?path=... - Stream local media file with HTTP Range (206) support
  app.get('/api/file', async (req, res) => {
    const filePath = String(req.query.path || '');
    if (!filePath) {
      res.status(400).send('Missing path query parameter');
      return;
    }

    try {
      const stat = await fsp.stat(filePath);
      if (!stat.isFile()) {
        res.status(404).send('Not a file');
        return;
      }

      const ext = path.extname(filePath).toLowerCase();
      const contentType = MIME_MAP[ext] || 'application/octet-stream';
      const fileSize = stat.size;
      const range = req.headers.range;

      if (range) {
        const parts = range.replace(/bytes=/, '').split('-');
        const start = parseInt(parts[0], 10);
        const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
        if (start >= fileSize || end >= fileSize) {
          res.status(416).header('Content-Range', `bytes */${fileSize}`).end();
          return;
        }
        const chunksize = end - start + 1;
        res.writeHead(206, {
          'Content-Range': `bytes ${start}-${end}/${fileSize}`,
          'Accept-Ranges': 'bytes',
          'Content-Length': chunksize,
          'Content-Type': contentType,
          'Cache-Control': 'public, max-age=3600',
        });
        fs.createReadStream(filePath, { start, end }).pipe(res);
      } else {
        res.writeHead(200, {
          'Content-Length': fileSize,
          'Content-Type': contentType,
          'Accept-Ranges': 'bytes',
          'Cache-Control': 'public, max-age=3600',
        });
        fs.createReadStream(filePath).pipe(res);
      }
    } catch {
      res.status(404).send('File not found');
    }
  });

  // PATCH /api/media/:id - Update rating, tags, bookmark, or probed dimensions/duration
  app.patch('/api/media/:id', async (req, res) => {
    const { id } = req.params;
    const updates = req.body || {};
    let updatedItem: MediaItem | null = null;

    db.mediaItems = db.mediaItems.map((item) => {
      if (item.id !== id) return item;
      updatedItem = {
        ...item,
        ...(typeof updates.rating === 'number' ? { rating: updates.rating } : {}),
        ...(typeof updates.isFavorite === 'boolean'
          ? { isFavorite: updates.isFavorite }
          : {}),
        ...(typeof updates.notes === 'string' ? { notes: updates.notes } : {}),
        ...(typeof updates.artist === 'string' ? { artist: updates.artist } : {}),
        ...(typeof updates.series === 'string' ? { series: updates.series } : {}),
        ...(Array.isArray(updates.tags) ? { tags: updates.tags } : {}),
        ...(typeof updates.lastReadPage === 'number'
          ? {
              lastReadPage: updates.lastReadPage,
              lastReadAt: new Date().toISOString(),
            }
          : {}),
        ...(Array.isArray(updates.readPages)
          ? {
              readPages: Array.from(
                new Set(
                  updates.readPages.filter(
                    (p: unknown): p is number =>
                      typeof p === 'number' && Number.isInteger(p) && p >= 1
                  )
                )
              ).sort((a, b) => a - b),
            }
          : {}),
        ...(typeof updates.title === 'string' ? { title: updates.title } : {}),
        ...(typeof updates.durationSeconds === 'number'
          ? { durationSeconds: updates.durationSeconds }
          : {}),
        ...(typeof updates.width === 'number' ? { width: updates.width } : {}),
        ...(typeof updates.height === 'number' ? { height: updates.height } : {}),
        ...(typeof updates.thumbnailUrl === 'string'
          ? { thumbnailUrl: updates.thumbnailUrl }
          : {}),
        ...(Array.isArray(updates.pages) ? { pages: updates.pages } : {}),
      };
      return updatedItem;
    });

    if (!updatedItem) {
      res.status(404).json({ ok: false, error: 'Media item not found' });
      return;
    }

    await saveDatabase(db);
    res.json({ ok: true, item: updatedItem });
  });

  // PATCH /api/media/:id/page/:pageNumber - Rate or update an individual page inside a comic or image set
  app.patch('/api/media/:id/page/:pageNumber', async (req, res) => {
    const { id, pageNumber } = req.params;
    const pageNum = parseInt(pageNumber, 10);
    const updates = req.body || {};
    const item = db.mediaItems.find((i) => i.id === id);
    if (!item || !item.pages) {
      res.status(404).json({ ok: false, error: 'Collection not found' });
      return;
    }
    const targetPage = item.pages.find((p) => p.pageNumber === pageNum);
    if (!targetPage) {
      res.status(404).json({ ok: false, error: 'Page not found' });
      return;
    }
    if (typeof updates.rating === 'number') {
      targetPage.rating = updates.rating;
    }
    if (typeof updates.isFavorite === 'boolean') {
      targetPage.isFavorite = updates.isFavorite;
    }
    if (Array.isArray(updates.tags)) {
      targetPage.tags = updates.tags;
    }
    if (typeof updates.notes === 'string') {
      targetPage.notes = updates.notes;
    }
    await saveDatabase(db);
    res.json({ ok: true, page: targetPage, item });
  });

  // DELETE /api/media/:id - Remove item from vault (and optionally delete file on disk)
  app.delete('/api/media/:id', async (req, res) => {
    const { id } = req.params;
    const deleteFromDisk = req.query.deleteFromDisk === 'true';
    const target = db.mediaItems.find((i) => i.id === id);
    if (!target) {
      res.status(404).json({ ok: false, error: 'Item not found' });
      return;
    }

    if (deleteFromDisk && target.localPath.startsWith(VAULT_ROOT)) {
      try {
        await fsp.rm(target.localPath, { recursive: true, force: true });
      } catch {
        // ignore disk deletion errors
      }
    }

    db.mediaItems = db.mediaItems.filter((i) => i.id !== id);
    await saveDatabase(db);
    res.json({ ok: true });
  });

  // PUT /api/settings - Update directories and appearance settings
  app.put('/api/settings', async (req, res) => {
    if (req.body?.directories) {
      db.directories = { ...db.directories, ...req.body.directories };
    }
    if (req.body?.appearance) {
      db.appearance = { ...db.appearance, ...req.body.appearance };
    }
    await saveDatabase(db);
    res.json({
      ok: true,
      directories: db.directories,
      appearance: db.appearance,
    });
  });

  // POST /api/database/import - Restore database from JSON backup
  app.post('/api/database/import', async (req, res) => {
    try {
      const payload = req.body;
      if (!payload || !Array.isArray(payload.mediaItems)) {
        res.status(400).json({ ok: false, error: 'Invalid database JSON' });
        return;
      }
      db.mediaItems = payload.mediaItems;
      if (payload.directories) {
        db.directories = { ...db.directories, ...payload.directories };
      }
      if (payload.appearance) {
        db.appearance = { ...db.appearance, ...payload.appearance };
      }
      await saveDatabase(db);
      res.json({ ok: true, db });
    } catch (err) {
      res.status(400).json({
        ok: false,
        error: err instanceof Error ? err.message : 'Import failed',
      });
    }
  });

  // POST /api/database/clear - Clear all vault items and disk files in /vault
  app.post('/api/database/clear', async (_req, res) => {
    db.mediaItems = [];
    await saveDatabase(db);
    res.json({ ok: true, db });
  });

  // POST /api/open-in-explorer - Launch OS Explorer/Finder at local file path
  app.post('/api/open-in-explorer', async (req, res) => {
    const targetPath = String(req.body?.path || '');
    if (!targetPath) {
      res.status(400).json({ ok: false, error: 'Missing path' });
      return;
    }
    const dirToOpen = fs.existsSync(targetPath)
      ? fs.statSync(targetPath).isDirectory()
        ? targetPath
        : path.dirname(targetPath)
      : path.dirname(targetPath);

    const platform = process.platform;
    const cmd =
      platform === 'darwin'
        ? 'open'
        : platform === 'win32'
        ? 'explorer.exe'
        : 'xdg-open';

    execFile(cmd, [dirToOpen], () => {
      // Ignore error in headless container environments
    });

    res.json({
      ok: true,
      openedDirectory: dirToOpen,
      targetPath,
    });
  });

  // Mount Vite middleware in development or serve static dist in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
        watch:
          process.env.DISABLE_HMR === 'true'
            ? null
            : {
                ignored: [
                  '**/vault/**',
                  '**/domina-db.json',
                  '**/.playwright-cli/**',
                ],
              },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(WORKSPACE_ROOT, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Domina Local Media Vault Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
