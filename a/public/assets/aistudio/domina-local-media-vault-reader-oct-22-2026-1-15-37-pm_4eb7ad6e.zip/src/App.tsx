/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { FolderPlus, Lock, PowerOff, RefreshCw, Unlock } from 'lucide-react';
import {
  AppearanceConfig,
  DirectoryConfig,
  FilterState,
  MediaItem,
  MediaType,
  PageView,
} from './types/media';
import {
  DEFAULT_APPEARANCE,
  DEFAULT_DIRECTORIES,
} from './data/seedLibrary';
import { matchesSearchQuery } from './utils/mediaLogic';
import {
  deleteMediaItemOnServer,
  fetchVaultState,
  patchCollectionPageOnServer,
  patchMediaItemOnServer,
  saveSettingsOnServer,
  triggerServerScan,
  uploadFilesToVaultAndScan,
} from './utils/localMediaClient';
import { DashboardView } from './components/DashboardView';
import { FilterToolbar } from './components/FilterToolbar';
import { MediaCard } from './components/MediaCard';
import { ImageDetailsView } from './components/ImageDetailsView';
import { VideoDetailsView } from './components/VideoDetailsView';
import { CollectionOverviewView } from './components/CollectionOverviewView';
import { ReaderView } from './components/ReaderView';
import { SettingsView } from './components/SettingsView';
import { AdvancedSearchView } from './components/AdvancedSearchView';
import { QuickSearchModal } from './components/QuickSearchModal';

const DEFAULT_FILTER: FilterState = {
  searchQuery: '',
  tagExpression: '',
  includedTags: [],
  excludedTags: [],
  orTags: [],
  selectedRatings: [],
  selectedTypes: [],
  favoritesOnly: false,
  orientation: 'all',
  minResolution: 'all',
  durationRange: 'all',
  comicProgress: 'all',
  sortBy: 'dateAdded',
  sortOrder: 'desc',
};

const NAV_STORAGE_KEY = 'domina_active_nav_v1';

export default function App() {
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([]);
  const [directories, setDirectories] = useState<DirectoryConfig>(
    DEFAULT_DIRECTORIES
  );
  const [appearance, setAppearance] = useState<AppearanceConfig>(
    DEFAULT_APPEARANCE
  );
  const [isLoadingVault, setIsLoadingVault] = useState(true);
  const [isScanning, setIsScanning] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatusText, setUploadStatusText] = useState<string | null>(null);

  // Restore active navigation view from sessionStorage so any reload stays on the exact same view
  const [currentPage, setCurrentPage] = useState<PageView>(() => {
    try {
      const saved = sessionStorage.getItem(NAV_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.currentPage) return parsed.currentPage as PageView;
      }
    } catch {
      // ignore
    }
    return 'dashboard';
  });

  const [selectedItemId, setSelectedItemId] = useState<string | null>(() => {
    try {
      const saved = sessionStorage.getItem(NAV_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.selectedItemId || null;
      }
    } catch {
      // ignore
    }
    return null;
  });

  const [readerStartPage, setReaderStartPage] = useState<number>(() => {
    try {
      const saved = sessionStorage.getItem(NAV_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.readerStartPage || 1;
      }
    } catch {
      // ignore
    }
    return 1;
  });

  const [selectedCollectionPageNumber, setSelectedCollectionPageNumber] =
    useState<number | null>(() => {
      try {
        const saved = sessionStorage.getItem(NAV_STORAGE_KEY);
        if (saved) {
          const parsed = JSON.parse(saved);
          return parsed.selectedCollectionPageNumber || null;
        }
      } catch {
        // ignore
      }
      return null;
    });

  // History-aware navigation that syncs with browser history (Chrome Back / Forward buttons)
  const navigateTo = useCallback(
    (
      page: PageView,
      itemId: string | null = null,
      startPage = 1,
      collectionPageNum: number | null = null,
      pushHistory = true
    ) => {
      setCurrentPage(page);
      setSelectedItemId(itemId);
      setReaderStartPage(startPage);
      setSelectedCollectionPageNumber(collectionPageNum);

      if (pushHistory) {
        const stateObj = {
          page,
          itemId,
          startPage,
          collectionPageNum,
        };
        const hash = `#${page}${itemId ? `/${itemId}` : ''}${
          collectionPageNum ? `/page/${collectionPageNum}` : ''
        }`;
        try {
          window.history.pushState(stateObj, '', hash);
        } catch {
          // ignore
        }
      }
    },
    []
  );

  // Chrome Back & Forward Button Handling via popstate
  useEffect(() => {
    const handlePopState = (e: PopStateEvent) => {
      if (e.state && e.state.page) {
        setCurrentPage(e.state.page);
        setSelectedItemId(e.state.itemId || null);
        setReaderStartPage(e.state.startPage || 1);
        setSelectedCollectionPageNumber(e.state.collectionPageNum || null);
      } else {
        const rawHash = window.location.hash.replace(/^#/, '');
        if (rawHash) {
          const parts = rawHash.split('/');
          const targetPage = parts[0] as PageView;
          const targetItemId = parts[1] || null;
          const pageIdx = parts.indexOf('page');
          const targetCollectionPage =
            pageIdx !== -1 && parts[pageIdx + 1]
              ? parseInt(parts[pageIdx + 1], 10)
              : null;
          setCurrentPage(targetPage || 'dashboard');
          setSelectedItemId(targetItemId);
          setSelectedCollectionPageNumber(targetCollectionPage);
        } else {
          setCurrentPage('dashboard');
          setSelectedItemId(null);
          setSelectedCollectionPageNumber(null);
        }
      }
    };

    window.addEventListener('popstate', handlePopState);

    // Initial state setup so going back to initial entry works
    if (!window.history.state) {
      try {
        window.history.replaceState(
          {
            page: currentPage,
            itemId: selectedItemId,
            startPage: readerStartPage,
            collectionPageNum: selectedCollectionPageNumber,
          },
          '',
          window.location.hash || `#${currentPage}`
        );
      } catch {
        // ignore
      }
    }

    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Simple search bar state for the 4 gallery pages
  const [gallerySearchQuery, setGallerySearchQuery] = useState('');
  // Full filter state for the dedicated Advanced Search page
  const [advancedFilter, setAdvancedFilter] =
    useState<FilterState>(DEFAULT_FILTER);

  const [quickSearchOpen, setQuickSearchOpen] = useState(false);
  const [privacyScreenLocked, setPrivacyScreenLocked] = useState(false);
  const [panicClosed, setPanicClosed] = useState(false);

  // Persist current navigation view in sessionStorage
  useEffect(() => {
    try {
      sessionStorage.setItem(
        NAV_STORAGE_KEY,
        JSON.stringify({
          currentPage,
          selectedItemId,
          readerStartPage,
          selectedCollectionPageNumber,
        })
      );
    } catch {
      // ignore
    }
  }, [
    currentPage,
    selectedItemId,
    readerStartPage,
    selectedCollectionPageNumber,
  ]);

  // Apply live CSS theme, background darkness & glow intensity variables to root element
  useEffect(() => {
    const root = document.documentElement;
    const intensity = Math.max(0.2, Math.min(1, (appearance.accentIntensity || 95) / 100));
    root.style.setProperty('--accent-intensity', String(intensity));

    let defaultBg = '#080510';
    if (appearance.accentColor === 'amethyst') {
      root.style.setProperty('--domina-accent', '#c084fc');
      root.style.setProperty('--domina-accent-bright', '#e879f9');
      root.style.setProperty(
        '--domina-accent-soft',
        `rgba(192, 132, 252, ${(0.32 * intensity).toFixed(2)})`
      );
      root.style.setProperty(
        '--domina-accent-glow',
        `rgba(217, 70, 239, ${(0.55 * intensity).toFixed(2)})`
      );
      defaultBg = '#0b0415';
    } else if (appearance.accentColor === 'indigo') {
      root.style.setProperty('--domina-accent', '#6366f1');
      root.style.setProperty('--domina-accent-bright', '#818cf8');
      root.style.setProperty(
        '--domina-accent-soft',
        `rgba(99, 102, 241, ${(0.32 * intensity).toFixed(2)})`
      );
      root.style.setProperty(
        '--domina-accent-glow',
        `rgba(129, 140, 248, ${(0.55 * intensity).toFixed(2)})`
      );
      defaultBg = '#060613';
    } else if (appearance.accentColor === 'crimson') {
      root.style.setProperty('--domina-accent', '#e11d48');
      root.style.setProperty('--domina-accent-bright', '#a855f7');
      root.style.setProperty(
        '--domina-accent-soft',
        `rgba(225, 29, 72, ${(0.28 * intensity).toFixed(2)})`
      );
      root.style.setProperty(
        '--domina-accent-glow',
        `rgba(168, 85, 247, ${(0.5 * intensity).toFixed(2)})`
      );
      defaultBg = '#09040f';
    } else if (appearance.accentColor === 'emerald') {
      root.style.setProperty('--domina-accent', '#10b981');
      root.style.setProperty('--domina-accent-bright', '#34d399');
      root.style.setProperty(
        '--domina-accent-soft',
        `rgba(16, 185, 129, ${(0.28 * intensity).toFixed(2)})`
      );
      root.style.setProperty(
        '--domina-accent-glow',
        `rgba(52, 211, 153, ${(0.5 * intensity).toFixed(2)})`
      );
      defaultBg = '#040d0a';
    } else if (appearance.accentColor === 'amber') {
      root.style.setProperty('--domina-accent', '#f59e0b');
      root.style.setProperty('--domina-accent-bright', '#fbbf24');
      root.style.setProperty(
        '--domina-accent-soft',
        `rgba(245, 158, 11, ${(0.28 * intensity).toFixed(2)})`
      );
      root.style.setProperty(
        '--domina-accent-glow',
        `rgba(251, 191, 36, ${(0.5 * intensity).toFixed(2)})`
      );
      defaultBg = '#0d0904';
    } else if (appearance.accentColor === 'fuchsia') {
      root.style.setProperty('--domina-accent', '#d946ef');
      root.style.setProperty('--domina-accent-bright', '#f0abfc');
      root.style.setProperty(
        '--domina-accent-soft',
        `rgba(217, 70, 239, ${(0.32 * intensity).toFixed(2)})`
      );
      root.style.setProperty(
        '--domina-accent-glow',
        `rgba(240, 171, 252, ${(0.55 * intensity).toFixed(2)})`
      );
      defaultBg = '#0c0414';
    } else {
      // Default: Royal Violet
      root.style.setProperty('--domina-accent', '#8b5cf6');
      root.style.setProperty('--domina-accent-bright', '#a855f7');
      root.style.setProperty(
        '--domina-accent-soft',
        `rgba(139, 92, 246, ${(0.32 * intensity).toFixed(2)})`
      );
      root.style.setProperty(
        '--domina-accent-glow',
        `rgba(168, 85, 247, ${(0.55 * intensity).toFixed(2)})`
      );
      defaultBg = '#080510';
    }

    if (appearance.bgDarkness === 'pitch-black') {
      root.style.setProperty('--domina-bg', '#020105');
    } else if (appearance.bgDarkness === 'charcoal') {
      root.style.setProperty('--domina-bg', '#120d1d');
    } else {
      root.style.setProperty('--domina-bg', defaultBg);
    }
  }, [appearance.accentColor, appearance.accentIntensity, appearance.bgDarkness]);

  // Panic Close Handler (Ctrl+D or button click): closes this tab/page immediately
  const handlePanicClose = useCallback(() => {
    setPanicClosed(true);
    document.title = 'about:blank';
    try {
      window.open('', '_self');
      window.close();
    } catch {
      // ignore
    }
    try {
      window.location.replace('about:blank');
    } catch {
      // ignore
    }
  }, []);

  // Load initial state from the local Express backend
  useEffect(() => {
    fetchVaultState()
      .then((state) => {
        setMediaItems(state.mediaItems || []);
        if (state.directories) setDirectories(state.directories);
        if (state.appearance) {
          setAppearance({ ...DEFAULT_APPEARANCE, ...state.appearance });
        }
      })
      .catch(() => {
        // Fallback if server is warming up
      })
      .finally(() => {
        setIsLoadingVault(false);
      });
  }, []);

  // Global Hotkeys: Ctrl+D (Panic Close), Ctrl+K / Cmd+K (Quick Search), Shift+L (Privacy Lock Screen)
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'd') {
        e.preventDefault();
        e.stopPropagation();
        handlePanicClose();
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setQuickSearchOpen((v) => !v);
      } else if (
        e.shiftKey &&
        e.key.toLowerCase() === 'l' &&
        document.activeElement?.tagName !== 'INPUT' &&
        document.activeElement?.tagName !== 'TEXTAREA'
      ) {
        e.preventDefault();
        setPrivacyScreenLocked((v) => !v);
      }
    };
    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [handlePanicClose]);

  // All unique tags across the vault for auto-complete suggestions
  const allAvailableTags = useMemo(() => {
    const tagCounts = new Map<string, number>();
    for (const item of mediaItems) {
      for (const t of item.tags) {
        tagCounts.set(t, (tagCounts.get(t) || 0) + 1);
      }
    }
    return Array.from(tagCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .map(([tag]) => tag);
  }, [mediaItems]);

  // Inline 5-Star Rating Handler (persisted to server without changing currentPage)
  const handleRateItem = useCallback((id: string, rating: number) => {
    setMediaItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, rating } : item))
    );
    patchMediaItemOnServer(id, { rating }).catch(() => {});
  }, []);

  // Toggle Favorite Handler
  const handleToggleFavorite = useCallback((id: string, nextFav: boolean) => {
    setMediaItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, isFavorite: nextFav } : item
      )
    );
    patchMediaItemOnServer(id, { isFavorite: nextFav }).catch(() => {});
  }, []);

  // Individual Comic Page & Image Set Page Rating Handler
  const handleRateCollectionPage = useCallback(
    (collectionId: string, pageNumber: number, rating: number) => {
      setMediaItems((prev) =>
        prev.map((item) => {
          if (item.id !== collectionId || !item.pages) return item;
          const updatedPages = item.pages.map((p) =>
            p.pageNumber === pageNumber ? { ...p, rating } : p
          );
          return { ...item, pages: updatedPages };
        })
      );
      patchCollectionPageOnServer(collectionId, pageNumber, { rating }).catch(
        () => {}
      );
    },
    []
  );

  // Individual Comic Page & Image Set Page Favorite Handler
  const handleToggleFavoriteCollectionPage = useCallback(
    (collectionId: string, pageNumber: number, nextFav: boolean) => {
      setMediaItems((prev) =>
        prev.map((item) => {
          if (item.id !== collectionId || !item.pages) return item;
          const updatedPages = item.pages.map((p) =>
            p.pageNumber === pageNumber ? { ...p, isFavorite: nextFav } : p
          );
          return { ...item, pages: updatedPages };
        })
      );
      patchCollectionPageOnServer(collectionId, pageNumber, {
        isFavorite: nextFav,
      }).catch(() => {});
    },
    []
  );

  // Update Tags Handler
  const handleUpdateTags = useCallback((id: string, nextTags: string[]) => {
    setMediaItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, tags: nextTags } : item))
    );
    patchMediaItemOnServer(id, { tags: nextTags }).catch(() => {});
  }, []);

  // Update Notes Handler
  const handleUpdateNotes = useCallback((id: string, notes: string) => {
    setMediaItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, notes } : item))
    );
    patchMediaItemOnServer(id, { notes }).catch(() => {});
  }, []);

  // Individual Comic Page & Image Set Page Tags Handler
  const handleUpdateCollectionPageTags = useCallback(
    (collectionId: string, pageNumber: number, nextTags: string[]) => {
      setMediaItems((prev) =>
        prev.map((item) => {
          if (item.id !== collectionId || !item.pages) return item;
          const updatedPages = item.pages.map((p) =>
            p.pageNumber === pageNumber ? { ...p, tags: nextTags } : p
          );
          return { ...item, pages: updatedPages };
        })
      );
      patchCollectionPageOnServer(collectionId, pageNumber, {
        tags: nextTags,
      }).catch(() => {});
    },
    []
  );

  // Individual Comic Page & Image Set Page Notes Handler
  const handleUpdateCollectionPageNotes = useCallback(
    (collectionId: string, pageNumber: number, notes: string) => {
      setMediaItems((prev) =>
        prev.map((item) => {
          if (item.id !== collectionId || !item.pages) return item;
          const updatedPages = item.pages.map((p) =>
            p.pageNumber === pageNumber ? { ...p, notes } : p
          );
          return { ...item, pages: updatedPages };
        })
      );
      patchCollectionPageOnServer(collectionId, pageNumber, {
        notes,
      }).catch(() => {});
    },
    []
  );

  // Update Comic Bookmark & readPages Handler (Comics only)
  const handleUpdateBookmark = useCallback(
    (id: string, pageNumber: number, newlyReadPages: number[]) => {
      setMediaItems((prev) =>
        prev.map((item) => {
          if (item.id !== id || item.type !== 'comic') return item;
          const existingRead = Array.isArray(item.readPages)
            ? item.readPages
            : [];
          const mergedRead = Array.from(
            new Set([...existingRead, ...newlyReadPages])
          ).sort((a, b) => a - b);

          patchMediaItemOnServer(id, {
            lastReadPage: pageNumber,
            readPages: mergedRead,
          }).catch(() => {});

          return {
            ...item,
            lastReadPage: pageNumber,
            readPages: mergedRead,
            lastReadAt: new Date().toISOString(),
          };
        })
      );
    },
    []
  );

  const handleResetComicProgress = useCallback((id: string) => {
    setMediaItems((prev) =>
      prev.map((item) =>
        item.id === id
          ? { ...item, lastReadPage: 1, readPages: [] }
          : item
      )
    );
    patchMediaItemOnServer(id, { lastReadPage: 1, readPages: [] }).catch(
      () => {}
    );
  }, []);

  const handleMarkAllComicRead = useCallback(
    (id: string, totalPages: number) => {
      const allPages = Array.from({ length: totalPages }, (_, i) => i + 1);
      setMediaItems((prev) =>
        prev.map((item) =>
          item.id === id
            ? { ...item, lastReadPage: totalPages, readPages: allPages }
            : item
        )
      );
      patchMediaItemOnServer(id, {
        lastReadPage: totalPages,
        readPages: allPages,
      }).catch(() => {});
    },
    []
  );

  // Update Probed Video Metadata
  const handleUpdateProbedMeta = useCallback(
    (
      id: string,
      meta: {
        durationSeconds: number;
        width: number;
        height: number;
        thumbnailUrl?: string;
      }
    ) => {
      setMediaItems((prev) =>
        prev.map((item) =>
          item.id === id
            ? {
                ...item,
                durationSeconds: meta.durationSeconds || item.durationSeconds,
                width: meta.width || item.width,
                height: meta.height || item.height,
                thumbnailUrl: meta.thumbnailUrl || item.thumbnailUrl,
              }
            : item
        )
      );
      patchMediaItemOnServer(id, meta).catch(() => {});
    },
    []
  );

  // Delete Item Handler
  const handleDeleteItem = useCallback(
    async (id: string) => {
      setMediaItems((prev) => prev.filter((item) => item.id !== id));
      await deleteMediaItemOnServer(id, true).catch(() => {});
      if (selectedItemId === id) {
        setSelectedItemId(null);
        setCurrentPage('dashboard');
      }
    },
    [selectedItemId]
  );

  // Trigger real server-side filesystem scan
  const handleTriggerServerScan = useCallback(
    async (customDirs?: DirectoryConfig): Promise<number> => {
      setIsScanning(true);
      try {
        const res = await triggerServerScan(customDirs);
        setMediaItems(res.mediaItems);
        setDirectories(res.directories);
        return res.totalCount;
      } finally {
        setIsScanning(false);
      }
    },
    []
  );

  // Update Directories & Appearance on server
  const handleUpdateDirectories = useCallback(
    async (nextDirs: DirectoryConfig) => {
      setDirectories(nextDirs);
      await saveSettingsOnServer({ directories: nextDirs }).catch(() => {});
    },
    []
  );

  const handleUpdateAppearance = useCallback(
    async (nextApp: AppearanceConfig) => {
      setAppearance(nextApp);
      await saveSettingsOnServer({ appearance: nextApp }).catch(() => {});
    },
    []
  );

  // Upload & Index Local Files / Subfolders from Browser into Server Vault
  const handleImportLocalFiles = useCallback(
    async (
      fileList: FileList,
      targetType: MediaType,
      collectionName?: string
    ) => {
      const filesArray = Array.from(fileList);
      if (filesArray.length === 0) return;

      setIsUploading(true);
      setUploadStatusText(
        `Importing ${filesArray.length} local file(s) into ${targetType} vault...`
      );

      try {
        const updatedItems = await uploadFilesToVaultAndScan(
          filesArray,
          targetType,
          collectionName,
          (done, total, fname) => {
            setUploadStatusText(
              `Indexing local media (${done}/${total}): ${fname}`
            );
          }
        );
        setMediaItems(updatedItems);
        setUploadStatusText(
          `Successfully indexed ${filesArray.length} file(s). Total vault items: ${updatedItems.length}.`
        );
        window.setTimeout(() => setUploadStatusText(null), 4000);
      } catch (err) {
        setUploadStatusText(
          `Import error: ${err instanceof Error ? err.message : 'Failed'}`
        );
        window.setTimeout(() => setUploadStatusText(null), 4000);
      } finally {
        setIsUploading(false);
      }
    },
    []
  );

  // Open an item in its appropriate detail / overview page
  const handleSelectItem = useCallback(
    (item: MediaItem) => {
      if (item.type === 'image') {
        navigateTo('image-details', item.id);
      } else if (item.type === 'video') {
        navigateTo('video-details', item.id);
      } else if (item.type === 'comic') {
        navigateTo('comic-pages', item.id);
      } else if (item.type === 'imageset') {
        navigateTo('imageset-images', item.id);
      }
    },
    [navigateTo]
  );

  // Resume Reader directly at smart bookmarked page
  const handleResumeReader = useCallback(
    (item: MediaItem) => {
      navigateTo('reader', item.id, item.lastReadPage || 1);
    },
    [navigateTo]
  );

  // Navigate between main sections
  const handleNavigateSection = useCallback(
    (target: PageView) => {
      navigateTo(target, null);
    },
    [navigateTo]
  );

  // Jump to Advanced Search with a tag pre-filtered
  const handleQuickTagJump = useCallback(
    (tag: string) => {
      setAdvancedFilter({
        ...DEFAULT_FILTER,
        includedTags: [tag],
      });
      navigateTo('advanced-search', null);
    },
    [navigateTo]
  );

  // Database Export, Import & Clear
  const handleExportDatabase = () => {
    const payload = {
      version: '2.0.0',
      exportedAt: new Date().toISOString(),
      directories,
      appearance,
      mediaItems,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `domina-vault-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportDatabaseJson = async (
    jsonString: string
  ): Promise<boolean> => {
    try {
      const parsed = JSON.parse(jsonString);
      const res = await fetch('/api/database/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(parsed),
      });
      if (!res.ok) return false;
      const data = await res.json();
      if (data.db) {
        setMediaItems(data.db.mediaItems || []);
        setDirectories(data.db.directories || DEFAULT_DIRECTORIES);
        setAppearance({
          ...DEFAULT_APPEARANCE,
          ...(data.db.appearance || {}),
        });
      }
      return true;
    } catch {
      return false;
    }
  };

  const handleClearLibrary = async () => {
    await fetch('/api/database/clear', { method: 'POST' });
    setMediaItems([]);
    setGallerySearchQuery('');
    setAdvancedFilter(DEFAULT_FILTER);
  };

  // Compute filtered list for active gallery page using simple search bar
  const activeMediaType: MediaType =
    currentPage === 'videos'
      ? 'video'
      : currentPage === 'comics'
      ? 'comic'
      : currentPage === 'imagesets'
      ? 'imageset'
      : 'image';

  const categoryItems = useMemo(
    () => mediaItems.filter((item) => item.type === activeMediaType),
    [mediaItems, activeMediaType]
  );

  const filteredCategoryItems = useMemo(
    () =>
      categoryItems.filter((item) =>
        matchesSearchQuery(item, gallerySearchQuery)
      ),
    [categoryItems, gallerySearchQuery]
  );

  const selectedItem = useMemo(
    () => mediaItems.find((item) => item.id === selectedItemId) || null,
    [mediaItems, selectedItemId]
  );

  // Active page item when inspecting a single page inside a Comic or Image Set
  const activeCollectionPageItem: MediaItem | null = useMemo(() => {
    if (
      !selectedItem ||
      !selectedCollectionPageNumber ||
      (selectedItem.type !== 'comic' && selectedItem.type !== 'imageset')
    ) {
      return null;
    }
    const p = selectedItem.pages?.find(
      (pg) => pg.pageNumber === selectedCollectionPageNumber
    );
    if (!p) return null;
    return {
      id: `${selectedItem.id}:p${p.pageNumber}`,
      title: `${selectedItem.title} · Page ${p.pageNumber}`,
      filename: p.filename,
      localPath: p.localPath,
      folderPath: selectedItem.folderPath,
      type: 'image',
      mediaUrl: p.url,
      thumbnailUrl: p.url,
      format: p.format || 'JPG',
      sizeBytes: p.sizeBytes || 0,
      width: p.width || 0,
      height: p.height || 0,
      rating: p.rating || 0,
      isFavorite: p.isFavorite || false,
      tags: p.tags && p.tags.length > 0 ? p.tags : selectedItem.tags,
      notes: p.notes || '',
      dateAdded: selectedItem.dateAdded,
    };
  }, [selectedItem, selectedCollectionPageNumber]);

  // Dynamic Grid Column & Spacing Classes from AppearanceConfig
  const gridColsClass = useMemo(() => {
    const gap =
      appearance.cardGap === 'tight'
        ? 'gap-3'
        : appearance.cardGap === 'relaxed'
        ? 'gap-7'
        : 'gap-5';

    if (appearance.gridColumns && appearance.gridColumns >= 2) {
      const colMap: Record<number, string> = {
        2: 'grid-cols-1 sm:grid-cols-2',
        3: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3',
        4: 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4',
        5: 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5',
        6: 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6',
      };
      return `${colMap[appearance.gridColumns] || colMap[4]} ${gap}`;
    }

    if (appearance.gridDensity === 'ultra-compact') {
      return `grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-6 ${gap}`;
    }
    if (appearance.gridDensity === 'compact') {
      return `grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 ${gap}`;
    }
    if (appearance.gridDensity === 'spacious') {
      return `grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 ${gap}`;
    }
    return `grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 ${gap}`;
  }, [appearance.gridDensity, appearance.gridColumns, appearance.cardGap]);

  if (panicClosed) {
    return <div className="min-h-screen bg-black" />;
  }

  // Fullscreen Privacy Lock Screen
  if (privacyScreenLocked) {
    return (
      <div className="min-h-screen bg-[#06030C] text-purple-100 flex flex-col items-center justify-center p-6 select-none">
        <div className="max-w-md w-full bg-[#120A20] border border-purple-800/70 domina-glow-card rounded-2xl p-8 text-center space-y-5 shadow-2xl">
          <div className="w-12 h-12 rounded-full bg-[#1D0F36] border border-purple-700/60 flex items-center justify-center mx-auto">
            <Lock size={20} className="text-[#C084FC]" />
          </div>
          <div className="space-y-1.5">
            <h1 className="text-xl font-display font-semibold text-purple-50">
              Vault Privacy Lock Active
            </h1>
            <p className="text-xs text-purple-300/75">
              All local media viewports and thumbnails are concealed. Click below to unlock your vault.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setPrivacyScreenLocked(false)}
            className="w-full inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold bg-[#7C3AED] hover:bg-[#8B5CF6] text-white rounded-lg transition-colors cursor-pointer"
          >
            <Unlock size={14} />
            <span>Unlock Vault</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col text-purple-50">
      {/* Top Navigation Header */}
      <header className="sticky top-0 z-30 flex items-center justify-between gap-3 md:gap-8 px-4 md:px-6 py-3 bg-[#0B0516]/95 border-b border-purple-900/60 backdrop-blur-md">
        {/* Zone 1: Brand Wordmark */}
        <a
          href="#dashboard"
          onClick={(e) => {
            e.preventDefault();
            handleNavigateSection('dashboard');
          }}
          className="text-base md:text-xl font-display font-bold tracking-wider text-purple-50 hover:text-[#C084FC] transition-colors whitespace-nowrap shrink-0"
        >
          DOMINA
        </a>

        {/* Zone 2: Navigation Links (including Advanced Search) */}
        <nav
          aria-label="Primary Vault Navigation"
          className="flex items-center gap-3 sm:gap-5 md:gap-7 text-[11px] sm:text-xs md:text-sm font-medium text-purple-300/80 overflow-x-auto"
        >
          {(
            [
              { id: 'dashboard', label: 'Dashboard' },
              { id: 'images', label: 'Images' },
              { id: 'videos', label: 'Videos' },
              { id: 'comics', label: 'Comics' },
              { id: 'imagesets', label: 'Image Sets' },
              { id: 'advanced-search', label: 'Advanced Search' },
            ] as const
          ).map((nav) => {
            const isActive =
              currentPage === nav.id ||
              (nav.id === 'images' && currentPage === 'image-details') ||
              (nav.id === 'videos' && currentPage === 'video-details') ||
              (nav.id === 'comics' &&
                (currentPage === 'comic-pages' ||
                  (currentPage === 'reader' && selectedItem?.type === 'comic'))) ||
              (nav.id === 'imagesets' &&
                (currentPage === 'imageset-images' ||
                  (currentPage === 'reader' &&
                    selectedItem?.type === 'imageset')));

            return (
              <a
                key={nav.id}
                href={`#${nav.id}`}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavigateSection(nav.id);
                }}
                className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                  isActive
                    ? 'text-white border-[#A855F7]'
                    : 'text-purple-300/75 border-transparent hover:text-white hover:border-purple-700'
                }`}
              >
                {nav.label}
              </a>
            );
          })}
        </nav>

        {/* Zone 3: Settings CTA */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => handleNavigateSection('settings')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
              currentPage === 'settings'
                ? 'bg-white text-purple-950'
                : 'bg-[#7C3AED] hover:bg-[#8B5CF6] text-white shadow-md shadow-purple-950/60'
            }`}
          >
            Settings
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1">
        {isLoadingVault ? (
          <div className="max-w-[1440px] mx-auto px-6 py-16 text-center text-xs font-mono text-purple-300/70">
            Connecting to local Domina filesystem engine...
          </div>
        ) : currentPage === 'dashboard' ? (
          <DashboardView
            items={mediaItems}
            directories={directories}
            appearance={appearance}
            gridColsClass={gridColsClass}
            panicBlur={appearance.panicModeBlur}
            isScanning={isScanning}
            isUploading={isUploading}
            uploadStatusText={uploadStatusText}
            onNavigate={handleNavigateSection}
            onSelectItem={handleSelectItem}
            onResumeReader={handleResumeReader}
            onRate={handleRateItem}
            onToggleFavorite={handleToggleFavorite}
            onUpdateProbedMeta={handleUpdateProbedMeta}
            onQuickTagJump={(tag) => handleQuickTagJump(tag)}
            onOpenSearch={() => setQuickSearchOpen(true)}
            onPanicClose={handlePanicClose}
            onTriggerScan={() => handleTriggerServerScan()}
            onImportLocalFiles={handleImportLocalFiles}
          />
        ) : null}

        {/* Main Gallery / Library Pages: Images, Videos, Comics, Image Sets */}
        {(currentPage === 'images' ||
          currentPage === 'videos' ||
          currentPage === 'comics' ||
          currentPage === 'imagesets') && (
          <div
            className="max-w-[1440px] mx-auto px-6 py-8"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                handleImportLocalFiles(e.dataTransfer.files, activeMediaType);
              }
            }}
          >
            {/* Section Title & Subtitle */}
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
              <div>
                <div className="text-xs font-mono text-[#C084FC] uppercase tracking-wider">
                  {currentPage === 'images'
                    ? `RECURSIVE PATH · ${directories.imagesPath}`
                    : currentPage === 'videos'
                    ? `RECURSIVE PATH · ${directories.videosPath}`
                    : currentPage === 'comics'
                    ? `SUBFOLDER ARCHIVE · ${directories.comicsPath}`
                    : `SUBFOLDER ARCHIVE · ${directories.imageSetsPath}`}
                </div>
                <h1 className="text-2xl md:text-3xl font-display font-semibold text-purple-50 mt-1">
                  {currentPage === 'images'
                    ? 'Images Gallery'
                    : currentPage === 'videos'
                    ? 'Videos Studio'
                    : currentPage === 'comics'
                    ? 'Comics Library'
                    : 'Image Sets Library'}
                </h1>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setPrivacyScreenLocked(true)}
                  className="px-3 py-1.5 text-xs font-medium bg-[#120A20] hover:bg-purple-950 text-purple-200 border border-purple-900/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  Lock Screen
                </button>
                <button
                  type="button"
                  onClick={handlePanicClose}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-rose-950/80 hover:bg-rose-800 text-rose-100 border border-rose-700/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  <PowerOff size={12} />
                  <span>Panic Close</span>
                </button>
              </div>
            </div>

            {/* Simple Search Bar for Gallery Page */}
            <FilterToolbar
              mediaType={activeMediaType}
              totalCount={categoryItems.length}
              filteredCount={filteredCategoryItems.length}
              searchQuery={gallerySearchQuery}
              isUploading={isUploading}
              uploadStatusText={uploadStatusText}
              onChangeSearch={setGallerySearchQuery}
              onOpenAdvancedSearch={() => {
                setAdvancedFilter((prev) => ({
                  ...prev,
                  selectedTypes: [activeMediaType],
                }));
                setCurrentPage('advanced-search');
              }}
              onImportLocalFiles={handleImportLocalFiles}
            />

            {/* Media Grid or Empty State */}
            {categoryItems.length === 0 ? (
              <div className="bg-[#120A20]/90 border border-dashed border-purple-800/60 rounded-2xl p-12 text-center space-y-4">
                <FolderPlus size={28} className="text-[#C084FC] mx-auto" />
                <div className="space-y-1.5 max-w-md mx-auto">
                  <h2 className="text-lg font-display font-semibold text-purple-50">
                    No {currentPage} indexed yet
                  </h2>
                  <p className="text-xs text-purple-200/70 leading-relaxed">
                    Use <strong>Mount Folder</strong> or <strong>Add Files</strong> in the search bar above, drag and drop files directly onto this page, or place files into{' '}
                    <code className="text-purple-100 font-mono">
                      {currentPage === 'images'
                        ? directories.imagesPath
                        : currentPage === 'videos'
                        ? directories.videosPath
                        : currentPage === 'comics'
                        ? directories.comicsPath
                        : directories.imageSetsPath}
                    </code>{' '}
                    and run <strong>Rescan Disk</strong> in Settings.
                  </p>
                </div>
              </div>
            ) : filteredCategoryItems.length === 0 ? (
              <div className="bg-[#120A20]/90 border border-purple-900/60 rounded-2xl p-12 text-center space-y-3">
                <h2 className="text-lg font-display font-semibold text-purple-50">
                  No matching media items found
                </h2>
                <p className="text-xs text-purple-300/75 max-w-md mx-auto">
                  No items matched "{gallerySearchQuery}". Clear the search bar or use Advanced Search for multi-star and boolean tag queries.
                </p>
                <button
                  type="button"
                  onClick={() => setGallerySearchQuery('')}
                  className="px-4 py-2 text-xs font-semibold bg-[#7C3AED] hover:bg-[#8B5CF6] text-white rounded-lg transition-colors cursor-pointer"
                >
                  Clear Search
                </button>
              </div>
            ) : (
              <div className={`grid ${gridColsClass}`}>
                {filteredCategoryItems.map((item) => (
                  <MediaCard
                    key={item.id}
                    item={item}
                    onSelect={handleSelectItem}
                    onRate={handleRateItem}
                    onToggleFavorite={handleToggleFavorite}
                    onUpdateProbedMeta={handleUpdateProbedMeta}
                    onResumeReader={handleResumeReader}
                    onTagClick={(tag) => handleQuickTagJump(tag)}
                    panicBlur={appearance.panicModeBlur}
                    appearance={appearance}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Dedicated Advanced Search Page */}
        {currentPage === 'advanced-search' && (
          <AdvancedSearchView
            items={mediaItems}
            filter={advancedFilter}
            allTags={allAvailableTags}
            appearance={appearance}
            gridColsClass={gridColsClass}
            panicBlur={appearance.panicModeBlur}
            onChangeFilter={setAdvancedFilter}
            onResetFilter={() => setAdvancedFilter(DEFAULT_FILTER)}
            onSelectItem={handleSelectItem}
            onResumeReader={handleResumeReader}
            onRate={handleRateItem}
            onToggleFavorite={handleToggleFavorite}
            onUpdateTags={handleUpdateTags}
            onDelete={handleDeleteItem}
            onUpdateProbedMeta={handleUpdateProbedMeta}
          />
        )}

        {/* Page 6: Image Details (standalone image OR individual collection page) */}
        {currentPage === 'image-details' &&
          (selectedCollectionPageNumber && activeCollectionPageItem && selectedItem ? (
            <ImageDetailsView
              item={activeCollectionPageItem}
              isCollectionPage={true}
              onClose={() => {
                setSelectedCollectionPageNumber(null);
                navigateTo(
                  selectedItem.type === 'comic'
                    ? 'comic-pages'
                    : 'imageset-images',
                  selectedItem.id
                );
              }}
              hasPrev={selectedCollectionPageNumber > 1}
              hasNext={
                selectedCollectionPageNumber <
                (selectedItem.pages?.length || 1)
              }
              onPrev={() => {
                const total = selectedItem.pages?.length || 1;
                const prevPage =
                  selectedCollectionPageNumber > 1
                    ? selectedCollectionPageNumber - 1
                    : total;
                setSelectedCollectionPageNumber(prevPage);
                navigateTo(
                  'image-details',
                  selectedItem.id,
                  1,
                  prevPage,
                  false
                );
              }}
              onNext={() => {
                const total = selectedItem.pages?.length || 1;
                const nextPage =
                  selectedCollectionPageNumber < total
                    ? selectedCollectionPageNumber + 1
                    : 1;
                setSelectedCollectionPageNumber(nextPage);
                navigateTo(
                  'image-details',
                  selectedItem.id,
                  1,
                  nextPage,
                  false
                );
              }}
              onOpenReaderAtPage={() => {
                const p = selectedCollectionPageNumber;
                setSelectedCollectionPageNumber(null);
                navigateTo('reader', selectedItem.id, p);
              }}
              onRate={(_id, rating) =>
                handleRateCollectionPage(
                  selectedItem.id,
                  selectedCollectionPageNumber,
                  rating
                )
              }
              onToggleFavorite={(_id, fav) =>
                handleToggleFavoriteCollectionPage(
                  selectedItem.id,
                  selectedCollectionPageNumber,
                  fav
                )
              }
              onUpdateTags={(_id, nextTags) =>
                handleUpdateCollectionPageTags(
                  selectedItem.id,
                  selectedCollectionPageNumber,
                  nextTags
                )
              }
              onUpdateNotes={(_id, notes) =>
                handleUpdateCollectionPageNotes(
                  selectedItem.id,
                  selectedCollectionPageNumber,
                  notes
                )
              }
              onDelete={() => handleDeleteItem(selectedItem.id)}
              slideshowIntervalSeconds={appearance.slideshowIntervalSeconds}
              panicBlur={appearance.panicModeBlur}
            />
          ) : selectedItem ? (
            <ImageDetailsView
              item={selectedItem}
              onClose={() => navigateTo('images')}
              hasPrev={
                filteredCategoryItems.findIndex(
                  (i) => i.id === selectedItem.id
                ) > 0
              }
              hasNext={
                filteredCategoryItems.findIndex(
                  (i) => i.id === selectedItem.id
                ) <
                filteredCategoryItems.length - 1
              }
              onPrev={() => {
                const idx = filteredCategoryItems.findIndex(
                  (i) => i.id === selectedItem.id
                );
                if (filteredCategoryItems.length > 0) {
                  const prevIdx =
                    idx > 0 ? idx - 1 : filteredCategoryItems.length - 1;
                  navigateTo(
                    'image-details',
                    filteredCategoryItems[prevIdx].id,
                    1,
                    null,
                    false
                  );
                }
              }}
              onNext={() => {
                const idx = filteredCategoryItems.findIndex(
                  (i) => i.id === selectedItem.id
                );
                if (filteredCategoryItems.length > 0) {
                  const nextIdx =
                    idx >= 0 && idx < filteredCategoryItems.length - 1
                      ? idx + 1
                      : 0;
                  navigateTo(
                    'image-details',
                    filteredCategoryItems[nextIdx].id,
                    1,
                    null,
                    false
                  );
                }
              }}
              onRate={handleRateItem}
              onToggleFavorite={handleToggleFavorite}
              onUpdateTags={handleUpdateTags}
              onUpdateNotes={handleUpdateNotes}
              onDelete={handleDeleteItem}
              slideshowIntervalSeconds={appearance.slideshowIntervalSeconds}
              panicBlur={appearance.panicModeBlur}
            />
          ) : null)}

        {/* Page 7: Video Details */}
        {currentPage === 'video-details' && selectedItem && (
          <VideoDetailsView
            item={selectedItem}
            nextVideoItem={(() => {
              const vids = mediaItems.filter((i) => i.type === 'video');
              const idx = vids.findIndex((v) => v.id === selectedItem.id);
              return idx >= 0 ? vids[(idx + 1) % vids.length] : undefined;
            })()}
            defaultLoop={appearance.defaultVideoLoop}
            defaultAutoPlayNext={appearance.defaultAutoPlayNext}
            onClose={() => navigateTo('videos')}
            onSelectVideo={(nextVid) =>
              navigateTo('video-details', nextVid.id, 1, null, false)
            }
            onRate={handleRateItem}
            onToggleFavorite={handleToggleFavorite}
            onUpdateTags={handleUpdateTags}
            onUpdateProbedMeta={handleUpdateProbedMeta}
            onDelete={handleDeleteItem}
            panicBlur={appearance.panicModeBlur}
          />
        )}

        {/* Page 8 & Page 9: Comic Pages (Overview) & Image Set Images (Overview) */}
        {(currentPage === 'comic-pages' ||
          currentPage === 'imageset-images') &&
          selectedItem && (
            <CollectionOverviewView
              item={selectedItem}
              appearance={appearance}
              gridColsClass={gridColsClass}
              onBack={() =>
                navigateTo(
                  selectedItem.type === 'comic' ? 'comics' : 'imagesets'
                )
              }
              onOpenReader={(startPage) => {
                navigateTo('reader', selectedItem.id, startPage);
              }}
              onSelectPage={(pageNum) => {
                navigateTo(
                  'image-details',
                  selectedItem.id,
                  1,
                  pageNum
                );
              }}
              onRate={handleRateItem}
              onRatePage={handleRateCollectionPage}
              onToggleFavorite={handleToggleFavorite}
              onToggleFavoritePage={handleToggleFavoriteCollectionPage}
              onUpdateTags={handleUpdateTags}
              onResetComicProgress={handleResetComicProgress}
              onMarkAllComicRead={handleMarkAllComicRead}
              onDelete={handleDeleteItem}
              panicBlur={appearance.panicModeBlur}
            />
          )}

        {/* Page 10: Reader (Immersive Viewer) */}
        {currentPage === 'reader' && selectedItem && (
          <ReaderView
            item={selectedItem}
            initialPage={readerStartPage}
            defaultFitMode={appearance.defaultReaderFit}
            defaultDirection={appearance.defaultReaderDirection}
            slideshowIntervalSeconds={appearance.slideshowIntervalSeconds}
            onCloseToOverview={() =>
              navigateTo(
                selectedItem.type === 'comic'
                  ? 'comic-pages'
                  : 'imageset-images',
                selectedItem.id
              )
            }
            onRate={handleRateItem}
            onRatePage={handleRateCollectionPage}
            onUpdateBookmark={handleUpdateBookmark}
            panicBlur={appearance.panicModeBlur}
          />
        )}

        {/* Page 11: Settings */}
        {currentPage === 'settings' && (
          <SettingsView
            directories={directories}
            appearance={appearance}
            mediaItems={mediaItems}
            onUpdateDirectories={handleUpdateDirectories}
            onUpdateAppearance={handleUpdateAppearance}
            onTriggerServerScan={handleTriggerServerScan}
            onImportLocalFiles={handleImportLocalFiles}
            onExportDatabase={handleExportDatabase}
            onImportDatabaseJson={handleImportDatabaseJson}
            onClearLibrary={handleClearLibrary}
            onPanicClose={handlePanicClose}
          />
        )}
      </main>

      {/* Global Quick Search Modal (Ctrl+K / Cmd+K) */}
      <QuickSearchModal
        isOpen={quickSearchOpen}
        onClose={() => setQuickSearchOpen(false)}
        items={mediaItems}
        onSelectItem={handleSelectItem}
        onRate={handleRateItem}
        onOpenAdvancedSearch={() => setCurrentPage('advanced-search')}
      />
    </div>
  );
}
