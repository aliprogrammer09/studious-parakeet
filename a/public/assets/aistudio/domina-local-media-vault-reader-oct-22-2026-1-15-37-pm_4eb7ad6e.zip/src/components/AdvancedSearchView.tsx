import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowDownAZ,
  ArrowUpAZ,
  Bookmark,
  CheckSquare,
  Heart,
  Plus,
  RotateCcw,
  Search,
  SlidersHorizontal,
  Square,
  Star,
  Tag,
  Trash2,
  X,
} from 'lucide-react';
import {
  AppearanceConfig,
  ComicProgressFilter,
  DurationFilter,
  FilterState,
  MediaItem,
  MediaType,
  OrientationFilter,
  ResolutionFilter,
  SavedSearchPreset,
  SortField,
} from '../types/media';
import { filterAndSortMedia, getTagSuggestions } from '../utils/mediaLogic';
import { MediaCard } from './MediaCard';
import { StarRating } from './StarRating';

interface AdvancedSearchViewProps {
  items: MediaItem[];
  filter: FilterState;
  allTags: string[];
  appearance: AppearanceConfig;
  gridColsClass: string;
  panicBlur: boolean;
  onChangeFilter: React.Dispatch<React.SetStateAction<FilterState>>;
  onResetFilter: () => void;
  onSelectItem: (item: MediaItem) => void;
  onResumeReader: (item: MediaItem) => void;
  onRate: (id: string, rating: number) => void;
  onToggleFavorite: (id: string, nextFav: boolean) => void;
  onUpdateTags: (id: string, nextTags: string[]) => void;
  onDelete: (id: string) => void;
  onUpdateProbedMeta: (
    id: string,
    meta: {
      durationSeconds: number;
      width: number;
      height: number;
      thumbnailUrl: string;
    }
  ) => void;
}

const PRESETS_STORAGE_KEY = 'domina_saved_search_presets_v1';

export const AdvancedSearchView: React.FC<AdvancedSearchViewProps> = ({
  items,
  filter,
  allTags,
  appearance,
  gridColsClass,
  panicBlur,
  onChangeFilter,
  onResetFilter,
  onSelectItem,
  onResumeReader,
  onRate,
  onToggleFavorite,
  onUpdateTags,
  onDelete,
  onUpdateProbedMeta,
}) => {
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [presetName, setPresetName] = useState('');
  const [savedPresets, setSavedPresets] = useState<SavedSearchPreset[]>(() => {
    try {
      const raw = localStorage.getItem(PRESETS_STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  // Batch Multi-Select State
  const [batchMode, setBatchMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [batchTagInput, setBatchTagInput] = useState('');

  const tagContainerRef = useRef<HTMLDivElement | null>(null);
  const tagInputRef = useRef<HTMLInputElement | null>(null);

  // Close tag suggestions dropdown only when clicking outside the tag input + dropdown container
  useEffect(() => {
    const handleOutsideMouseDown = (e: MouseEvent) => {
      if (
        tagContainerRef.current &&
        !tagContainerRef.current.contains(e.target as Node)
      ) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideMouseDown);
    return () => document.removeEventListener('mousedown', handleOutsideMouseDown);
  }, []);

  const suggestions = getTagSuggestions(allTags, filter.tagExpression, [
    ...filter.includedTags,
    ...filter.excludedTags,
    ...filter.orTags,
  ]);

  const filteredItems = filterAndSortMedia(items, filter);

  const toggleMediaType = (type: MediaType) => {
    onChangeFilter((prev) => {
      const current = prev.selectedTypes || [];
      const exists = current.includes(type);
      const next = exists
        ? current.filter((t) => t !== type)
        : [...current, type];
      return { ...prev, selectedTypes: next };
    });
  };

  const toggleRating = (star: number) => {
    onChangeFilter((prev) => {
      const exists = prev.selectedRatings.includes(star);
      const next = exists
        ? prev.selectedRatings.filter((r) => r !== star)
        : [...prev.selectedRatings, star].sort((a, b) => a - b);
      return { ...prev, selectedRatings: next };
    });
  };

  const applySuggestion = (
    tag: string,
    mode: 'include' | 'exclude' | 'or' | 'expression'
  ) => {
    if (mode === 'include') {
      onChangeFilter((prev) => ({
        ...prev,
        includedTags: prev.includedTags.includes(tag)
          ? prev.includedTags
          : [...prev.includedTags, tag],
        excludedTags: prev.excludedTags.filter((t) => t !== tag),
      }));
    } else if (mode === 'exclude') {
      onChangeFilter((prev) => ({
        ...prev,
        excludedTags: prev.excludedTags.includes(tag)
          ? prev.excludedTags
          : [...prev.excludedTags, tag],
        includedTags: prev.includedTags.filter((t) => t !== tag),
      }));
    } else if (mode === 'or') {
      onChangeFilter((prev) => {
        const mergedOr = Array.from(
          new Set([...prev.orTags, ...prev.includedTags, tag])
        );
        return {
          ...prev,
          includedTags: [],
          orTags: mergedOr,
          excludedTags: prev.excludedTags.filter((t) => t !== tag),
        };
      });
    } else {
      onChangeFilter((prev) => {
        const tokens = prev.tagExpression.trim().split(/\s+/).filter(Boolean);
        if (tokens.length === 0) {
          return { ...prev, tagExpression: `+${tag} ` };
        }
        const last = tokens[tokens.length - 1];
        const prefix = last.startsWith('-')
          ? '-'
          : last.startsWith('+')
          ? '+'
          : '';
        tokens[tokens.length - 1] = `${prefix}${tag}`;
        return { ...prev, tagExpression: `${tokens.join(' ')} ` };
      });
    }
    // Close dropdown after selecting a tag; clicking the input again (onClick) immediately re-opens it
    setShowSuggestions(false);
  };

  const handleSavePreset = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = presetName.trim();
    if (!trimmed) return;
    const nextPreset: SavedSearchPreset = {
      id: `preset-${Date.now()}`,
      name: trimmed,
      filter: { ...filter },
      createdAt: new Date().toISOString(),
    };
    const updated = [nextPreset, ...savedPresets];
    setSavedPresets(updated);
    try {
      localStorage.setItem(PRESETS_STORAGE_KEY, JSON.stringify(updated));
    } catch {
      // ignore
    }
    setPresetName('');
  };

  const handleDeletePreset = (id: string) => {
    const updated = savedPresets.filter((p) => p.id !== id);
    setSavedPresets(updated);
    try {
      localStorage.setItem(PRESETS_STORAGE_KEY, JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const handleToggleSelectItem = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const handleBatchRate = (rating: number) => {
    for (const id of selectedIds) {
      onRate(id, rating);
    }
  };

  const handleBatchAddTag = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = batchTagInput
      .trim()
      .toLowerCase()
      .replace(/^#/, '')
      .replace(/\s+/g, '-');
    if (!cleaned) return;
    for (const id of selectedIds) {
      const target = items.find((i) => i.id === id);
      if (target && !target.tags.includes(cleaned)) {
        onUpdateTags(id, [...target.tags, cleaned]);
      }
    }
    setBatchTagInput('');
  };

  const handleBatchDelete = () => {
    for (const id of selectedIds) {
      onDelete(id);
    }
    setSelectedIds([]);
  };

  return (
    <div className="max-w-[1440px] mx-auto px-6 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-[#C084FC] uppercase tracking-wider">
            MULTI-DIMENSIONAL QUERY ENGINE
          </div>
          <h1 className="text-2xl md:text-3xl font-display font-semibold text-purple-50 mt-1">
            Advanced Search & Tag Matrix
          </h1>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              setBatchMode((b) => !b);
              setSelectedIds([]);
            }}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
              batchMode
                ? 'bg-[#7C3AED] text-white border-[#A855F7]'
                : 'bg-[#120A20] text-purple-200 border-purple-900/60 hover:border-purple-700'
            }`}
          >
            {batchMode ? <CheckSquare size={14} /> : <Square size={14} />}
            <span>{batchMode ? 'Exit Batch Select' : 'Batch Select Items'}</span>
          </button>

          <button
            type="button"
            onClick={onResetFilter}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium bg-[#120A20] hover:bg-purple-950/70 text-[#C084FC] border border-purple-900/60 rounded-lg transition-colors cursor-pointer"
          >
            <RotateCcw size={13} />
            <span>Reset All Criteria</span>
          </button>
        </div>
      </div>

      {/* Main Advanced Search Control Panel */}
      <section
        aria-label="Advanced Search Parameters"
        className="bg-[#120A20]/95 border border-purple-900/60 domina-glow-card rounded-2xl p-6 space-y-5"
      >
        {/* Row 1: Text Query + Boolean Tag Input with Click-to-Reopen Dropdown */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Keyword Search */}
          <div className="space-y-1.5">
            <label
              htmlFor="adv-keyword-search"
              className="block text-xs font-medium text-purple-200"
            >
              Title, Filename, Path, Artist, or Notes
            </label>
            <div className="relative">
              <Search
                size={15}
                className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#A855F7] pointer-events-none"
              />
              <input
                id="adv-keyword-search"
                type="text"
                value={filter.searchQuery}
                onChange={(e) =>
                  onChangeFilter((prev) => ({
                    ...prev,
                    searchQuery: e.target.value,
                  }))
                }
                placeholder="Search across all titles, filenames, artists, or local paths..."
                className="w-full pl-9 pr-8 py-2.5 text-xs bg-[#090412] border border-purple-900/60 rounded-lg text-purple-50 placeholder:text-purple-400/50 focus:outline-none focus:border-[#A855F7]"
              />
              {filter.searchQuery && (
                <button
                  type="button"
                  onClick={() =>
                    onChangeFilter((prev) => ({ ...prev, searchQuery: '' }))
                  }
                  aria-label="Clear keyword search"
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-purple-400 hover:text-white cursor-pointer"
                >
                  <X size={13} />
                </button>
              )}
            </div>
          </div>

          {/* Boolean Tag Expression with Click-to-Reopen Auto-Complete Dropdown */}
          <div className="space-y-1.5" ref={tagContainerRef}>
            <div className="flex items-center justify-between gap-2">
              <label
                htmlFor="adv-tag-expression"
                className="block text-xs font-medium text-purple-200"
              >
                Boolean Tag Query (`+include`, `-exclude`, `tagA OR tagB`)
              </label>
              <div className="flex items-center gap-1 bg-[#090412] border border-purple-900/60 rounded-md p-0.5">
                <button
                  type="button"
                  onClick={() =>
                    onChangeFilter((prev) => ({ ...prev, tagMatchMode: 'all' }))
                  }
                  className={`px-2 py-0.5 text-[11px] font-medium rounded transition-colors cursor-pointer ${
                    filter.tagMatchMode !== 'any'
                      ? 'bg-[#7C3AED] text-white'
                      : 'text-purple-300/70 hover:text-white'
                  }`}
                >
                  ALL (AND)
                </button>
                <button
                  type="button"
                  onClick={() =>
                    onChangeFilter((prev) => ({ ...prev, tagMatchMode: 'any' }))
                  }
                  className={`px-2 py-0.5 text-[11px] font-medium rounded transition-colors cursor-pointer ${
                    filter.tagMatchMode === 'any'
                      ? 'bg-[#7C3AED] text-white'
                      : 'text-purple-300/70 hover:text-white'
                  }`}
                >
                  ANY (OR)
                </button>
              </div>
            </div>
            <div className="relative">
              <Tag
                size={15}
                className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#C084FC] pointer-events-none"
              />
              <input
                ref={tagInputRef}
                id="adv-tag-expression"
                type="text"
                value={filter.tagExpression}
                onFocus={() => setShowSuggestions(true)}
                onClick={() => setShowSuggestions(true)}
                onChange={(e) => {
                  onChangeFilter((prev) => ({
                    ...prev,
                    tagExpression: e.target.value,
                  }));
                  setShowSuggestions(true);
                }}
                placeholder="Click to browse tags or type: +violet -daylight gothic OR noir"
                aria-label="Boolean tag filter query"
                className="w-full pl-9 pr-8 py-2.5 text-xs font-mono bg-[#090412] border border-purple-900/60 rounded-lg text-purple-50 placeholder:text-purple-400/50 focus:outline-none focus:border-[#C084FC]"
              />
              {filter.tagExpression && (
                <button
                  type="button"
                  onClick={() => {
                    onChangeFilter((prev) => ({ ...prev, tagExpression: '' }));
                    tagInputRef.current?.focus();
                    setShowSuggestions(true);
                  }}
                  aria-label="Clear tag expression"
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-purple-400 hover:text-white cursor-pointer"
                >
                  <X size={13} />
                </button>
              )}

              {/* Tag Auto-Complete Dropdown */}
              {showSuggestions && suggestions.length > 0 && (
                <div className="absolute z-30 left-0 right-0 top-full mt-1.5 bg-[#130A24] border border-purple-700/70 rounded-xl shadow-2xl p-2 space-y-1">
                  <div className="flex items-center justify-between px-2 py-1 text-[11px] text-purple-300/80 border-b border-purple-900/60">
                    <span>Tag Suggestions ({suggestions.length})</span>
                    <button
                      type="button"
                      onClick={() => setShowSuggestions(false)}
                      className="text-purple-400 hover:text-white cursor-pointer"
                    >
                      Close
                    </button>
                  </div>
                  <div className="max-h-56 overflow-y-auto divide-y divide-purple-900/30">
                    {suggestions.map((tag) => (
                      <div
                        key={tag}
                        className="flex items-center justify-between px-2 py-1.5 hover:bg-purple-950/70 rounded text-xs"
                      >
                        <button
                          type="button"
                          onMouseDown={(e) => {
                            e.preventDefault();
                            applySuggestion(tag, 'expression');
                          }}
                          className="text-left font-mono text-purple-100 hover:text-white flex-1 cursor-pointer"
                        >
                          #{tag}
                        </button>
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onMouseDown={(e) => {
                              e.preventDefault();
                              applySuggestion(tag, 'include');
                            }}
                            className="px-2 py-0.5 text-[11px] font-mono bg-emerald-950/70 text-emerald-300 border border-emerald-700/50 rounded hover:bg-emerald-900 cursor-pointer whitespace-nowrap"
                          >
                            +Include
                          </button>
                          <button
                            type="button"
                            onMouseDown={(e) => {
                              e.preventDefault();
                              applySuggestion(tag, 'or');
                            }}
                            className="px-2 py-0.5 text-[11px] font-mono bg-purple-950/80 text-purple-200 border border-purple-700/60 rounded hover:bg-purple-900 cursor-pointer whitespace-nowrap"
                          >
                            OR
                          </button>
                          <button
                            type="button"
                            onMouseDown={(e) => {
                              e.preventDefault();
                              applySuggestion(tag, 'exclude');
                            }}
                            className="px-2 py-0.5 text-[11px] font-mono bg-rose-950/70 text-rose-300 border border-rose-700/50 rounded hover:bg-rose-900 cursor-pointer whitespace-nowrap"
                          >
                            -Exclude
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Row 2: Media Types, Multi-Star Ratings (including 0★ Unrated), and Favorites Only */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 pt-2 border-t border-purple-900/40">
          {/* Media Types */}
          <div className="md:col-span-5 space-y-1.5">
            <span className="block text-xs font-medium text-purple-200">
              Media Categories
            </span>
            <div className="flex flex-wrap items-center gap-1.5">
              {(
                [
                  { id: 'image', label: 'Images' },
                  { id: 'video', label: 'Videos' },
                  { id: 'comic', label: 'Comics' },
                  { id: 'imageset', label: 'Image Sets' },
                ] as const
              ).map((t) => {
                const active = (filter.selectedTypes || []).includes(t.id);
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => toggleMediaType(t.id)}
                    aria-pressed={active}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#7C3AED] text-white border-[#C084FC]'
                        : 'bg-[#090412] text-purple-300/80 border-purple-900/60 hover:border-purple-700'
                    }`}
                  >
                    {t.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Multi-Star Ratings */}
          <div className="md:col-span-5 space-y-1.5">
            <span className="block text-xs font-medium text-purple-200">
              Concurrent Star Ratings (Multi-Select)
            </span>
            <div
              className="flex flex-wrap items-center gap-1.5"
              role="group"
              aria-label="Multi-star rating filter"
            >
              {[0, 1, 2, 3, 4, 5].map((star) => {
                const active = filter.selectedRatings.includes(star);
                return (
                  <button
                    key={star}
                    type="button"
                    onClick={() => toggleRating(star)}
                    aria-pressed={active}
                    aria-label={
                      star === 0
                        ? 'Filter unrated items'
                        : `Filter ${star} star items`
                    }
                    className={`inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-mono-tabular rounded-lg border transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#8B5CF6] text-white border-[#C084FC] font-semibold'
                        : 'bg-[#090412] text-purple-300/80 border-purple-900/60 hover:border-purple-700'
                    }`}
                  >
                    <span>{star === 0 ? 'Unrated' : star}</span>
                    {star > 0 && (
                      <Star
                        size={11}
                        className={
                          active
                            ? 'fill-white text-white'
                            : 'fill-current text-purple-400/70'
                        }
                      />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Favorites Toggle */}
          <div className="md:col-span-2 space-y-1.5">
            <span className="block text-xs font-medium text-purple-200">
              Favorites
            </span>
            <button
              type="button"
              onClick={() =>
                onChangeFilter((prev) => ({
                  ...prev,
                  favoritesOnly: !prev.favoritesOnly,
                }))
              }
              aria-pressed={Boolean(filter.favoritesOnly)}
              className={`w-full inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                filter.favoritesOnly
                  ? 'bg-[#9333EA] text-white border-[#C084FC]'
                  : 'bg-[#090412] text-purple-300/80 border-purple-900/60 hover:border-purple-700'
              }`}
            >
              <Heart
                size={13}
                className={filter.favoritesOnly ? 'fill-white text-white' : ''}
              />
              <span>Favorites Only</span>
            </button>
          </div>
        </div>

        {/* Row 3: Orientation, Minimum Resolution, Video Duration, Comic Reading Progress, Sort */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 pt-2 border-t border-purple-900/40">
          {/* Orientation */}
          <div className="space-y-1">
            <label
              htmlFor="adv-orientation"
              className="block text-xs font-medium text-purple-200"
            >
              Aspect Orientation
            </label>
            <select
              id="adv-orientation"
              value={filter.orientation || 'all'}
              onChange={(e) =>
                onChangeFilter((prev) => ({
                  ...prev,
                  orientation: e.target.value as OrientationFilter,
                }))
              }
              className="w-full bg-[#090412] border border-purple-900/60 rounded-lg px-3 py-2 text-xs text-purple-100 focus:outline-none focus:border-[#A855F7]"
            >
              <option value="all">All Orientations</option>
              <option value="portrait">Portrait (Vertical)</option>
              <option value="landscape">Landscape (Widescreen)</option>
              <option value="square">Square (1:1)</option>
            </select>
          </div>

          {/* Minimum Resolution */}
          <div className="space-y-1">
            <label
              htmlFor="adv-resolution"
              className="block text-xs font-medium text-purple-200"
            >
              Minimum Resolution
            </label>
            <select
              id="adv-resolution"
              value={filter.minResolution || 'all'}
              onChange={(e) =>
                onChangeFilter((prev) => ({
                  ...prev,
                  minResolution: e.target.value as ResolutionFilter,
                }))
              }
              className="w-full bg-[#090412] border border-purple-900/60 rounded-lg px-3 py-2 text-xs text-purple-100 focus:outline-none focus:border-[#A855F7]"
            >
              <option value="all">Any Resolution</option>
              <option value="hd">HD (720p+)</option>
              <option value="fhd">Full HD (1080p+)</option>
              <option value="qhd">QHD / 2K (1440p+)</option>
              <option value="uhd">4K UHD (2160p+)</option>
            </select>
          </div>

          {/* Video Length Filter */}
          <div className="space-y-1">
            <label
              htmlFor="adv-duration"
              className="block text-xs font-medium text-purple-200"
            >
              Video Duration
            </label>
            <select
              id="adv-duration"
              value={filter.durationRange || 'all'}
              onChange={(e) =>
                onChangeFilter((prev) => ({
                  ...prev,
                  durationRange: e.target.value as DurationFilter,
                }))
              }
              className="w-full bg-[#090412] border border-purple-900/60 rounded-lg px-3 py-2 text-xs text-purple-100 focus:outline-none focus:border-[#A855F7]"
            >
              <option value="all">Any Duration</option>
              <option value="short">Short (&lt; 1 min)</option>
              <option value="medium">Medium (1 – 10 min)</option>
              <option value="long">Long (&gt; 10 min)</option>
            </select>
          </div>

          {/* Comic Progress Filter */}
          <div className="space-y-1">
            <label
              htmlFor="adv-comic-progress"
              className="block text-xs font-medium text-purple-200"
            >
              Comic Reading Status
            </label>
            <select
              id="adv-comic-progress"
              value={filter.comicProgress || 'all'}
              onChange={(e) =>
                onChangeFilter((prev) => ({
                  ...prev,
                  comicProgress: e.target.value as ComicProgressFilter,
                }))
              }
              className="w-full bg-[#090412] border border-purple-900/60 rounded-lg px-3 py-2 text-xs text-purple-100 focus:outline-none focus:border-[#A855F7]"
            >
              <option value="all">All Reading States</option>
              <option value="unread">Unread (0%)</option>
              <option value="reading">In Progress (1% – 99%)</option>
              <option value="completed">Completed (100%)</option>
            </select>
          </div>

          {/* Sort By & Direction */}
          <div className="space-y-1">
            <label
              htmlFor="adv-sort"
              className="block text-xs font-medium text-purple-200"
            >
              Sort Order
            </label>
            <div className="flex items-center gap-1.5">
              <select
                id="adv-sort"
                value={filter.sortBy}
                onChange={(e) =>
                  onChangeFilter((prev) => ({
                    ...prev,
                    sortBy: e.target.value as SortField,
                  }))
                }
                className="flex-1 bg-[#090412] border border-purple-900/60 rounded-lg px-3 py-2 text-xs text-purple-100 focus:outline-none focus:border-[#A855F7]"
              >
                <option value="dateAdded">Date Added</option>
                <option value="rating">Star Rating</option>
                <option value="title">Title (A–Z)</option>
                <option value="size">File Size</option>
                <option value="resolution">Resolution (Px)</option>
                <option value="pageCount">Pages / Length</option>
              </select>
              <button
                type="button"
                onClick={() =>
                  onChangeFilter((prev) => ({
                    ...prev,
                    sortOrder: prev.sortOrder === 'asc' ? 'desc' : 'asc',
                  }))
                }
                aria-label="Toggle sort direction"
                className="p-2 bg-[#090412] border border-purple-900/60 rounded-lg text-purple-200 hover:text-white hover:border-purple-700 cursor-pointer"
              >
                {filter.sortOrder === 'asc' ? (
                  <ArrowUpAZ size={15} />
                ) : (
                  <ArrowDownAZ size={15} />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Row 4: Interactive Tag Bank & Active Tag Chips */}
        <div className="pt-3 border-t border-purple-900/40 space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="text-purple-300/80 font-medium">
              Interactive Tag Bank (Click to cycle: +Include → OR → -Exclude → Off):
            </span>
            <span className="font-mono-tabular text-purple-200">
              Matching Results:{' '}
              <strong className="text-[#C084FC]">{filteredItems.length}</strong> of{' '}
              {items.length}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {allTags.length === 0 ? (
              <span className="text-xs font-mono text-purple-400/60">
                No tags indexed yet. Add tags to any media item to filter here.
              </span>
            ) : (
              allTags.map((tag) => {
                const isInc = filter.includedTags.includes(tag);
                const isExc = filter.excludedTags.includes(tag);
                const isOr = filter.orTags.includes(tag);
                return (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => {
                      if (!isInc && !isOr && !isExc) {
                        applySuggestion(tag, 'include');
                      } else if (isInc) {
                        onChangeFilter((prev) => ({
                          ...prev,
                          includedTags: prev.includedTags.filter(
                            (t) => t !== tag
                          ),
                          orTags: [...prev.orTags, tag],
                        }));
                      } else if (isOr) {
                        onChangeFilter((prev) => ({
                          ...prev,
                          orTags: prev.orTags.filter((t) => t !== tag),
                          excludedTags: [...prev.excludedTags, tag],
                        }));
                      } else {
                        onChangeFilter((prev) => ({
                          ...prev,
                          excludedTags: prev.excludedTags.filter(
                            (t) => t !== tag
                          ),
                        }));
                      }
                    }}
                    className={`px-2.5 py-1 rounded-md font-mono text-[11px] transition-colors cursor-pointer ${
                      isInc
                        ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-600/60'
                        : isOr
                        ? 'bg-purple-900/80 text-purple-100 border border-purple-500/70'
                        : isExc
                        ? 'bg-rose-950/80 text-rose-300 border border-rose-600/60 line-through'
                        : 'bg-[#090412] text-purple-300/80 border border-purple-900/60 hover:border-purple-700 hover:text-white'
                    }`}
                  >
                    {isInc
                      ? `+${tag}`
                      : isOr
                      ? `OR:${tag}`
                      : isExc
                      ? `-${tag}`
                      : `#${tag}`}
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Row 5: Saved Search Presets */}
        <div className="pt-3 border-t border-purple-900/40 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-medium text-purple-300/80 inline-flex items-center gap-1">
              <Bookmark size={13} className="text-[#C084FC]" />
              <span>Saved Search Presets:</span>
            </span>
            {savedPresets.length === 0 ? (
              <span className="text-xs text-purple-400/50">
                Save your current filter combination for 1-click access
              </span>
            ) : (
              savedPresets.map((preset) => (
                <div
                  key={preset.id}
                  className="inline-flex items-center gap-1 bg-[#090412] border border-purple-800/70 rounded-lg px-2.5 py-1 text-xs"
                >
                  <button
                    type="button"
                    onClick={() => onChangeFilter(preset.filter)}
                    className="text-purple-100 hover:text-[#C084FC] font-medium cursor-pointer"
                  >
                    {preset.name}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeletePreset(preset.id)}
                    aria-label={`Delete preset ${preset.name}`}
                    className="text-purple-400 hover:text-rose-400 cursor-pointer ml-1"
                  >
                    <X size={12} />
                  </button>
                </div>
              ))
            )}
          </div>

          <form onSubmit={handleSavePreset} className="flex items-center gap-2">
            <input
              type="text"
              value={presetName}
              onChange={(e) => setPresetName(e.target.value)}
              placeholder="Preset name..."
              aria-label="New search preset name"
              className="px-3 py-1.5 text-xs bg-[#090412] border border-purple-900/60 rounded-lg text-purple-100 placeholder:text-purple-400/50 focus:outline-none focus:border-[#A855F7]"
            />
            <button
              type="submit"
              className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold bg-[#7C3AED] hover:bg-[#8B5CF6] text-white rounded-lg transition-colors cursor-pointer"
            >
              <Plus size={13} />
              <span>Save Preset</span>
            </button>
          </form>
        </div>
      </section>

      {/* Batch Action Bar (when Batch Mode is active) */}
      {batchMode && (
        <section className="bg-[#1B0E33] border border-[#A855F7] rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-purple-100">
              Selected: <strong>{selectedIds.length}</strong> items
            </span>
            <button
              type="button"
              onClick={() =>
                setSelectedIds(filteredItems.map((i) => i.id))
              }
              className="text-xs text-[#C084FC] hover:underline cursor-pointer"
            >
              Select All ({filteredItems.length})
            </button>
            <button
              type="button"
              onClick={() => setSelectedIds([])}
              className="text-xs text-purple-300 hover:underline cursor-pointer"
            >
              Clear Selection
            </button>
          </div>

          {selectedIds.length > 0 && (
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-xs text-purple-200">Batch Rate:</span>
                <StarRating rating={0} onChange={handleBatchRate} size="md" />
              </div>

              <form
                onSubmit={handleBatchAddTag}
                className="flex items-center gap-1.5"
              >
                <input
                  type="text"
                  value={batchTagInput}
                  onChange={(e) => setBatchTagInput(e.target.value)}
                  placeholder="Add tag to selected..."
                  className="px-2.5 py-1 text-xs bg-[#090412] border border-purple-800 rounded text-purple-100"
                />
                <button
                  type="submit"
                  className="px-2.5 py-1 text-xs font-semibold bg-[#7C3AED] hover:bg-[#8B5CF6] text-white rounded cursor-pointer"
                >
                  Apply Tag
                </button>
              </form>

              <button
                type="button"
                onClick={handleBatchDelete}
                className="inline-flex items-center gap-1 px-3 py-1 text-xs font-medium bg-rose-950/80 hover:bg-rose-800 text-rose-200 border border-rose-700/60 rounded cursor-pointer"
              >
                <Trash2 size={13} />
                <span>Delete Selected</span>
              </button>
            </div>
          )}
        </section>
      )}

      {/* Results Grid */}
      {filteredItems.length === 0 ? (
        <div className="bg-[#120A20]/80 border border-purple-900/50 rounded-2xl p-12 text-center space-y-3">
          <SlidersHorizontal size={28} className="text-[#A855F7] mx-auto" />
          <h2 className="text-lg font-display font-semibold text-purple-50">
            No matching media items found
          </h2>
          <p className="text-xs text-purple-300/70 max-w-md mx-auto">
            Adjust your boolean tag query, star ratings, or resolution/orientation filters above to broaden the results.
          </p>
          <button
            type="button"
            onClick={onResetFilter}
            className="px-4 py-2 text-xs font-semibold bg-[#7C3AED] hover:bg-[#8B5CF6] text-white rounded-lg transition-colors cursor-pointer"
          >
            Reset All Search Filters
          </button>
        </div>
      ) : (
        <div className={`grid ${gridColsClass}`}>
          {filteredItems.map((item) => (
            <MediaCard
              key={item.id}
              item={item}
              onSelect={onSelectItem}
              onRate={onRate}
              onToggleFavorite={onToggleFavorite}
              onUpdateProbedMeta={onUpdateProbedMeta}
              onResumeReader={onResumeReader}
              onTagClick={(tag) => applySuggestion(tag, 'include')}
              panicBlur={panicBlur}
              appearance={appearance}
              selectable={batchMode}
              isSelected={selectedIds.includes(item.id)}
              onToggleSelect={handleToggleSelectItem}
            />
          ))}
        </div>
      )}
    </div>
  );
};
