import React, { useState } from 'react';
import {
  ArrowLeft,
  BookOpen,
  BookmarkCheck,
  CheckCircle2,
  ExternalLink,
  Heart,
  Layers,
  Plus,
  RotateCcw,
  Trash2,
  X,
} from 'lucide-react';
import { AppearanceConfig, MediaItem } from '../types/media';
import {
  computeBookmarkProgress,
  formatFileSize,
} from '../utils/mediaLogic';
import { openPathInOsExplorer } from '../utils/localMediaClient';
import { StarRating } from './StarRating';

interface CollectionOverviewViewProps {
  item: MediaItem;
  appearance?: AppearanceConfig;
  gridColsClass?: string;
  onBack: () => void;
  onOpenReader: (startPageNumber: number) => void;
  onSelectPage: (pageNumber: number) => void;
  onRate: (id: string, rating: number) => void;
  onRatePage: (collectionId: string, pageNumber: number, rating: number) => void;
  onToggleFavorite?: (id: string, nextFav: boolean) => void;
  onToggleFavoritePage?: (
    collectionId: string,
    pageNumber: number,
    nextFav: boolean
  ) => void;
  onUpdateTags: (id: string, nextTags: string[]) => void;
  onResetComicProgress?: (id: string) => void;
  onMarkAllComicRead?: (id: string, totalPages: number) => void;
  onDelete: (id: string) => void;
  panicBlur?: boolean;
}

export const CollectionOverviewView: React.FC<CollectionOverviewViewProps> = ({
  item,
  gridColsClass = 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4',
  onBack,
  onOpenReader,
  onSelectPage,
  onRate,
  onRatePage,
  onToggleFavorite,
  onToggleFavoritePage,
  onUpdateTags,
  onResetComicProgress,
  onMarkAllComicRead,
  onDelete,
  panicBlur = false,
}) => {
  const [newTagInput, setNewTagInput] = useState('');
  const [explorerNotice, setExplorerNotice] = useState<string | null>(null);
  const [pageFilter, setPageFilter] = useState<'all' | 'favorites' | 'rated'>('all');
  const [pageSort, setPageSort] = useState<'page' | 'rating' | 'name'>('page');

  const pages = item.pages || [];
  const isComic = item.type === 'comic';
  const readPagesSet = new Set(item.readPages || []);

  // Only compute reading progress for Comics (never Image Sets)
  const bookmark = isComic
    ? computeBookmarkProgress(item.lastReadPage, pages.length, item.readPages)
    : { percent: 0, readCount: 0, isStarted: false, isCompleted: false };

  const handleAddTag = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = newTagInput
      .trim()
      .toLowerCase()
      .replace(/^#/, '')
      .replace(/\s+/g, '-');
    if (!cleaned) return;
    if (!item.tags.includes(cleaned)) {
      onUpdateTags(item.id, [...item.tags, cleaned]);
    }
    setNewTagInput('');
  };

  const handleOpenInExplorer = async () => {
    navigator.clipboard?.writeText(item.localPath).catch(() => {});
    await openPathInOsExplorer(item.localPath).catch(() => {});
    setExplorerNotice(`Folder path copied & signaled: ${item.localPath}`);
    window.setTimeout(() => setExplorerNotice(null), 3500);
  };

  const displayedPages = React.useMemo(() => {
    let list = [...pages];
    if (pageFilter === 'favorites') {
      list = list.filter((p) => p.isFavorite);
    } else if (pageFilter === 'rated') {
      list = list.filter((p) => (p.rating || 0) > 0);
    }
    if (pageSort === 'rating') {
      list.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    } else if (pageSort === 'name') {
      list.sort((a, b) => (a.filename || '').localeCompare(b.filename || ''));
    } else {
      list.sort((a, b) => a.pageNumber - b.pageNumber);
    }
    return list;
  }, [pages, pageFilter, pageSort]);

  return (
    <div className="max-w-[1440px] mx-auto px-6 py-8 space-y-8">
      {/* Top Breadcrumb & Actions Bar */}
      <div className="flex items-center justify-between gap-4 border-b border-purple-900/50 pb-4">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium bg-[#120A20] hover:bg-purple-950/80 text-purple-200 border border-purple-900/60 rounded-lg transition-colors cursor-pointer"
        >
          <ArrowLeft size={14} />
          <span>Back to {isComic ? 'Comics' : 'Image Sets'}</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onToggleFavorite && onToggleFavorite(item.id, !item.isFavorite)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
              item.isFavorite
                ? 'bg-[#9333EA] text-white border-[#C084FC]'
                : 'bg-[#120A20] text-purple-300 border-purple-900/60 hover:text-white'
            }`}
          >
            <Heart
              size={13}
              className={item.isFavorite ? 'fill-white text-white' : ''}
            />
            <span>{item.isFavorite ? 'Favorited' : 'Favorite'}</span>
          </button>

          <button
            type="button"
            onClick={handleOpenInExplorer}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#120A20] hover:bg-purple-950/80 text-purple-200 border border-purple-900/60 rounded-lg transition-colors cursor-pointer"
          >
            <ExternalLink size={13} />
            <span>Folder</span>
          </button>

          <button
            type="button"
            onClick={() => onDelete(item.id)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-rose-950/40 hover:bg-rose-900/80 text-rose-300 border border-rose-800/60 rounded-lg transition-colors cursor-pointer"
          >
            <Trash2 size={13} />
            <span>Delete</span>
          </button>
        </div>
      </div>

      {explorerNotice && (
        <div className="p-3 text-xs bg-purple-950/90 border border-purple-700/70 rounded-xl text-purple-200">
          {explorerNotice}
        </div>
      )}

      {/* Main Collection Showcase Banner */}
      <section className="bg-[#120A20]/95 border border-purple-900/60 domina-glow-card rounded-2xl p-6 md:p-8 flex flex-col md:flex-row gap-8 items-start">
        {/* Cover Thumbnail */}
        <div
          onClick={() => onSelectPage(1)}
          className="relative w-44 md:w-56 shrink-0 aspect-[3/4] bg-[#080410] rounded-xl overflow-hidden border border-purple-800/70 shadow-2xl cursor-pointer group"
        >
          {pages[0] ? (
            <img
              src={pages[0].url}
              alt={item.title}
              referrerPolicy="no-referrer"
              className={`w-full h-full object-cover transition-transform duration-200 group-hover:scale-[1.03] ${
                panicBlur ? 'blur-xl scale-110' : ''
              }`}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-purple-500">
              <Layers size={36} />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center p-3">
            <span className="text-xs text-purple-100 font-medium">Inspect in Details</span>
          </div>
        </div>

        {/* Collection Metadata & Reader Launch CTAs */}
        <div className="flex-1 space-y-4 min-w-0">
          <div>
            <div className="text-xs font-mono text-[#C084FC] uppercase tracking-wider">
              {isComic ? 'COMIC VOLUME ARCHIVE' : 'PHOTO SET COLLECTION'}
            </div>
            <h1 className="text-2xl md:text-3xl font-display font-semibold text-purple-50 mt-1">
              {item.title}
            </h1>
            <div className="flex flex-wrap items-center gap-3 text-xs text-purple-300/80 mt-2">
              <span className="font-mono-tabular">
                {pages.length} {isComic ? 'Pages' : 'Plates'}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono-tabular">
                Total Size: {formatFileSize(item.sizeBytes || 0)}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono text-purple-300/70 truncate max-w-md">
                {item.localPath}
              </span>
            </div>
          </div>

          {/* Interactive Collection Rating */}
          <div className="flex items-center gap-3 pt-1">
            <span className="text-xs text-purple-300/80">Collection Rating:</span>
            <StarRating
              rating={item.rating}
              onChange={(r) => onRate(item.id, r)}
              size="lg"
              itemTitle={item.title}
            />
          </div>

          {/* Editable Tags */}
          <div className="space-y-2 pt-2 border-t border-purple-900/50">
            <div className="flex flex-wrap items-center gap-1.5">
              {item.tags.map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs font-mono bg-[#080410] border border-purple-900/60 rounded text-purple-200"
                >
                  <span>#{tag}</span>
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateTags(
                        item.id,
                        item.tags.filter((t) => t !== tag)
                      )
                    }
                    aria-label={`Remove tag ${tag}`}
                    className="text-purple-400 hover:text-rose-400 cursor-pointer"
                  >
                    <X size={11} />
                  </button>
                </span>
              ))}

              <form onSubmit={handleAddTag} className="inline-flex items-center gap-1.5">
                <input
                  type="text"
                  value={newTagInput}
                  onChange={(e) => setNewTagInput(e.target.value)}
                  placeholder="+ Add tag"
                  aria-label="Add collection tag"
                  className="w-28 px-2.5 py-0.5 text-xs bg-[#080410] border border-purple-900/60 rounded text-purple-100 placeholder:text-purple-400/50 focus:outline-none focus:border-[#A855F7]"
                />
                <button
                  type="submit"
                  aria-label="Confirm add tag"
                  className="p-1 bg-[#7C3AED] hover:bg-[#8B5CF6] text-white rounded cursor-pointer"
                >
                  <Plus size={12} />
                </button>
              </form>
            </div>
          </div>

          {/* Direct Prominent CTA: Open in Reader + Comic-Only Smart Bookmark Resume */}
          <div className="pt-3 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => onOpenReader(1)}
              className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold bg-[#7C3AED] hover:bg-[#8B5CF6] text-white rounded-xl shadow-lg shadow-purple-950/60 transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <BookOpen size={17} />
              <span>Open in Reader</span>
            </button>

            {isComic && bookmark.isStarted && (
              <button
                type="button"
                onClick={() => onOpenReader(item.lastReadPage || 1)}
                className="inline-flex items-center gap-2 px-5 py-3 text-sm font-medium bg-[#1A0E30] hover:bg-[#261447] text-purple-50 border border-[#A855F7] rounded-xl transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <BookmarkCheck size={17} className="text-[#C084FC]" />
                <span>
                  Resume at Page {item.lastReadPage} ({bookmark.percent}% ·{' '}
                  {bookmark.readCount}/{pages.length} read)
                </span>
              </button>
            )}

            {isComic && pages.length > 0 && onMarkAllComicRead && (
              <button
                type="button"
                onClick={() => onMarkAllComicRead(item.id, pages.length)}
                className="inline-flex items-center gap-1.5 px-3.5 py-3 text-xs font-medium bg-[#080410] hover:bg-purple-950/70 text-purple-200 border border-purple-900/60 rounded-xl transition-colors cursor-pointer"
              >
                <CheckCircle2 size={14} className="text-[#C084FC]" />
                <span>Mark All Read</span>
              </button>
            )}

            {isComic && bookmark.isStarted && onResetComicProgress && (
              <button
                type="button"
                onClick={() => onResetComicProgress(item.id)}
                className="inline-flex items-center gap-1.5 px-3.5 py-3 text-xs font-medium bg-[#080410] hover:bg-purple-950/70 text-purple-300 border border-purple-900/60 rounded-xl transition-colors cursor-pointer"
              >
                <RotateCcw size={13} />
                <span>Reset Progress</span>
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Ordered Pages / Photos Grid with Filtering & Individual Page Rating */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-purple-900/50 pb-3">
          <div>
            <h2 className="text-lg font-display font-semibold text-purple-50">
              {isComic ? 'Comic Pages' : 'Image Set Plates'} ({displayedPages.length})
            </h2>
            <p className="text-xs text-purple-300/75 mt-0.5">
              Click any image below to view it in full Image Details, or rate individual pages with stars.
            </p>
          </div>

          {/* Page Filter & Sort Controls */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center bg-[#0d071a] border border-purple-900/60 rounded-lg p-0.5 text-xs">
              <button
                type="button"
                onClick={() => setPageFilter('all')}
                className={`px-2.5 py-1 rounded font-medium transition-colors cursor-pointer ${
                  pageFilter === 'all'
                    ? 'bg-[#7C3AED] text-white'
                    : 'text-purple-300 hover:text-white'
                }`}
              >
                All ({pages.length})
              </button>
              <button
                type="button"
                onClick={() => setPageFilter('favorites')}
                className={`px-2.5 py-1 rounded font-medium transition-colors cursor-pointer ${
                  pageFilter === 'favorites'
                    ? 'bg-[#7C3AED] text-white'
                    : 'text-purple-300 hover:text-white'
                }`}
              >
                Favorites ({pages.filter((p) => p.isFavorite).length})
              </button>
              <button
                type="button"
                onClick={() => setPageFilter('rated')}
                className={`px-2.5 py-1 rounded font-medium transition-colors cursor-pointer ${
                  pageFilter === 'rated'
                    ? 'bg-[#7C3AED] text-white'
                    : 'text-purple-300 hover:text-white'
                }`}
              >
                Rated ({pages.filter((p) => (p.rating || 0) > 0).length})
              </button>
            </div>

            <select
              value={pageSort}
              onChange={(e) => setPageSort(e.target.value as 'page' | 'rating' | 'name')}
              aria-label="Sort pages"
              className="bg-[#0d071a] text-xs text-purple-200 border border-purple-900/60 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-[#C084FC] cursor-pointer"
            >
              <option value="page">Page Order</option>
              <option value="rating">Highest Rated Page</option>
              <option value="name">Filename</option>
            </select>
          </div>
        </div>

        <div className={`grid ${gridColsClass}`}>
          {displayedPages.map((page) => {
            const isPageRead = isComic && readPagesSet.has(page.pageNumber);
            const isLastReadPage =
              isComic &&
              bookmark.isStarted &&
              item.lastReadPage === page.pageNumber;

            return (
              <div
                key={page.id}
                onClick={() => onSelectPage(page.pageNumber)}
                tabIndex={0}
                role="button"
                aria-label={`Open ${item.title} Page ${page.pageNumber} in Image Details`}
                className={`group text-left bg-[#120A20] border rounded-xl overflow-hidden transition-all duration-150 hover:border-[#A855F7] domina-glow-border focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A855F7] cursor-pointer ${
                  isLastReadPage
                    ? 'border-[#C084FC] ring-1 ring-[#C084FC]/60'
                    : isPageRead
                    ? 'border-purple-700/80'
                    : 'border-purple-900/50'
                }`}
              >
                <div className="relative aspect-[3/4] bg-[#080410] overflow-hidden">
                  <img
                    src={page.url}
                    alt={`${item.title} - Page ${page.pageNumber}`}
                    referrerPolicy="no-referrer"
                    className={`w-full h-full object-cover transition-transform duration-200 group-hover:scale-[1.03] ${
                      panicBlur ? 'blur-xl scale-110' : ''
                    }`}
                  />
                  <div className="absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-[#080410]/90 to-transparent" />
                  
                  {/* Page index badge */}
                  <div className="absolute bottom-2 left-2.5 right-2.5 flex items-center justify-between text-xs font-mono-tabular text-purple-100">
                    <span>P.{String(page.pageNumber).padStart(2, '0')}</span>
                    <span className="text-[11px] text-purple-300/75">
                      {page.width}×{page.height}
                    </span>
                  </div>

                  {/* Top-left Favorite Button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      onToggleFavoritePage?.(
                        item.id,
                        page.pageNumber,
                        !page.isFavorite
                      );
                    }}
                    aria-label={`Favorite Page ${page.pageNumber}`}
                    className={`absolute top-2 left-2 p-1.5 rounded-lg backdrop-blur-md transition-all cursor-pointer ${
                      page.isFavorite
                        ? 'bg-purple-900/90 text-white'
                        : 'bg-black/60 text-purple-300 opacity-0 group-hover:opacity-100 hover:text-white'
                    }`}
                  >
                    <Heart
                      size={13}
                      className={page.isFavorite ? 'fill-white text-white' : ''}
                    />
                  </button>

                  {/* Status Badges */}
                  {isLastReadPage ? (
                    <div className="absolute top-2 right-2 bg-[#7C3AED] text-white text-[10px] font-mono px-2 py-0.5 rounded shadow">
                      LAST READ
                    </div>
                  ) : isPageRead ? (
                    <div className="absolute top-2 right-2 bg-purple-950/90 border border-purple-600/60 text-purple-200 text-[10px] font-mono px-2 py-0.5 rounded">
                      READ
                    </div>
                  ) : null}
                </div>

                {/* Bottom card content with interactive page rating */}
                <div className="px-3 py-2.5 space-y-1.5 bg-[#0e071c]">
                  <div className="flex items-center justify-between gap-1">
                    <StarRating
                      rating={page.rating || 0}
                      onChange={(r) => onRatePage(item.id, page.pageNumber, r)}
                      size="sm"
                      itemTitle={`Page ${page.pageNumber}`}
                    />
                    <span className="text-[10px] font-mono text-purple-400/80">
                      {page.rating ? `${page.rating}★` : 'Rate'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-0.5 border-t border-purple-900/40">
                    <span className="font-mono text-[11px] text-purple-200 truncate max-w-[120px]">
                      {page.filename}
                    </span>
                    <span className="font-mono-tabular text-[10px] text-purple-400/70">
                      {formatFileSize(page.sizeBytes || 0)}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
