import React, { useRef } from 'react';
import {
  ArrowRight,
  BookOpen,
  BookmarkCheck,
  Film,
  FolderOpen,
  FolderPlus,
  Heart,
  Image as ImageIcon,
  Layers,
  PowerOff,
  RefreshCw,
  Search,
  Settings,
  SlidersHorizontal,
  Sparkles,
  Upload,
} from 'lucide-react';
import {
  AppearanceConfig,
  DirectoryConfig,
  MediaItem,
  MediaType,
  PageView,
} from '../types/media';
import {
  computeBookmarkProgress,
  formatFileSize,
} from '../utils/mediaLogic';
import { MediaCard } from './MediaCard';

interface DashboardViewProps {
  items: MediaItem[];
  directories: DirectoryConfig;
  appearance: AppearanceConfig;
  gridColsClass: string;
  panicBlur: boolean;
  isScanning: boolean;
  isUploading: boolean;
  uploadStatusText: string | null;
  onNavigate: (page: PageView) => void;
  onSelectItem: (item: MediaItem) => void;
  onResumeReader: (item: MediaItem) => void;
  onRate: (id: string, rating: number) => void;
  onToggleFavorite: (id: string, nextFav: boolean) => void;
  onUpdateProbedMeta: (
    id: string,
    meta: {
      durationSeconds: number;
      width: number;
      height: number;
      thumbnailUrl: string;
    }
  ) => void;
  onQuickTagJump: (tag: string, targetPage: PageView) => void;
  onOpenSearch: () => void;
  onPanicClose: () => void;
  onTriggerScan: () => void;
  onImportLocalFiles: (
    files: FileList,
    type: MediaType,
    collectionName?: string
  ) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  items,
  directories,
  appearance,
  gridColsClass,
  panicBlur,
  isScanning,
  isUploading,
  uploadStatusText,
  onNavigate,
  onSelectItem,
  onResumeReader,
  onRate,
  onToggleFavorite,
  onUpdateProbedMeta,
  onQuickTagJump,
  onOpenSearch,
  onPanicClose,
  onTriggerScan,
  onImportLocalFiles,
}) => {
  const folderRefs = {
    image: useRef<HTMLInputElement | null>(null),
    video: useRef<HTMLInputElement | null>(null),
    comic: useRef<HTMLInputElement | null>(null),
    imageset: useRef<HTMLInputElement | null>(null),
  };

  const fileRefs = {
    image: useRef<HTMLInputElement | null>(null),
    video: useRef<HTMLInputElement | null>(null),
  };

  const images = items.filter((i) => i.type === 'image');
  const videos = items.filter((i) => i.type === 'video');
  const comics = items.filter((i) => i.type === 'comic');
  const imageSets = items.filter((i) => i.type === 'imageset');

  const totalBytes = items.reduce((acc, i) => acc + i.sizeBytes, 0);

  // Highest-Rated Showcase: ONLY show rated items (rating > 0), never unrated items
  const highestRated = items
    .filter((i) => i.rating > 0)
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 8);

  // Favorites Showcase
  const favoritedItems = items.filter((i) => i.isFavorite).slice(0, 4);

  // Smart Bookmarks: ONLY Comics with reading progress (Image Sets excluded)
  const inProgressComics = items.filter((i) => {
    if (i.type !== 'comic') return false;
    const prog = computeBookmarkProgress(
      i.lastReadPage,
      i.pageCount,
      i.readPages
    );
    return prog.isStarted;
  });

  const hubCards: Array<{
    type: MediaType;
    page: PageView;
    title: string;
    count: number;
    unit: string;
    path: string;
    icon: React.ReactNode;
  }> = [
    {
      type: 'image',
      page: 'images',
      title: 'Images Gallery',
      count: images.length,
      unit: 'Indexed Images',
      path: directories.imagesPath,
      icon: <ImageIcon size={18} className="text-[#C084FC]" />,
    },
    {
      type: 'video',
      page: 'videos',
      title: 'Videos Studio',
      count: videos.length,
      unit: 'Video Streams',
      path: directories.videosPath,
      icon: <Film size={18} className="text-[#A855F7]" />,
    },
    {
      type: 'comic',
      page: 'comics',
      title: 'Comics Library',
      count: comics.length,
      unit: 'Subfolder Volumes',
      path: directories.comicsPath,
      icon: <BookOpen size={18} className="text-[#C084FC]" />,
    },
    {
      type: 'imageset',
      page: 'imagesets',
      title: 'Image Sets',
      count: imageSets.length,
      unit: 'Subfolder Sets',
      path: directories.imageSetsPath,
      icon: <Layers size={18} className="text-[#A855F7]" />,
    },
  ];

  return (
    <div className="max-w-[1440px] mx-auto px-6 py-8 space-y-10">
      {/* Hidden Folder & File Inputs for Quick Mounting */}
      {(['image', 'video', 'comic', 'imageset'] as const).map((type) => (
        <input
          key={`folder-${type}`}
          ref={folderRefs[type]}
          type="file"
          multiple
          // @ts-expect-error webkitdirectory support
          webkitdirectory=""
          directory=""
          className="hidden"
          onChange={(e) => {
            if (e.target.files && e.target.files.length > 0) {
              onImportLocalFiles(e.target.files, type);
              e.target.value = '';
            }
          }}
        />
      ))}
      <input
        ref={fileRefs.image}
        type="file"
        multiple
        accept="image/*,.png,.jpg,.jpeg,.webp,.gif,.avif,.bmp,.svg"
        className="hidden"
        onChange={(e) => {
          if (e.target.files && e.target.files.length > 0) {
            onImportLocalFiles(e.target.files, 'image');
            e.target.value = '';
          }
        }}
      />
      <input
        ref={fileRefs.video}
        type="file"
        multiple
        accept="video/*,.mp4,.webm,.mkv,.mov,.avi,.m4v,.ogv"
        className="hidden"
        onChange={(e) => {
          if (e.target.files && e.target.files.length > 0) {
            onImportLocalFiles(e.target.files, 'video');
            e.target.value = '';
          }
        }}
      />

      {/* Hero Banner & Workspace Toolbar */}
      <section className="bg-gradient-to-br from-[#230E40] via-[#130924] to-[#0A0514] border border-purple-800/60 domina-glow-card rounded-2xl p-6 md:p-8 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-3 max-w-2xl">
          <div className="inline-flex items-center gap-1.5 text-xs font-mono text-[#C084FC] tracking-wider uppercase">
            <Sparkles size={13} />
            <span>OFFLINE LOCAL MEDIA SANCTUM</span>
          </div>
          <h1
            className="text-3xl md:text-4xl font-display font-semibold text-purple-50 tracking-tight"
            style={{ textWrap: 'balance' }}
          >
            Domina Media Archive & Immersive Reader
          </h1>
          <p className="text-sm text-purple-200/75 leading-relaxed">
            Scan local directories on disk or mount folders from your machine to organize, rate, filter, and view Images, Videos, multi-page Comics, and Image Sets.
          </p>
        </div>

        {/* Workspace Quick Actions & Vault Footprint */}
        <div className="flex flex-col sm:flex-row lg:flex-col items-stretch sm:items-center lg:items-end gap-3 shrink-0">
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => onNavigate('advanced-search')}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-medium bg-[#160B2B] hover:bg-purple-950/80 text-purple-100 border border-purple-800/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <SlidersHorizontal size={14} className="text-[#C084FC]" />
              <span>Advanced Search</span>
            </button>

            <button
              type="button"
              onClick={onOpenSearch}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-medium bg-[#160B2B] hover:bg-purple-950/80 text-purple-100 border border-purple-800/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <Search size={14} className="text-[#A855F7]" />
              <span>Quick Search</span>
            </button>

            <button
              type="button"
              onClick={onPanicClose}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold bg-rose-950/80 hover:bg-rose-800 text-rose-100 border border-rose-700/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <PowerOff size={14} />
              <span>Panic Close</span>
            </button>

            <button
              type="button"
              onClick={() => onNavigate('settings')}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-medium bg-[#160B2B] hover:bg-purple-950/80 text-purple-200 border border-purple-800/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <Settings size={14} className="text-[#C084FC]" />
              <span>Settings</span>
            </button>
          </div>

          <div className="text-xs font-mono-tabular text-purple-300/75">
            Total Indexed: <strong className="text-purple-50">{items.length}</strong> items
            <span aria-hidden="true" className="mx-2">
              ·
            </span>
            Rated: <strong className="text-purple-50">{highestRated.length}</strong>
            <span aria-hidden="true" className="mx-2">
              ·
            </span>
            Footprint: <strong className="text-purple-50">{formatFileSize(totalBytes)}</strong>
          </div>
        </div>
      </section>

      {uploadStatusText && (
        <div className="p-4 bg-[#140A26] border border-[#A855F7]/60 rounded-xl text-xs font-mono text-purple-100 flex items-center justify-between">
          <span>{uploadStatusText}</span>
        </div>
      )}

      {/* Central Navigation Hub: 4 Media Category Pillars + Quick Folder Status */}
      <section
        aria-label="Media Category Hub"
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
      >
        {hubCards.map((card) => (
          <div
            key={card.type}
            className="bg-[#120A20]/95 border border-purple-900/50 hover:border-[#A855F7] domina-glow-border rounded-xl p-5 transition-all duration-150 flex flex-col justify-between gap-4"
          >
            <button
              type="button"
              onClick={() => onNavigate(card.page)}
              className="group text-left w-full cursor-pointer"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  {card.icon}
                  <h2 className="text-base font-display font-semibold text-purple-50 group-hover:text-white">
                    {card.title}
                  </h2>
                </div>
                <ArrowRight
                  size={16}
                  className="text-purple-400/60 group-hover:text-[#C084FC] group-hover:translate-x-0.5 transition-all"
                />
              </div>

              <div className="mt-4">
                <div className="text-2xl font-mono-tabular font-semibold text-purple-50">
                  {card.count}{' '}
                  <span className="text-xs font-sans font-normal text-purple-300/70">
                    {card.unit}
                  </span>
                </div>
                <div className="mt-2 pt-2 border-t border-purple-900/40 flex items-center gap-1.5 text-[11px] font-mono text-purple-300/65 truncate">
                  <FolderOpen size={12} className="text-purple-400 shrink-0" />
                  <span className="truncate">{card.path}</span>
                </div>
              </div>
            </button>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => folderRefs[card.type].current?.click()}
                className="flex-1 inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs font-medium bg-[#1C1033] hover:bg-[#271647] text-purple-100 border border-purple-800/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
              >
                <FolderPlus size={13} className="text-[#C084FC]" />
                <span>Mount Folder</span>
              </button>
              {(card.type === 'image' || card.type === 'video') && (
                <button
                  type="button"
                  onClick={() => fileRefs[card.type].current?.click()}
                  className="inline-flex items-center justify-center gap-1 px-2.5 py-1.5 text-xs font-medium bg-[#0E071B] hover:bg-[#1A0E30] text-purple-200 border border-purple-900/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <Upload size={12} className="text-[#A855F7]" />
                  <span>Add Files</span>
                </button>
              )}
            </div>
          </div>
        ))}
      </section>

      {/* Empty Library State vs Populated Showcases */}
      {items.length === 0 ? (
        <section className="bg-[#120A20]/90 border border-purple-900/50 rounded-2xl p-8 md:p-10 text-center space-y-5">
          <div className="max-w-xl mx-auto space-y-2">
            <h2 className="text-xl font-display font-semibold text-purple-50">
              Your Local Vault is Clean & Ready
            </h2>
            <p className="text-xs text-purple-200/70 leading-relaxed">
              No media files are currently indexed. Mount any folder from your machine above, drop files directly into your configured local vault paths, or open Settings to point Domina at existing directories on disk.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => folderRefs.image.current?.click()}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold bg-[#7C3AED] hover:bg-[#8B5CF6] text-white rounded-lg transition-colors cursor-pointer"
            >
              <FolderPlus size={14} />
              <span>Mount Images Folder</span>
            </button>
            <button
              type="button"
              onClick={() => folderRefs.video.current?.click()}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold bg-[#9333EA] hover:bg-[#A855F7] text-white rounded-lg transition-colors cursor-pointer"
            >
              <FolderPlus size={14} />
              <span>Mount Videos Folder</span>
            </button>
            <button
              type="button"
              onClick={() => folderRefs.comic.current?.click()}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-medium bg-[#1C1033] hover:bg-[#271647] text-purple-100 border border-purple-700/60 rounded-lg transition-colors cursor-pointer"
            >
              <BookOpen size={14} className="text-[#C084FC]" />
              <span>Mount Comics Subfolders</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('settings')}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-medium bg-[#0E071B] hover:bg-[#190D30] text-purple-200 border border-purple-800/60 rounded-lg transition-colors cursor-pointer"
            >
              <Settings size={14} />
              <span>Configure Server Directories</span>
            </button>
          </div>
        </section>
      ) : (
        <>
          {/* Smart Bookmarks / Resume Reading Strip (Comics ONLY) */}
          {inProgressComics.length > 0 && (
            <section className="space-y-4">
              <div className="flex items-center justify-between border-b border-purple-900/50 pb-3">
                <div className="flex items-center gap-2">
                  <BookmarkCheck size={18} className="text-[#C084FC]" />
                  <h2 className="text-lg font-display font-semibold text-purple-50">
                    Continue Reading Comics
                  </h2>
                </div>
                <span className="text-xs text-purple-300/70">
                  Pick up directly on your last bookmarked comic page
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {inProgressComics.map((col) => {
                  const progress = computeBookmarkProgress(
                    col.lastReadPage,
                    col.pageCount,
                    col.readPages
                  );
                  return (
                    <div
                      key={col.id}
                      onClick={() => onResumeReader(col)}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') onResumeReader(col);
                      }}
                      className="bg-[#120A20] border border-purple-900/60 hover:border-[#A855F7] rounded-xl p-4 flex items-center gap-4 transition-colors cursor-pointer"
                    >
                      <img
                        src={col.thumbnailUrl}
                        alt={col.title}
                        referrerPolicy="no-referrer"
                        className={`w-16 h-20 object-cover rounded-lg border border-purple-800/60 shrink-0 ${
                          panicBlur ? 'blur-lg' : ''
                        }`}
                      />
                      <div className="flex-1 min-w-0 space-y-1.5">
                        <div className="text-[11px] font-mono text-[#C084FC] uppercase">
                          Page {col.lastReadPage} · {progress.readCount}/
                          {col.pageCount} read ({progress.percent}%)
                        </div>
                        <h3 className="text-sm font-semibold text-purple-50 truncate">
                          {col.title}
                        </h3>
                        <div className="w-full h-1.5 bg-purple-950 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-[#7C3AED] to-[#C084FC]"
                            style={{ width: `${progress.percent}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          )}

          {/* Favorites Strip (if any items are favorited) */}
          {favoritedItems.length > 0 && (
            <section className="space-y-4">
              <div className="flex items-center justify-between border-b border-purple-900/50 pb-3">
                <div className="flex items-center gap-2">
                  <Heart size={17} className="text-[#C084FC] fill-[#C084FC]" />
                  <div>
                    <h2 className="text-lg font-display font-semibold text-purple-50">
                      Pinned Favorites
                    </h2>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onNavigate('advanced-search')}
                  className="text-xs font-medium text-[#C084FC] hover:text-purple-200 transition-colors cursor-pointer"
                >
                  Filter Favorites in Advanced Search →
                </button>
              </div>

              <div className={`grid ${gridColsClass}`}>
                {favoritedItems.map((item) => (
                  <MediaCard
                    key={`fav-${item.id}`}
                    item={item}
                    onSelect={onSelectItem}
                    onRate={onRate}
                    onToggleFavorite={onToggleFavorite}
                    onUpdateProbedMeta={onUpdateProbedMeta}
                    onResumeReader={onResumeReader}
                    onTagClick={(tag) =>
                      onQuickTagJump(
                        tag,
                        item.type === 'video'
                          ? 'videos'
                          : item.type === 'comic'
                          ? 'comics'
                          : item.type === 'imageset'
                          ? 'imagesets'
                          : 'images'
                      )
                    }
                    panicBlur={panicBlur}
                    appearance={appearance}
                  />
                ))}
              </div>
            </section>
          )}

          {/* Highest-Rated Showcase (Strictly rated items: rating > 0) */}
          <section className="space-y-4">
            <div className="flex items-center justify-between border-b border-purple-900/50 pb-3">
              <div>
                <h2 className="text-lg font-display font-semibold text-purple-50">
                  Highest-Rated Showcase
                </h2>
                <p className="text-xs text-purple-300/70">
                  Top rated works across your local vault — click any star to rate inline
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('images')}
                className="text-xs font-medium text-[#C084FC] hover:text-purple-200 transition-colors cursor-pointer"
              >
                Explore All Images →
              </button>
            </div>

            {highestRated.length === 0 ? (
              <div className="bg-[#120A20]/80 border border-dashed border-purple-800/50 rounded-xl p-8 text-center space-y-2">
                <p className="text-sm font-medium text-purple-100">
                  No rated items in your showcase yet
                </p>
                <p className="text-xs text-purple-300/70 max-w-md mx-auto">
                  Unrated media items are hidden from this showcase. Assign 1 to 5 stars to any Image, Video, Comic, or Image Set to feature it here.
                </p>
              </div>
            ) : (
              <div className={`grid ${gridColsClass}`}>
                {highestRated.map((item) => (
                  <MediaCard
                    key={item.id}
                    item={item}
                    onSelect={onSelectItem}
                    onRate={onRate}
                    onToggleFavorite={onToggleFavorite}
                    onUpdateProbedMeta={onUpdateProbedMeta}
                    onResumeReader={onResumeReader}
                    onTagClick={(tag) =>
                      onQuickTagJump(
                        tag,
                        item.type === 'video'
                          ? 'videos'
                          : item.type === 'comic'
                          ? 'comics'
                          : item.type === 'imageset'
                          ? 'imagesets'
                          : 'images'
                      )
                    }
                    panicBlur={panicBlur}
                    appearance={appearance}
                  />
                ))}
              </div>
            )}
          </section>
        </>
      )}
    </div>
  );
};
