import React, { useEffect, useState } from 'react';
import {
  ArrowUp,
  Check,
  Folder,
  FolderPlus,
  HardDrive,
  RefreshCw,
  X,
} from 'lucide-react';

interface DirectoryPickerModalProps {
  isOpen: boolean;
  title: string;
  initialPath: string;
  onClose: () => void;
  onSelectPath: (selectedPath: string) => void;
}

interface BrowseResult {
  currentPath: string;
  parentPath: string;
  subdirectories: Array<{ name: string; path: string }>;
  imageCount: number;
  videoCount: number;
  error?: string;
}

export const DirectoryPickerModal: React.FC<DirectoryPickerModalProps> = ({
  isOpen,
  title,
  initialPath,
  onClose,
  onSelectPath,
}) => {
  const [browseData, setBrowseData] = useState<BrowseResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [manualPath, setManualPath] = useState(initialPath);
  const [newFolderName, setNewFolderName] = useState('');

  const loadDirectory = async (targetDir: string) => {
    setLoading(true);
    try {
      const res = await fetch(
        `/api/fs/browse?dir=${encodeURIComponent(targetDir)}`
      );
      const data: BrowseResult = await res.json();
      setBrowseData(data);
      setManualPath(data.currentPath);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      setManualPath(initialPath);
      loadDirectory(initialPath);
    }
  }, [isOpen, initialPath]);

  if (!isOpen) return null;

  const handleCreateSubfolder = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = newFolderName.trim();
    if (!cleaned || !browseData) return;
    const newPath = `${browseData.currentPath.replace(/\/$/, '')}/${cleaned}`;
    const res = await fetch('/api/fs/mkdir', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: newPath }),
    });
    if (res.ok) {
      setNewFolderName('');
      loadDirectory(newPath);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl bg-[#120A20] border border-purple-800/70 domina-glow-card rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-purple-900/60">
          <div className="flex items-center gap-2.5">
            <HardDrive size={18} className="text-[#C084FC]" />
            <h2 className="text-base font-display font-semibold text-purple-50">
              {title}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close directory browser"
            className="p-1 text-purple-300 hover:text-white rounded cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        {/* Current Path Input & Up Button */}
        <div className="p-4 bg-[#080410] border-b border-purple-900/60 space-y-3">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() =>
                browseData?.parentPath && loadDirectory(browseData.parentPath)
              }
              aria-label="Go to parent directory"
              className="inline-flex items-center gap-1 px-3 py-2 text-xs font-medium bg-[#1A0E30] hover:bg-purple-900 text-purple-100 border border-purple-800/60 rounded-lg transition-colors cursor-pointer shrink-0"
            >
              <ArrowUp size={14} />
              <span>Up</span>
            </button>

            <input
              type="text"
              value={manualPath}
              onChange={(e) => setManualPath(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') loadDirectory(manualPath);
              }}
              aria-label="Directory path input"
              className="flex-1 px-3 py-2 text-xs font-mono bg-[#120A20] border border-purple-900/60 rounded-lg text-purple-50 focus:outline-none focus:border-[#A855F7]"
            />

            <button
              type="button"
              onClick={() => loadDirectory(manualPath)}
              className="inline-flex items-center gap-1 px-3 py-2 text-xs font-medium bg-[#1A0E30] hover:bg-purple-900 text-purple-100 border border-purple-800/60 rounded-lg transition-colors cursor-pointer shrink-0"
            >
              <RefreshCw size={13} className={loading ? 'animate-spin' : ''} />
              <span>Go</span>
            </button>
          </div>

          {browseData && (
            <div className="flex items-center justify-between text-[11px] font-mono text-purple-300/75">
              <span>
                Subfolders: {browseData.subdirectories.length} · Images here:{' '}
                {browseData.imageCount} · Videos here: {browseData.videoCount}
              </span>
              {browseData.error && (
                <span className="text-rose-400">{browseData.error}</span>
              )}
            </div>
          )}
        </div>

        {/* Subdirectory List */}
        <div className="flex-1 overflow-y-auto p-3 divide-y divide-purple-900/30 min-h-[220px]">
          {browseData?.subdirectories.length === 0 ? (
            <div className="py-10 text-center text-xs text-purple-300/60">
              No subdirectories inside this folder. You can select this directory or create a new subfolder below.
            </div>
          ) : (
            browseData?.subdirectories.map((dir) => (
              <button
                key={dir.path}
                type="button"
                onClick={() => loadDirectory(dir.path)}
                className="w-full flex items-center justify-between px-3 py-2.5 hover:bg-purple-950/60 rounded-lg text-left transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <Folder size={16} className="text-[#C084FC] shrink-0" />
                  <span className="text-xs font-mono text-purple-100 truncate">
                    {dir.name}
                  </span>
                </div>
                <span className="text-[11px] font-mono text-purple-400">
                  Open →
                </span>
              </button>
            ))
          )}
        </div>

        {/* Footer: New Subfolder & Confirm Selection */}
        <div className="p-4 bg-[#080410] border-t border-purple-900/60 flex flex-wrap items-center justify-between gap-3">
          <form
            onSubmit={handleCreateSubfolder}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={newFolderName}
              onChange={(e) => setNewFolderName(e.target.value)}
              placeholder="New folder name..."
              aria-label="New folder name"
              className="px-3 py-1.5 text-xs bg-[#120A20] border border-purple-900/60 rounded-lg text-purple-100 placeholder:text-purple-400/50 focus:outline-none focus:border-[#A855F7]"
            />
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#1A0E30] hover:bg-purple-900 text-purple-100 border border-purple-800/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              <FolderPlus size={13} className="text-[#C084FC]" />
              <span>Create Folder</span>
            </button>
          </form>

          <div className="flex items-center gap-2 ml-auto">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 text-xs font-medium text-purple-300 hover:text-white cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={() => {
                onSelectPath(manualPath);
                onClose();
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-[#7C3AED] hover:bg-[#8B5CF6] text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              <Check size={14} />
              <span>Use This Directory</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
