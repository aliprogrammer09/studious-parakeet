import React, { useRef } from 'react';
import { FilePlus2, FolderPlus, Search, SlidersHorizontal, X } from 'lucide-react';
import { MediaType } from '../types/media';

interface FilterToolbarProps {
  mediaType: MediaType;
  totalCount: number;
  filteredCount: number;
  searchQuery: string;
  isUploading?: boolean;
  uploadStatusText?: string | null;
  onChangeSearch: (query: string) => void;
  onOpenAdvancedSearch?: () => void;
  onImportLocalFiles: (
    files: FileList,
    type: MediaType,
    collectionName?: string
  ) => void;
}

export const FilterToolbar: React.FC<FilterToolbarProps> = ({
  mediaType,
  totalCount,
  filteredCount,
  searchQuery,
  isUploading = false,
  uploadStatusText = null,
  onChangeSearch,
  onOpenAdvancedSearch,
  onImportLocalFiles,
}) => {
  const folderInputRef = useRef<HTMLInputElement | null>(null);
  const filesInputRef = useRef<HTMLInputElement | null>(null);

  const fileAccept =
    mediaType === 'video'
      ? 'video/*,.mp4,.webm,.mkv,.mov,.avi,.m4v,.ogv'
      : 'image/*,.png,.jpg,.jpeg,.webp,.gif,.avif,.bmp,.svg';

  return (
    <section
      aria-label="Gallery Search Bar"
      className="bg-[#120A20]/95 border border-purple-900/50 rounded-xl p-3.5 mb-6 space-y-2.5"
    >
      <div className="flex flex-wrap items-center gap-3">
        {/* Simple Search Bar */}
        <div className="relative flex-1 min-w-[220px]">
          <Search
            size={15}
            className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#A855F7] pointer-events-none"
          />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onChangeSearch(e.target.value)}
            placeholder={`Search ${mediaType}s by title, filename, or #tag...`}
            aria-label={`Search ${mediaType}s`}
            className="w-full pl-9 pr-9 py-2 text-xs bg-[#090412] border border-purple-900/60 rounded-lg text-purple-50 placeholder:text-purple-400/50 focus:outline-none focus:border-[#A855F7] transition-colors"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => onChangeSearch('')}
              aria-label="Clear search query"
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-purple-400 hover:text-white cursor-pointer"
            >
              <X size={13} />
            </button>
          )}
        </div>

        <span className="text-xs text-purple-300/75 font-mono-tabular whitespace-nowrap shrink-0">
          Showing <strong className="text-purple-50">{filteredCount}</strong> of{' '}
          {totalCount}
        </span>

        {onOpenAdvancedSearch && (
          <button
            type="button"
            onClick={onOpenAdvancedSearch}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#1A0E30] hover:bg-[#251344] text-purple-200 border border-purple-800/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <SlidersHorizontal size={13} className="text-[#C084FC]" />
            <span>Advanced Search</span>
          </button>
        )}

        {/* Local Folder & File Mount Triggers */}
        <div className="flex items-center gap-1.5">
          <input
            ref={folderInputRef}
            type="file"
            multiple
            // @ts-expect-error webkitdirectory support
            webkitdirectory=""
            directory=""
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files.length > 0) {
                onImportLocalFiles(e.target.files, mediaType);
                e.target.value = '';
              }
            }}
          />
          <button
            type="button"
            disabled={isUploading}
            onClick={() => folderInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-[#7C3AED] hover:bg-[#8B5CF6] disabled:opacity-50 text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <FolderPlus size={14} />
            <span>Mount Folder</span>
          </button>

          <input
            ref={filesInputRef}
            type="file"
            multiple
            accept={fileAccept}
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files.length > 0) {
                onImportLocalFiles(
                  e.target.files,
                  mediaType,
                  mediaType === 'comic'
                    ? `Comic_${new Date().toISOString().slice(0, 10)}`
                    : mediaType === 'imageset'
                    ? `ImageSet_${new Date().toISOString().slice(0, 10)}`
                    : undefined
                );
                e.target.value = '';
              }
            }}
          />
          <button
            type="button"
            disabled={isUploading}
            onClick={() => filesInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#180C2E] hover:bg-[#231242] disabled:opacity-50 text-purple-100 border border-purple-800/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <FilePlus2 size={14} className="text-[#C084FC]" />
            <span>Add Files</span>
          </button>
        </div>
      </div>

      {uploadStatusText && (
        <div className="px-3 py-2 bg-[#090412] border border-[#A855F7]/50 rounded-lg text-xs font-mono text-purple-100 flex items-center justify-between">
          <span>{uploadStatusText}</span>
        </div>
      )}
    </section>
  );
};
