import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  FlipHorizontal,
  FlipVertical,
  Heart,
  Maximize2,
  Pause,
  Play,
  Plus,
  RotateCcw,
  RotateCw,
  Trash2,
  X,
  ZoomIn,
  ZoomOut,
  Sparkles,
  Sliders,
  Copy,
  Download,
  BookOpen,
} from 'lucide-react';
import { MediaItem } from '../types/media';
import { formatFileSize } from '../utils/mediaLogic';
import { openPathInOsExplorer } from '../utils/localMediaClient';
import { StarRating } from './StarRating';

interface ImageDetailsViewProps {
  item: MediaItem;
  onClose: () => void;
  onPrev?: () => void;
  onNext?: () => void;
  hasPrev: boolean;
  hasNext: boolean;
  onRate: (id: string, rating: number) => void;
  onToggleFavorite?: (id: string, nextFav: boolean) => void;
  onUpdateTags: (id: string, nextTags: string[]) => void;
  onUpdateNotes?: (id: string, notes: string) => void;
  onDelete: (id: string) => void;
  onOpenReaderAtPage?: () => void;
  isCollectionPage?: boolean;
  slideshowIntervalSeconds?: number;
  panicBlur?: boolean;
}

export const ImageDetailsView: React.FC<ImageDetailsViewProps> = ({
  item,
  onClose,
  onPrev,
  onNext,
  hasPrev,
  hasNext,
  onRate,
  onToggleFavorite,
  onUpdateTags,
  onUpdateNotes,
  onDelete,
  onOpenReaderAtPage,
  isCollectionPage = false,
  slideshowIntervalSeconds = 4,
  panicBlur = false,
}) => {
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [rotation, setRotation] = useState(0);
  const [flipH, setFlipH] = useState(false);
  const [flipV, setFlipV] = useState(false);
  
  // Expanded Viewport Tone & Optical Adjustments
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [saturation, setSaturation] = useState(100);
  const [hueRotate, setHueRotate] = useState(0);
  const [sepia, setSepia] = useState(0);
  const [invert, setInvert] = useState(0);
  const [blur, setBlur] = useState(0);
  const [vignette, setVignette] = useState(0);
  const [violetTint, setVioletTint] = useState(0);
  const [activeTonePreset, setActiveTonePreset] = useState<string>('normal');

  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [newTagInput, setNewTagInput] = useState('');
  const [notesDraft, setNotesDraft] = useState(item.notes || '');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [slideshowPlaying, setSlideshowPlaying] = useState(false);
  const [slideshowSpeed, setSlideshowSpeed] = useState(slideshowIntervalSeconds || 4);
  const [explorerNotice, setExplorerNotice] = useState<string | null>(null);
  const [copyNotice, setCopyNotice] = useState<string | null>(null);

  const viewportRef = useRef<HTMLDivElement | null>(null);

  // Reset transform when changing image
  useEffect(() => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
    setRotation(0);
    setFlipH(false);
    setFlipV(false);
    setNotesDraft(item.notes || '');
  }, [item.id, item.notes]);

  const applyTonePreset = (
    preset:
      | 'normal'
      | 'noir'
      | 'amethyst'
      | 'blood'
      | 'sepia'
      | 'vivid'
      | 'negative'
  ) => {
    setActiveTonePreset(preset);
    if (preset === 'normal') {
      setBrightness(100);
      setContrast(100);
      setSaturation(100);
      setHueRotate(0);
      setSepia(0);
      setInvert(0);
      setBlur(0);
      setVignette(0);
      setVioletTint(0);
    } else if (preset === 'noir') {
      setBrightness(95);
      setContrast(145);
      setSaturation(0);
      setHueRotate(0);
      setSepia(0);
      setInvert(0);
      setBlur(0);
      setVignette(60);
      setVioletTint(0);
    } else if (preset === 'amethyst') {
      setBrightness(100);
      setContrast(125);
      setSaturation(135);
      setHueRotate(10);
      setSepia(0);
      setInvert(0);
      setBlur(0);
      setVignette(35);
      setVioletTint(50);
    } else if (preset === 'blood') {
      setBrightness(95);
      setContrast(135);
      setSaturation(150);
      setHueRotate(-25);
      setSepia(15);
      setInvert(0);
      setBlur(0);
      setVignette(45);
      setVioletTint(25);
    } else if (preset === 'sepia') {
      setBrightness(105);
      setContrast(110);
      setSaturation(90);
      setHueRotate(0);
      setSepia(75);
      setInvert(0);
      setBlur(0);
      setVignette(25);
      setVioletTint(0);
    } else if (preset === 'vivid') {
      setBrightness(105);
      setContrast(130);
      setSaturation(170);
      setHueRotate(0);
      setSepia(0);
      setInvert(0);
      setBlur(0);
      setVignette(0);
      setVioletTint(0);
    } else if (preset === 'negative') {
      setBrightness(100);
      setContrast(120);
      setSaturation(100);
      setHueRotate(0);
      setSepia(0);
      setInvert(100);
      setBlur(0);
      setVignette(0);
      setVioletTint(0);
    }
  };

  // Sync browser fullscreenchange
  useEffect(() => {
    const handleFsChange = () => {
      if (!document.fullscreenElement) {
        setIsFullscreen(false);
      }
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  // Automatic Slideshow Timer (Infinite loop, never stops)
  useEffect(() => {
    if (!slideshowPlaying || !onNext) return;
    const timer = window.setInterval(() => {
      onNext();
    }, Math.max(1, slideshowSpeed) * 1000);
    return () => window.clearInterval(timer);
  }, [slideshowPlaying, onNext, slideshowSpeed]);

  const enterFullscreen = () => {
    setIsFullscreen(true);
    if (!document.fullscreenElement && viewportRef.current) {
      viewportRef.current.requestFullscreen?.().catch(() => {});
    }
  };

  const exitFullscreen = () => {
    setIsFullscreen(false);
    if (document.fullscreenElement) {
      document.exitFullscreen?.().catch(() => {});
    }
  };

  const toggleFullscreen = () => {
    if (isFullscreen) {
      exitFullscreen();
    } else {
      enterFullscreen();
    }
  };

  // Keyboard navigation & quick rating hotkeys
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'TEXTAREA'
      ) {
        return;
      }
      if (e.key === 'Escape') {
        if (isFullscreen) {
          exitFullscreen();
        } else {
          onClose();
        }
      } else if (e.key === 'ArrowLeft' && hasPrev && onPrev) {
        onPrev();
      } else if (e.key === 'ArrowRight' && hasNext && onNext) {
        onNext();
      } else if (e.key === 'f' || e.key === 'F') {
        toggleFullscreen();
      } else if (e.key === 'r' || e.key === 'R') {
        setRotation((r) => (r + 90) % 360);
      } else if (e.key === '0') {
        setZoom(1);
        setPan({ x: 0, y: 0 });
        setRotation(0);
        setFlipH(false);
        setFlipV(false);
      } else if (['1', '2', '3', '4', '5'].includes(e.key)) {
        onRate(item.id, Number(e.key));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  });

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY < 0 ? 0.2 : -0.2;
    setZoom((prev) => {
      const next = Math.min(6, Math.max(0.4, Number((prev + delta).toFixed(2))));
      if (next === 1) setPan({ x: 0, y: 0 });
      return next;
    });
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleAddTag = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = newTagInput
      .trim()
      .toLowerCase()
      .replace(/^#/, '')
      .replace(/\s+/g, '-');
    if (!cleaned) return;
    if (!item.tags.includes(cleaned)) {
      onUpdateTags(item.id, [...item.tags, cleaned]);
    }
    setNewTagInput('');
  };

  const handleRemoveTag = (tagToRemove: string) => {
    onUpdateTags(
      item.id,
      item.tags.filter((t) => t !== tagToRemove)
    );
  };

  const handleOpenInExplorer = async () => {
    navigator.clipboard?.writeText(item.localPath).catch(() => {});
    await openPathInOsExplorer(item.localPath).catch(() => {});
    setExplorerNotice(`Opened local directory for: ${item.localPath}`);
    window.setTimeout(() => setExplorerNotice(null), 3500);
  };

  const scaleX = (flipH ? -1 : 1) * zoom;
  const scaleY = (flipV ? -1 : 1) * zoom;

  return (
    <div
      ref={viewportRef}
      data-fullscreen={isFullscreen ? 'true' : 'false'}
      className={
        isFullscreen
          ? 'fixed inset-0 z-50 w-screen h-screen bg-black flex items-center justify-center overflow-hidden'
          : 'flex flex-col lg:flex-row h-[calc(100vh-4.25rem)] bg-[#07040E] overflow-hidden'
      }
    >
      {/* Interactive Pan & Zoom Viewport */}
      <div
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onDoubleClick={() => {
          if (isFullscreen) exitFullscreen();
        }}
        className={`relative flex-1 w-full h-full flex items-center justify-center overflow-hidden select-none ${
          isDragging ? 'cursor-grabbing' : 'cursor-grab'
        }`}
      >
        {/* Top Floating Viewport Bar — Hidden completely in Fullscreen */}
        {!isFullscreen && (
          <div className="absolute top-4 left-4 right-4 z-20 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
            <div className="pointer-events-auto flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium bg-[#120A20]/90 hover:bg-purple-950 text-purple-100 border border-purple-800/70 rounded-lg backdrop-blur-md transition-colors cursor-pointer"
              >
                <ArrowLeft size={15} />
                <span>
                  {isCollectionPage ? 'Back to Collection' : 'Back to Gallery'}
                </span>
              </button>

              {onOpenReaderAtPage && (
                <button
                  type="button"
                  onClick={onOpenReaderAtPage}
                  className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold bg-[#7C3AED]/90 hover:bg-[#8B5CF6] text-white border border-[#C084FC]/70 rounded-lg backdrop-blur-md transition-colors cursor-pointer"
                >
                  <BookOpen size={14} />
                  <span>Open in Reader</span>
                </button>
              )}
            </div>

            <div className="pointer-events-auto flex flex-wrap items-center gap-1 bg-[#120A20]/90 border border-purple-800/70 rounded-lg p-1 backdrop-blur-md">
              <button
                type="button"
                onClick={() =>
                  setZoom((z) => Math.max(0.4, Number((z - 0.25).toFixed(2))))
                }
                aria-label="Zoom out"
                className="p-1.5 text-purple-200 hover:text-white hover:bg-purple-900/60 rounded transition-colors cursor-pointer"
              >
                <ZoomOut size={15} />
              </button>
              <span className="px-2 text-xs font-mono-tabular text-purple-100">
                {Math.round(zoom * 100)}%
              </span>
              <button
                type="button"
                onClick={() =>
                  setZoom((z) => Math.min(6, Number((z + 0.25).toFixed(2))))
                }
                aria-label="Zoom in"
                className="p-1.5 text-purple-200 hover:text-white hover:bg-purple-900/60 rounded transition-colors cursor-pointer"
              >
                <ZoomIn size={15} />
              </button>

              <button
                type="button"
                onClick={() => setRotation((r) => (r - 90 + 360) % 360)}
                aria-label="Rotate counterclockwise"
                className="p-1.5 text-purple-200 hover:text-white hover:bg-purple-900/60 rounded transition-colors cursor-pointer"
              >
                <RotateCcw size={14} />
              </button>
              <button
                type="button"
                onClick={() => setRotation((r) => (r + 90) % 360)}
                aria-label="Rotate clockwise"
                className="p-1.5 text-purple-200 hover:text-white hover:bg-purple-900/60 rounded transition-colors cursor-pointer"
              >
                <RotateCw size={14} />
              </button>
              <button
                type="button"
                onClick={() => setFlipH((f) => !f)}
                aria-label="Flip horizontal"
                className={`p-1.5 rounded transition-colors cursor-pointer ${
                  flipH
                    ? 'bg-[#7C3AED] text-white'
                    : 'text-purple-200 hover:text-white hover:bg-purple-900/60'
                }`}
              >
                <FlipHorizontal size={14} />
              </button>
              <button
                type="button"
                onClick={() => setFlipV((f) => !f)}
                aria-label="Flip vertical"
                className={`p-1.5 rounded transition-colors cursor-pointer ${
                  flipV
                    ? 'bg-[#7C3AED] text-white'
                    : 'text-purple-200 hover:text-white hover:bg-purple-900/60'
                }`}
              >
                <FlipVertical size={14} />
              </button>

              {/* Slideshow button + speed selector */}
              {onNext && (
                <div className="flex items-center gap-1 bg-[#1A0E30] px-1 py-0.5 rounded border border-purple-800/60">
                  <button
                    type="button"
                    onClick={() => setSlideshowPlaying((s) => !s)}
                    aria-label={
                      slideshowPlaying ? 'Pause slideshow' : 'Start slideshow'
                    }
                    className={`inline-flex items-center gap-1 px-2 py-1 text-xs rounded transition-colors cursor-pointer ${
                      slideshowPlaying
                        ? 'bg-[#7C3AED] text-white font-semibold'
                        : 'text-purple-200 hover:text-white'
                    }`}
                  >
                    {slideshowPlaying ? <Pause size={12} /> : <Play size={12} />}
                    <span>Slideshow</span>
                  </button>
                  <select
                    value={slideshowSpeed}
                    onChange={(e) => setSlideshowSpeed(Number(e.target.value))}
                    aria-label="Slideshow speed"
                    className="bg-[#0f071e] text-[11px] font-mono text-purple-200 rounded px-1.5 py-0.5 border border-purple-800/80 focus:outline-none cursor-pointer"
                  >
                    <option value={1}>1s</option>
                    <option value={2}>2s</option>
                    <option value={3}>3s</option>
                    <option value={4}>4s</option>
                    <option value={5}>5s</option>
                    <option value={7}>7s</option>
                    <option value={10}>10s</option>
                  </select>
                </div>
              )}

              <button
                type="button"
                onClick={() => {
                  setZoom(1);
                  setPan({ x: 0, y: 0 });
                  setRotation(0);
                  setFlipH(false);
                  setFlipV(false);
                  applyTonePreset('normal');
                }}
                aria-label="Reset zoom and tone"
                className="inline-flex items-center gap-1 px-2 py-1 text-xs text-purple-200 hover:text-white hover:bg-purple-900/60 rounded transition-colors cursor-pointer"
              >
                <span>Reset</span>
              </button>

              <button
                type="button"
                onClick={toggleFullscreen}
                aria-label="Toggle fullscreen"
                className="p-1.5 text-purple-200 hover:text-white hover:bg-purple-900/60 rounded transition-colors cursor-pointer"
              >
                <Maximize2 size={15} />
              </button>
            </div>
          </div>
        )}

        {/* Previous / Next Image Navigation Buttons — Hidden in Fullscreen */}
        {!isFullscreen && (hasPrev || isCollectionPage) && onPrev && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onPrev();
            }}
            aria-label="Previous image"
            className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-3 bg-[#120A20]/85 hover:bg-[#7C3AED] text-white border border-purple-800/70 rounded-full transition-colors cursor-pointer"
          >
            <ChevronLeft size={20} />
          </button>
        )}

        {!isFullscreen && (hasNext || isCollectionPage) && onNext && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onNext();
            }}
            aria-label="Next image"
            className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-3 bg-[#120A20]/85 hover:bg-[#7C3AED] text-white border border-purple-800/70 rounded-full transition-colors cursor-pointer"
          >
            <ChevronRight size={20} />
          </button>
        )}

        {/* Pan & Zoom Image Target with Rich Optical Tone Filters & Vignette */}
        <div
          style={{
            transform: `translate3d(${pan.x}px, ${pan.y}px, 0) scale(${scaleX}, ${scaleY}) rotate(${rotation}deg)`,
          }}
          className={`relative transition-transform duration-75 ease-out flex items-center justify-center ${
            isFullscreen ? 'w-screen h-screen' : 'max-h-[85vh] max-w-[85vw]'
          }`}
        >
          <div className="relative overflow-hidden flex items-center justify-center">
            <img
              src={item.mediaUrl || item.thumbnailUrl}
              alt={item.title}
              draggable={false}
              referrerPolicy="no-referrer"
              style={{
                filter: `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%) hue-rotate(${hueRotate}deg) sepia(${sepia}%) invert(${invert}%) blur(${blur}px)`,
              }}
              className={
                isFullscreen
                  ? `w-screen h-screen object-contain select-none ${
                      panicBlur ? 'blur-2xl' : ''
                    }`
                  : `max-h-[82vh] max-w-full object-contain rounded shadow-2xl border border-purple-900/60 ${
                      panicBlur ? 'blur-2xl' : ''
                    }`
              }
            />

            {/* Vignette Overlay */}
            {vignette > 0 && (
              <div
                className="absolute inset-0 pointer-events-none rounded"
                style={{
                  background: `radial-gradient(ellipse at center, transparent 35%, rgba(0,0,0,${(
                    vignette / 100
                  ).toFixed(2)}) 100%)`,
                }}
              />
            )}

            {/* Violet Velvet Tone Tint Overlay */}
            {violetTint > 0 && (
              <div
                className="absolute inset-0 pointer-events-none rounded mix-blend-color"
                style={{
                  backgroundColor: `rgba(139, 92, 246, ${(
                    (violetTint * 0.55) /
                    100
                  ).toFixed(2)})`,
                }}
              />
            )}
          </div>
        </div>
      </div>

      {/* Metadata Sidebar — Hidden completely in Fullscreen */}
      {!isFullscreen && (
        <aside
          aria-label="Image Metadata Sidebar"
          className="w-full lg:w-96 bg-[#11091F] border-t lg:border-t-0 lg:border-l border-purple-900/60 p-6 flex flex-col justify-between overflow-y-auto shrink-0"
        >
          <div className="space-y-6">
            {/* Title, Favorite & Interactive Rating */}
            <div>
              <div className="flex items-center justify-between">
                <div className="text-xs font-mono text-[#C084FC] mb-1">
                  IMAGE INSPECTOR
                </div>
                {onToggleFavorite && (
                  <button
                    type="button"
                    onClick={() => onToggleFavorite(item.id, !item.isFavorite)}
                    aria-label={
                      item.isFavorite ? 'Remove from favorites' : 'Add to favorites'
                    }
                    className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs border transition-colors cursor-pointer ${
                      item.isFavorite
                        ? 'bg-[#7C3AED] border-[#C084FC] text-white'
                        : 'bg-[#090412] border-purple-800/60 text-purple-300 hover:text-white'
                    }`}
                  >
                    <Heart
                      size={12}
                      className={item.isFavorite ? 'fill-white text-white' : ''}
                    />
                    <span>{item.isFavorite ? 'Favorited' : 'Favorite'}</span>
                  </button>
                )}
              </div>
              <h1 className="text-xl font-display font-semibold text-purple-50 leading-snug">
                {item.title}
              </h1>

              <div className="mt-4 pt-4 border-t border-purple-900/50 flex items-center justify-between">
                <span className="text-xs text-purple-300/80">Vault Rating</span>
                <StarRating
                  rating={item.rating}
                  onChange={(r) => onRate(item.id, r)}
                  size="lg"
                  itemTitle={item.title}
                />
              </div>
            </div>

            {/* Image Color & Tone Adjustments */}
            <div className="space-y-3 pt-4 border-t border-purple-900/50 text-xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 font-semibold text-purple-200">
                  <Sliders size={13} className="text-[#C084FC]" />
                  <span>Viewport Tone Adjustments</span>
                </div>
                <button
                  type="button"
                  onClick={() => applyTonePreset('normal')}
                  className="text-[11px] text-[#C084FC] hover:underline cursor-pointer"
                >
                  Reset All
                </button>
              </div>

              {/* Quick Tone Presets */}
              <div className="space-y-1">
                <span className="text-[11px] text-purple-300/70">Tone Presets</span>
                <div className="flex flex-wrap gap-1">
                  {[
                    { id: 'normal', label: 'Default' },
                    { id: 'noir', label: 'Gothic Noir' },
                    { id: 'amethyst', label: 'Amethyst' },
                    { id: 'blood', label: 'Crimson' },
                    { id: 'sepia', label: 'Sepia' },
                    { id: 'vivid', label: 'Vivid' },
                    { id: 'negative', label: 'Invert' },
                  ].map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => applyTonePreset(p.id as any)}
                      className={`px-2 py-0.5 rounded text-[11px] font-medium border transition-colors cursor-pointer ${
                        activeTonePreset === p.id
                          ? 'bg-[#7C3AED] text-white border-[#C084FC]'
                          : 'bg-[#080410] text-purple-300 border-purple-900/60 hover:text-white'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sliders Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 pt-1">
                {/* Brightness */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-purple-300/80">
                    <span>Brightness</span>
                    <span className="font-mono-tabular">{brightness}%</span>
                  </div>
                  <input
                    type="range"
                    min={25}
                    max={200}
                    value={brightness}
                    onChange={(e) => {
                      setBrightness(Number(e.target.value));
                      setActiveTonePreset('custom');
                    }}
                    aria-label="Image brightness"
                    className="w-full h-1.5 bg-purple-950 rounded-lg accent-[#A855F7] cursor-pointer"
                  />
                </div>

                {/* Contrast */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-purple-300/80">
                    <span>Contrast</span>
                    <span className="font-mono-tabular">{contrast}%</span>
                  </div>
                  <input
                    type="range"
                    min={25}
                    max={250}
                    value={contrast}
                    onChange={(e) => {
                      setContrast(Number(e.target.value));
                      setActiveTonePreset('custom');
                    }}
                    aria-label="Image contrast"
                    className="w-full h-1.5 bg-purple-950 rounded-lg accent-[#A855F7] cursor-pointer"
                  />
                </div>

                {/* Saturation */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-purple-300/80">
                    <span>Saturation</span>
                    <span className="font-mono-tabular">{saturation}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={250}
                    value={saturation}
                    onChange={(e) => {
                      setSaturation(Number(e.target.value));
                      setActiveTonePreset('custom');
                    }}
                    aria-label="Image saturation"
                    className="w-full h-1.5 bg-purple-950 rounded-lg accent-[#A855F7] cursor-pointer"
                  />
                </div>

                {/* Hue Rotate */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-purple-300/80">
                    <span>Hue Shift</span>
                    <span className="font-mono-tabular">{hueRotate}°</span>
                  </div>
                  <input
                    type="range"
                    min={-180}
                    max={180}
                    value={hueRotate}
                    onChange={(e) => {
                      setHueRotate(Number(e.target.value));
                      setActiveTonePreset('custom');
                    }}
                    aria-label="Image hue shift"
                    className="w-full h-1.5 bg-purple-950 rounded-lg accent-[#A855F7] cursor-pointer"
                  />
                </div>

                {/* Sepia */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-purple-300/80">
                    <span>Sepia Warmth</span>
                    <span className="font-mono-tabular">{sepia}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={sepia}
                    onChange={(e) => {
                      setSepia(Number(e.target.value));
                      setActiveTonePreset('custom');
                    }}
                    aria-label="Image sepia"
                    className="w-full h-1.5 bg-purple-950 rounded-lg accent-[#A855F7] cursor-pointer"
                  />
                </div>

                {/* Invert */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-purple-300/80">
                    <span>Negative Invert</span>
                    <span className="font-mono-tabular">{invert}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={invert}
                    onChange={(e) => {
                      setInvert(Number(e.target.value));
                      setActiveTonePreset('custom');
                    }}
                    aria-label="Image invert"
                    className="w-full h-1.5 bg-purple-950 rounded-lg accent-[#A855F7] cursor-pointer"
                  />
                </div>

                {/* Soft Focus / Blur */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-purple-300/80">
                    <span>Soft Bloom</span>
                    <span className="font-mono-tabular">{blur}px</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={8}
                    step={0.5}
                    value={blur}
                    onChange={(e) => {
                      setBlur(Number(e.target.value));
                      setActiveTonePreset('custom');
                    }}
                    aria-label="Image soft blur"
                    className="w-full h-1.5 bg-purple-950 rounded-lg accent-[#A855F7] cursor-pointer"
                  />
                </div>

                {/* Vignette */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-purple-300/80">
                    <span>Vignette</span>
                    <span className="font-mono-tabular">{vignette}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={vignette}
                    onChange={(e) => {
                      setVignette(Number(e.target.value));
                      setActiveTonePreset('custom');
                    }}
                    aria-label="Image vignette"
                    className="w-full h-1.5 bg-purple-950 rounded-lg accent-[#A855F7] cursor-pointer"
                  />
                </div>

                {/* Velvet Violet Tint */}
                <div className="space-y-1 sm:col-span-2">
                  <div className="flex justify-between text-[11px] text-purple-300/80">
                    <span>Velvet Violet Tint</span>
                    <span className="font-mono-tabular">{violetTint}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={violetTint}
                    onChange={(e) => {
                      setVioletTint(Number(e.target.value));
                      setActiveTonePreset('custom');
                    }}
                    aria-label="Image violet tint"
                    className="w-full h-1.5 bg-purple-950 rounded-lg accent-[#A855F7] cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* Technical Specifications Table */}
            <div className="space-y-2.5 pt-4 border-t border-purple-900/50 text-xs">
              <h2 className="text-xs font-semibold text-purple-200">
                File Specifications
              </h2>
              <dl className="grid grid-cols-2 gap-y-2 text-purple-300/75">
                <dt>Filename</dt>
                <dd className="text-right font-mono-tabular text-purple-100 truncate">
                  {item.filename}
                </dd>
                <dt>Resolution</dt>
                <dd className="text-right font-mono-tabular text-purple-100">
                  {item.width} × {item.height} px
                </dd>
                <dt>Format</dt>
                <dd className="text-right font-mono-tabular text-purple-100">
                  {item.format}
                </dd>
                <dt>File Size</dt>
                <dd className="text-right font-mono-tabular text-purple-100">
                  {formatFileSize(item.sizeBytes)}
                </dd>
                <dt>Date Indexed</dt>
                <dd className="text-right font-mono-tabular text-purple-100">
                  {new Date(item.dateAdded).toLocaleDateString()}
                </dd>
              </dl>

              <div className="pt-2">
                <div className="flex items-center justify-between text-purple-300/75 mb-1">
                  <span>Local Storage Path</span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard?.writeText(item.localPath).catch(() => {});
                      setCopyNotice('Copied local path!');
                      window.setTimeout(() => setCopyNotice(null), 2500);
                    }}
                    className="inline-flex items-center gap-1 text-[11px] text-[#C084FC] hover:underline cursor-pointer"
                  >
                    <Copy size={11} />
                    <span>{copyNotice || 'Copy Path'}</span>
                  </button>
                </div>
                <div className="p-2.5 bg-[#080410] border border-purple-900/60 rounded font-mono text-[11px] text-purple-200 break-all select-all">
                  {item.localPath}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  type="button"
                  onClick={handleOpenInExplorer}
                  className="inline-flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium bg-[#1A0E30] hover:bg-[#251444] text-purple-100 border border-purple-800/60 rounded-lg transition-colors cursor-pointer"
                >
                  <ExternalLink size={13} className="text-[#C084FC]" />
                  <span>Open Folder</span>
                </button>

                <a
                  href={item.mediaUrl || item.thumbnailUrl}
                  download={item.filename}
                  className="inline-flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium bg-[#1A0E30] hover:bg-[#251444] text-purple-100 border border-purple-800/60 rounded-lg transition-colors cursor-pointer"
                >
                  <Download size={13} className="text-[#A855F7]" />
                  <span>Download</span>
                </a>
              </div>

              {explorerNotice && (
                <p className="text-[11px] font-mono text-emerald-300 bg-emerald-950/40 border border-emerald-800/50 rounded p-2">
                  {explorerNotice}
                </p>
              )}
            </div>

            {/* Editable Tags Section */}
            <div className="space-y-3 pt-4 border-t border-purple-900/50">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-semibold text-purple-200">
                  Assigned Tags ({item.tags.length})
                </h2>
              </div>

              <div className="flex flex-wrap gap-1.5">
                {item.tags.map((tag) => (
                  <span
                    key={tag}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono bg-[#080410] border border-purple-900/60 rounded text-purple-100"
                  >
                    <span>#{tag}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(tag)}
                      aria-label={`Remove tag ${tag}`}
                      className="text-purple-400 hover:text-rose-400 transition-colors cursor-pointer"
                    >
                      <X size={12} />
                    </button>
                  </span>
                ))}
              </div>

              <form onSubmit={handleAddTag} className="flex items-center gap-2">
                <input
                  type="text"
                  value={newTagInput}
                  onChange={(e) => setNewTagInput(e.target.value)}
                  placeholder="Add new tag (e.g. violet)..."
                  aria-label="Add new tag"
                  className="flex-1 px-3 py-1.5 text-xs bg-[#080410] border border-purple-900/60 rounded-lg text-purple-100 placeholder:text-purple-400/50 focus:outline-none focus:border-[#A855F7]"
                />
                <button
                  type="submit"
                  className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold bg-[#7C3AED] hover:bg-[#8B5CF6] text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  <Plus size={14} />
                  <span>Add Tag</span>
                </button>
              </form>
            </div>

            {/* Personal Notes */}
            {onUpdateNotes && (
              <div className="space-y-2 pt-4 border-t border-purple-900/50">
                <label
                  htmlFor="img-notes"
                  className="block text-xs font-semibold text-purple-200"
                >
                  Curator Notes
                </label>
                <textarea
                  id="img-notes"
                  rows={2}
                  value={notesDraft}
                  onChange={(e) => setNotesDraft(e.target.value)}
                  onBlur={() => {
                    if (notesDraft !== (item.notes || '')) {
                      onUpdateNotes(item.id, notesDraft);
                    }
                  }}
                  placeholder="Add private notes about this work..."
                  className="w-full px-3 py-2 text-xs bg-[#080410] border border-purple-900/60 rounded-lg text-purple-100 placeholder:text-purple-400/40 focus:outline-none focus:border-[#A855F7]"
                />
              </div>
            )}
          </div>

          {/* Bottom Danger Action */}
          <div className="pt-6 border-t border-purple-900/50 mt-6">
            <button
              type="button"
              onClick={() => onDelete(item.id)}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-rose-300 hover:text-white hover:bg-rose-950/70 border border-rose-800/50 rounded-lg transition-colors cursor-pointer"
            >
              <Trash2 size={14} />
              <span>Remove from Vault</span>
            </button>
          </div>
        </aside>
      )}
    </div>
  );
};
