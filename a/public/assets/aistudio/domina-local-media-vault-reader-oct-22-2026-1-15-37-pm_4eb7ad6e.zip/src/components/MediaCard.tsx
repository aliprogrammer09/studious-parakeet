import React, { useEffect, useRef, useState } from 'react';
import {
  BookOpen,
  Check,
  Film,
  Heart,
  Image as ImageIcon,
  Layers,
  Play,
} from 'lucide-react';
import { AppearanceConfig, MediaItem } from '../types/media';
import {
  computeBookmarkProgress,
  formatDuration,
  formatFileSize,
} from '../utils/mediaLogic';
import { probeVideoMetadataInBrowser } from '../utils/localMediaClient';
import { StarRating } from './StarRating';

interface MediaCardProps {
  item: MediaItem;
  onSelect: (item: MediaItem) => void;
  onRate: (id: string, rating: number) => void;
  onToggleFavorite?: (id: string, nextFav: boolean) => void;
  onUpdateProbedMeta?: (
    id: string,
    meta: {
      durationSeconds: number;
      width: number;
      height: number;
      thumbnailUrl: string;
    }
  ) => void;
  onTagClick?: (tag: string) => void;
  onResumeReader?: (item: MediaItem) => void;
  panicBlur?: boolean;
  appearance?: AppearanceConfig;
  aspectMode?: 'portrait' | 'landscape' | 'square';
  selectable?: boolean;
  isSelected?: boolean;
  onToggleSelect?: (id: string) => void;
}

export const MediaCard: React.FC<MediaCardProps> = ({
  item,
  onSelect,
  onRate,
  onToggleFavorite,
  onUpdateProbedMeta,
  onTagClick,
  onResumeReader,
  panicBlur = false,
  appearance,
  aspectMode,
  selectable = false,
  isSelected = false,
  onToggleSelect,
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [scrubTime, setScrubTime] = useState(0);
  const [imgError, setImgError] = useState(false);
  const hoverVideoRef = useRef<HTMLVideoElement | null>(null);
  const probedRef = useRef(false);

  // Automatically probe real video duration & capture frame thumbnail if missing
  useEffect(() => {
    if (
      item.type === 'video' &&
      item.mediaUrl &&
      (!item.durationSeconds || !item.thumbnailUrl) &&
      !probedRef.current &&
      onUpdateProbedMeta
    ) {
      probedRef.current = true;
      probeVideoMetadataInBrowser(item.mediaUrl).then((meta) => {
        if (meta) {
          onUpdateProbedMeta(item.id, {
            durationSeconds: meta.durationSeconds,
            width: meta.width,
            height: meta.height,
            thumbnailUrl: meta.thumbnailDataUrl,
          });
        }
      });
    }
  }, [
    item.id,
    item.type,
    item.mediaUrl,
    item.durationSeconds,
    item.thumbnailUrl,
    onUpdateProbedMeta,
  ]);

  const effectiveAspect =
    aspectMode ||
    appearance?.thumbnailAspect ||
    (item.type === 'video' ? 'landscape' : 'portrait');

  const aspectClass =
    effectiveAspect === 'landscape'
      ? 'aspect-video'
      : effectiveAspect === 'square'
      ? 'aspect-square'
      : effectiveAspect === 'comic'
      ? 'aspect-[2/3]'
      : effectiveAspect === 'natural'
      ? 'aspect-auto min-h-[180px]'
      : 'aspect-[3/4]';

  const fitClass =
    appearance?.thumbnailFit === 'contain' ? 'object-contain p-1' : 'object-cover';

  const radiusClass =
    appearance?.cardRadius === 'sharp'
      ? 'rounded-md'
      : appearance?.cardRadius === 'lux'
      ? 'rounded-2xl'
      : 'rounded-xl';

  const zoomClass =
    appearance?.hoverZoom === false ? '' : 'group-hover:scale-[1.04]';

  const showSize = appearance?.showCardSize ?? true;
  const showDimensions = appearance?.showCardDimensions ?? true;
  const showTags = appearance?.showCardTags ?? true;
  const showRating = appearance?.showCardRating ?? true;
  const borderStyle = appearance?.borderStyle || 'glow';
  const cardSurface =
    borderStyle === 'minimal'
      ? 'bg-[#0E071B]/90 border-purple-950/40'
      : borderStyle === 'glass'
      ? 'bg-[#160B28]/70 backdrop-blur-xl border-purple-500/30'
      : 'bg-[#120A20]/90 backdrop-blur-md border-purple-900/50 domina-glow-border';
  const titlePos: string = 'below';

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (item.type !== 'video') return;
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const vid = hoverVideoRef.current;
    const duration =
      (vid && Number.isFinite(vid.duration) && vid.duration > 0
        ? vid.duration
        : item.durationSeconds) || 30;
    const targetTime = ratio * duration;
    setScrubTime(targetTime);
    if (vid && Math.abs(vid.currentTime - targetTime) > 0.25) {
      vid.currentTime = targetTime;
    }
  };

  // Only compute reading bookmark progress for Comics (never Image Sets)
  const isComic = item.type === 'comic';
  const bookmark = isComic
    ? computeBookmarkProgress(item.lastReadPage, item.pageCount, item.readPages)
    : { percent: 0, readCount: 0, isStarted: false, isCompleted: false };
  const effectiveDuration = item.durationSeconds || 0;

  return (
    <article
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onMouseMove={handleMouseMove}
      onClick={() => {
        if (selectable && onToggleSelect) {
          onToggleSelect(item.id);
        } else {
          onSelect(item);
        }
      }}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          if (selectable && onToggleSelect) {
            onToggleSelect(item.id);
          } else {
            onSelect(item);
          }
        }
      }}
      tabIndex={0}
      role="button"
      aria-label={`Open ${item.title}`}
      className={`group relative flex flex-col border ${cardSurface} ${radiusClass} overflow-hidden transition-all duration-150 domina-glow-border focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A855F7] cursor-pointer ${
        isSelected
          ? 'border-[#A855F7] ring-2 ring-[#A855F7]/70'
          : 'hover:border-[#A855F7]'
      }`}
    >
      {/* Thumbnail Viewport */}
      <div className={`relative w-full ${aspectClass} bg-[#080410] overflow-hidden`}>
        {item.type === 'video' && isHovered && item.mediaUrl ? (
          <div className={`w-full h-full ${panicBlur ? 'blur-xl scale-110' : ''}`}>
            <video
              ref={hoverVideoRef}
              src={item.mediaUrl}
              muted
              autoPlay
              loop
              playsInline
              onTimeUpdate={(e) => setScrubTime(e.currentTarget.currentTime)}
              className={`w-full h-full ${fitClass}`}
            />
            {/* Hover Scrubbing Progress Bar */}
            <div className="absolute bottom-0 inset-x-0 h-1 bg-purple-950/90">
              <div
                className="h-full bg-[#A855F7] transition-all duration-75"
                style={{
                  width: `${Math.min(
                    100,
                    (scrubTime / Math.max(1, effectiveDuration)) * 100
                  )}%`,
                }}
              />
            </div>
            <div className="absolute top-2.5 left-2.5 text-[11px] font-mono-tabular text-purple-100 bg-[#150828]/85 border border-purple-700/50 px-2 py-0.5 rounded">
              PREVIEW · {formatDuration(scrubTime)}
            </div>
          </div>
        ) : !imgError && item.thumbnailUrl ? (
          <img
            src={item.thumbnailUrl}
            alt={item.title}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className={`w-full h-full ${fitClass} transition-transform duration-200 ${zoomClass} ${
              panicBlur ? 'blur-xl scale-110' : ''
            }`}
          />
        ) : item.type === 'video' && item.mediaUrl ? (
          <video
            src={`${item.mediaUrl}#t=0.5`}
            preload="metadata"
            muted
            playsInline
            className={`w-full h-full ${fitClass} ${
              panicBlur ? 'blur-xl scale-110' : ''
            }`}
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-[#210D3B] via-[#110722] to-[#080410] p-4 text-center">
            {item.type === 'video' ? (
              <Film className="w-8 h-8 text-[#A855F7]/80 mb-2" />
            ) : item.type === 'comic' ? (
              <BookOpen className="w-8 h-8 text-[#C084FC]/80 mb-2" />
            ) : item.type === 'imageset' ? (
              <Layers className="w-8 h-8 text-[#A855F7]/80 mb-2" />
            ) : (
              <ImageIcon className="w-8 h-8 text-[#C084FC]/80 mb-2" />
            )}
            <span className="text-xs font-display text-purple-200/80 line-clamp-2">
              {item.title}
            </span>
          </div>
        )}

        {/* Top-Left Batch Selection Checkbox */}
        {selectable && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleSelect?.(item.id);
            }}
            aria-label={`Select ${item.title}`}
            className={`absolute top-2.5 left-2.5 z-10 w-6 h-6 rounded-md flex items-center justify-center border transition-colors cursor-pointer ${
              isSelected
                ? 'bg-[#8B5CF6] border-[#C084FC] text-white'
                : 'bg-black/70 border-purple-700/60 text-transparent hover:border-purple-400'
            }`}
          >
            <Check size={14} />
          </button>
        )}

        {/* Top-Right Favorite Heart Toggle */}
        {onToggleFavorite && (
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onToggleFavorite(item.id, !item.isFavorite);
            }}
            aria-label={
              item.isFavorite
                ? `Remove ${item.title} from favorites`
                : `Add ${item.title} to favorites`
            }
            className={`absolute top-2.5 right-2.5 z-10 p-1.5 rounded-full border backdrop-blur-sm transition-all cursor-pointer ${
              item.isFavorite
                ? 'bg-[#8B5CF6]/90 border-[#C084FC] text-white shadow-md shadow-purple-950/60'
                : 'bg-black/60 border-purple-800/40 text-purple-300/70 opacity-0 group-hover:opacity-100 hover:text-white hover:bg-purple-900/70'
            }`}
          >
            <Heart
              size={13}
              className={item.isFavorite ? 'fill-white text-white' : ''}
            />
          </button>
        )}

        {/* Measured Gradient Scrim at Bottom of Media */}
        <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-[#090412]/95 via-[#090412]/45 to-transparent pointer-events-none" />

        {/* Video Duration Overlay */}
        {item.type === 'video' && (
          <div className="absolute bottom-2.5 right-3 flex items-center gap-1.5 text-xs font-mono-tabular font-medium text-purple-100 drop-shadow">
            <Play size={11} className="fill-[#A855F7] text-[#A855F7]" />
            <span>{formatDuration(effectiveDuration)}</span>
          </div>
        )}

        {/* Comic / Image Set Page Count & Comic-Only Resume Indicator */}
        {(item.type === 'comic' || item.type === 'imageset') && (
          <div className="absolute bottom-2.5 inset-x-3 flex items-center justify-between text-xs font-mono-tabular text-purple-100">
            <span>
              {item.pageCount || item.pages?.length || 0}{' '}
              {item.type === 'comic' ? 'PAGES' : 'PLATES'}
            </span>
            {isComic && bookmark.isStarted && onResumeReader && (
              <button
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onResumeReader(item);
                }}
                className="text-[11px] font-sans font-medium text-white bg-[#7C3AED] hover:bg-[#8B5CF6] border border-purple-400/40 px-2 py-0.5 rounded transition-colors cursor-pointer whitespace-nowrap shrink-0"
                aria-label={`Resume reading ${item.title} at page ${item.lastReadPage}`}
              >
                Resume P.{item.lastReadPage} ({bookmark.percent}%)
              </button>
            )}
          </div>
        )}

        {/* Smart Bookmark Progress Line on Comics ONLY (never Image Sets) */}
        {isComic && bookmark.isStarted && (
          <div className="absolute bottom-0 inset-x-0 h-1 bg-purple-950">
            <div
              className="h-full bg-gradient-to-r from-[#7C3AED] to-[#C084FC]"
              style={{ width: `${bookmark.percent}%` }}
            />
          </div>
        )}
        {/* Optional Overlay Title */}
        {(titlePos === 'overlay' || titlePos === 'hover') && (
          <div
            className={`absolute bottom-8 inset-x-3 z-10 pointer-events-none transition-opacity duration-150 ${
              titlePos === 'hover' ? 'opacity-0 group-hover:opacity-100' : 'opacity-100'
            }`}
          >
            <h3 className="text-xs font-semibold text-white drop-shadow truncate">
              {item.title}
            </h3>
          </div>
        )}
      </div>

      {/* Card Body: Title, Interactive 5-Star Rating, and Unboxed Metadata/Tags */}
      <div className="p-3.5 flex flex-col gap-2 flex-1 justify-between">
        <div>
          {titlePos === 'below' && (
            <h3 className="text-sm font-semibold text-purple-50 group-hover:text-white truncate leading-snug">
              {item.title}
            </h3>
          )}
          {(showRating || showSize || showDimensions) && (
            <div className="mt-1.5 flex items-center justify-between gap-2">
              {showRating ? (
                <StarRating
                  rating={item.rating}
                  onChange={(r) => onRate(item.id, r)}
                  size="sm"
                  itemTitle={item.title}
                />
              ) : (
                <span />
              )}
              {(showSize || showDimensions) && (
                <span className="text-[11px] font-mono-tabular text-purple-300/60 whitespace-nowrap shrink-0">
                  {showDimensions && item.width > 0
                    ? `${item.width}×${item.height}`
                    : item.format}
                  {showSize ? ` · ${formatFileSize(item.sizeBytes)}` : ''}
                </span>
              )}
            </div>
          )}
        </div>

        {/* Unboxed Tag Metadata with Typographic Separators */}
        {showTags && item.tags.length > 0 && (
          <div className="pt-1.5 border-t border-purple-900/40 flex items-center flex-wrap gap-x-1.5 gap-y-0.5 text-xs text-purple-300/75">
            {item.tags.slice(0, 4).map((tag, idx) => (
              <React.Fragment key={tag}>
                {idx > 0 && (
                  <span aria-hidden="true" className="text-purple-700">
                    ·
                  </span>
                )}
                {onTagClick ? (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      onTagClick(tag);
                    }}
                    className="hover:text-[#C084FC] transition-colors cursor-pointer whitespace-nowrap"
                  >
                    #{tag}
                  </button>
                ) : (
                  <span className="whitespace-nowrap">#{tag}</span>
                )}
              </React.Fragment>
            ))}
            {item.tags.length > 4 && (
              <>
                <span aria-hidden="true" className="text-purple-700">
                  ·
                </span>
                <span className="text-purple-400/70 font-mono-tabular">
                  +{item.tags.length - 4}
                </span>
              </>
            )}
          </div>
        )}
      </div>
    </article>
  );
};
