import React, { useEffect, useRef, useState } from 'react';
import {
  BookOpen,
  Film,
  Image as ImageIcon,
  Layers,
  Search,
  SlidersHorizontal,
  X,
} from 'lucide-react';
import { MediaItem } from '../types/media';
import { matchesSearchQuery } from '../utils/mediaLogic';
import { StarRating } from './StarRating';

interface QuickSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: MediaItem[];
  onSelectItem: (item: MediaItem) => void;
  onRate: (id: string, rating: number) => void;
  onOpenAdvancedSearch?: () => void;
}

export const QuickSearchModal: React.FC<QuickSearchModalProps> = ({
  isOpen,
  onClose,
  items,
  onSelectItem,
  onRate,
  onOpenAdvancedSearch,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      window.setTimeout(() => inputRef.current?.focus(), 40);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const matchingItems = items
    .filter((item) => matchesSearchQuery(item, query))
    .slice(0, 10);

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-start justify-center pt-16 px-4"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Global Quick Search"
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl bg-[#120A20] border border-purple-800/70 domina-glow-card rounded-2xl shadow-2xl overflow-hidden"
      >
        {/* Search Input Header */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-purple-900/60">
          <Search size={18} className="text-[#C084FC] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search all Images, Videos, Comics, Image Sets, or #tags..."
            aria-label="Global quick search input"
            className="flex-1 bg-transparent text-sm text-purple-50 placeholder:text-purple-400/50 focus:outline-none"
          />
          {onOpenAdvancedSearch && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenAdvancedSearch();
              }}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium bg-[#1D0F36] hover:bg-purple-900 text-purple-100 border border-purple-700/60 rounded-lg cursor-pointer"
            >
              <SlidersHorizontal size={12} className="text-[#C084FC]" />
              <span>Advanced Search</span>
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            aria-label="Close quick search"
            className="p-1 text-purple-300 hover:text-white rounded cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto divide-y divide-purple-900/40">
          {matchingItems.length === 0 ? (
            <div className="py-12 text-center text-xs text-purple-300/70">
              No vault media items match "{query}".
            </div>
          ) : (
            matchingItems.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  onSelectItem(item);
                  onClose();
                }}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    onSelectItem(item);
                    onClose();
                  }
                }}
                className="flex items-center justify-between gap-4 px-4 py-3 hover:bg-purple-950/60 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-lg bg-[#080410] border border-purple-900/60 flex items-center justify-center shrink-0">
                    {item.type === 'image' ? (
                      <ImageIcon size={15} className="text-[#C084FC]" />
                    ) : item.type === 'video' ? (
                      <Film size={15} className="text-[#A855F7]" />
                    ) : item.type === 'comic' ? (
                      <BookOpen size={15} className="text-[#C084FC]" />
                    ) : (
                      <Layers size={15} className="text-[#A855F7]" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-purple-50 truncate">
                      {item.title}
                    </div>
                    <div className="text-xs text-purple-300/70 truncate">
                      <span className="uppercase font-mono text-[10px] text-[#C084FC]">
                        {item.type}
                      </span>
                      <span aria-hidden="true" className="mx-1.5">
                        ·
                      </span>
                      <span>
                        {item.tags
                          .slice(0, 4)
                          .map((t) => `#${t}`)
                          .join(' · ')}
                      </span>
                    </div>
                  </div>
                </div>

                <div
                  onClick={(e) => e.stopPropagation()}
                  className="shrink-0"
                >
                  <StarRating
                    rating={item.rating}
                    onChange={(r) => onRate(item.id, r)}
                    size="sm"
                    itemTitle={item.title}
                  />
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
