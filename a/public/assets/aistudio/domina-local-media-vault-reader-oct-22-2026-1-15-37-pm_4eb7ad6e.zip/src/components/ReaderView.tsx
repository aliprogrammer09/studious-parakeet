import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  ArrowLeft,
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Columns,
  Maximize2,
  Minimize2,
  Moon,
  PanelLeft,
  Pause,
  Play,
  ScrollText,
  Sun,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import {
  MediaItem,
  ReaderDirection,
  ReaderFitMode,
} from '../types/media';
import { computeBookmarkProgress } from '../utils/mediaLogic';
import { StarRating } from './StarRating';

interface ReaderViewProps {
  item: MediaItem;
  initialPage?: number;
  defaultFitMode?: ReaderFitMode;
  defaultDirection?: ReaderDirection;
  slideshowIntervalSeconds?: number;
  onCloseToOverview: () => void;
  onRate: (id: string, rating: number) => void;
  onRatePage?: (collectionId: string, pageNumber: number, rating: number) => void;
  onUpdateBookmark: (
    id: string,
    pageNumber: number,
    newlyReadPages: number[]
  ) => void;
  panicBlur?: boolean;
}

export const ReaderView: React.FC<ReaderViewProps> = ({
  item,
  initialPage = 1,
  defaultFitMode = 'height',
  defaultDirection = 'ltr',
  slideshowIntervalSeconds = 4,
  onCloseToOverview,
  onRate,
  onRatePage,
  onUpdateBookmark,
  panicBlur = false,
}) => {
  const pages = item.pages || [];
  const totalPages = pages.length;
  const isComic = item.type === 'comic';

  const [currentPage, setCurrentPage] = useState<number>(
    Math.min(Math.max(1, initialPage), Math.max(1, totalPages))
  );
  const [fitMode, setFitMode] = useState<ReaderFitMode>(defaultFitMode);
  const [direction, setDirection] = useState<ReaderDirection>(defaultDirection);
  const [readerZoom, setReaderZoom] = useState<number>(1);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [fullscreenControlsVisible, setFullscreenControlsVisible] = useState(false);
  const [slideshowPlaying, setSlideshowPlaying] = useState(false);
  const [slideshowSpeed, setSlideshowSpeed] = useState<number>(
    slideshowIntervalSeconds || 4
  );
  const [readerInvert, setReaderInvert] = useState<boolean>(false);

  const readerContainerRef = useRef<HTMLDivElement | null>(null);
  const lastRecordedRef = useRef<string>('');
  const hideControlsTimerRef = useRef<number | null>(null);

  // Sync currentPage if initialPage prop changes
  useEffect(() => {
    const clamped = Math.min(Math.max(1, initialPage), Math.max(1, totalPages));
    setCurrentPage(clamped);
  }, [initialPage, totalPages]);

  // Persist smart bookmark & actual readPages for Comics ONLY
  useEffect(() => {
    if (!isComic || totalPages === 0) return;
    const visiblePages =
      fitMode === 'double' &&
      direction !== 'vertical' &&
      currentPage < totalPages
        ? [currentPage, currentPage + 1]
        : [currentPage];

    const signature = `${item.id}:${currentPage}:${visiblePages.join(',')}`;
    if (lastRecordedRef.current === signature) return;
    lastRecordedRef.current = signature;

    onUpdateBookmark(item.id, currentPage, visiblePages);
  }, [isComic, item.id, currentPage, fitMode, direction, totalPages, onUpdateBookmark]);

  // Automatic Slideshow Timer (infinite loop back to page 1)
  useEffect(() => {
    if (!slideshowPlaying || totalPages <= 1) return;
    const timer = window.setInterval(() => {
      setCurrentPage((prev) => (prev >= totalPages ? 1 : prev + 1));
    }, Math.max(1, slideshowSpeed) * 1000);
    return () => window.clearInterval(timer);
  }, [slideshowPlaying, totalPages, slideshowSpeed]);

  const stepAmount = fitMode === 'double' && direction !== 'vertical' ? 2 : 1;

  const goNextPage = useCallback(() => {
    setCurrentPage((p) => Math.min(totalPages, p + stepAmount));
  }, [totalPages, stepAmount]);

  const goPrevPage = useCallback(() => {
    setCurrentPage((p) => Math.max(1, p - stepAmount));
  }, [stepAmount]);

  const toggleFullscreen = () => {
    if (!isFullscreen) {
      setIsFullscreen(true);
      setFullscreenControlsVisible(true);
      if (!document.fullscreenElement && readerContainerRef.current) {
        readerContainerRef.current.requestFullscreen?.().catch(() => {});
      }
    } else {
      setIsFullscreen(false);
      if (document.fullscreenElement) {
        document.exitFullscreen?.().catch(() => {});
      }
    }
  };

  // Sync state if user exits fullscreen via browser native Esc key
  useEffect(() => {
    const handleFsChange = () => {
      if (!document.fullscreenElement) {
        setIsFullscreen(false);
      }
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  // Show floating controls on mouse move in fullscreen, then auto-hide after 2.5s
  const handleFullscreenMouseMove = () => {
    if (!isFullscreen) return;
    setFullscreenControlsVisible(true);
    if (hideControlsTimerRef.current) {
      window.clearTimeout(hideControlsTimerRef.current);
    }
    hideControlsTimerRef.current = window.setTimeout(() => {
      setFullscreenControlsVisible(false);
    }, 2500);
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'TEXTAREA'
      ) {
        return;
      }
      if (e.key === 'Escape') {
        if (isFullscreen) {
          setIsFullscreen(false);
          if (document.fullscreenElement) {
            document.exitFullscreen?.().catch(() => {});
          }
        } else {
          onCloseToOverview();
        }
      } else if (e.key === 'ArrowRight') {
        if (direction === 'rtl') goPrevPage();
        else goNextPage();
      } else if (e.key === 'ArrowLeft') {
        if (direction === 'rtl') goNextPage();
        else goPrevPage();
      } else if (e.key === 'w' || e.key === 'W') {
        setFitMode('width');
      } else if (e.key === 'h' || e.key === 'H') {
        setFitMode('height');
      } else if (e.key === 'd' || e.key === 'D') {
        setFitMode('double');
      } else if (e.key === 'f' || e.key === 'F') {
        toggleFullscreen();
      } else if (['1', '2', '3', '4', '5'].includes(e.key)) {
        const ratingVal = Number(e.key);
        if (onRatePage) {
          onRatePage(item.id, currentPage, ratingVal);
        } else {
          onRate(item.id, ratingVal);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    direction,
    goNextPage,
    goPrevPage,
    isFullscreen,
    item.id,
    currentPage,
    onCloseToOverview,
    onRate,
    onRatePage,
  ]);

  const activePageObj = pages[currentPage - 1] || pages[0];
  const secondSpreadPageObj =
    fitMode === 'double' && currentPage < totalPages
      ? pages[currentPage]
      : null;

  const comicProgress = isComic
    ? computeBookmarkProgress(item.lastReadPage, totalPages, item.readPages)
    : null;
  const readSet = new Set(item.readPages || []);

  const imageFilterStyle = {
    filter: readerInvert ? 'invert(0.92) hue-rotate(180deg)' : 'none',
    transition: 'filter 0.2s ease',
  };

  return (
    <div
      ref={readerContainerRef}
      onMouseMove={handleFullscreenMouseMove}
      className={
        isFullscreen
          ? 'fixed inset-0 z-50 w-screen h-screen bg-[#05020a] text-purple-50 flex flex-col overflow-hidden select-none'
          : 'flex flex-col h-[calc(100vh-4.25rem)] bg-[#06030C] text-purple-50 overflow-hidden'
      }
    >
      {/* ------------------------------------------------------------- */}
      {/* Standard Top Navigation Bar (Visible in non-fullscreen mode) */}
      {/* ------------------------------------------------------------- */}
      {!isFullscreen && (
        <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-2 bg-[#10081E] border-b border-purple-900/60 shrink-0">
          {/* Left: Back to Overview + Drawer Toggle + Title + Collection Rating + Active Page Rating */}
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={onCloseToOverview}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#1A0E30] hover:bg-purple-900 text-purple-100 border border-purple-800/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <ArrowLeft size={14} />
              <span>Overview</span>
            </button>

            <button
              type="button"
              onClick={() => setDrawerOpen((o) => !o)}
              aria-expanded={drawerOpen}
              aria-label="Toggle thumbnail sidebar drawer"
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                drawerOpen
                  ? 'bg-[#7C3AED] text-white border-[#C084FC]'
                  : 'bg-[#1A0E30] text-purple-200 border-purple-800/60 hover:border-purple-700'
              }`}
            >
              <PanelLeft size={14} />
              <span>
                Pages ({currentPage}/{totalPages})
              </span>
            </button>

            <div className="hidden lg:flex items-center gap-3 min-w-0">
              <h1 className="text-sm font-display font-semibold text-purple-50 truncate max-w-xs">
                {item.title}
              </h1>
              <div className="flex items-center gap-1 text-xs text-purple-300/80">
                <span className="text-[10px] font-mono uppercase tracking-wider text-purple-400/80">Vault:</span>
                <StarRating
                  rating={item.rating}
                  onChange={(r) => onRate(item.id, r)}
                  size="sm"
                  itemTitle={item.title}
                />
              </div>
            </div>

            {/* Current Page Star Rating */}
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-[#080410] border border-purple-900/60 rounded-lg shrink-0">
              <span className="text-[11px] font-mono text-[#C084FC] font-semibold whitespace-nowrap">
                P.{currentPage} Star:
              </span>
              <StarRating
                rating={activePageObj?.rating || 0}
                onChange={(r) => onRatePage?.(item.id, currentPage, r)}
                size="sm"
                itemTitle={`Page ${currentPage} rating`}
              />
            </div>
          </div>

          {/* Center: Display Fit Modes + Zoom */}
          <div className="flex flex-wrap items-center gap-2">
            <div
              className="flex items-center gap-1 bg-[#080410] border border-purple-900/60 rounded-lg p-1"
              role="group"
              aria-label="Reader display fit modes"
            >
              <button
                type="button"
                onClick={() => setFitMode('width')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  fitMode === 'width'
                    ? 'bg-[#7C3AED] text-white'
                    : 'text-purple-300/80 hover:text-white'
                }`}
              >
                Fit Width
              </button>
              <button
                type="button"
                onClick={() => setFitMode('height')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  fitMode === 'height'
                    ? 'bg-[#7C3AED] text-white'
                    : 'text-purple-300/80 hover:text-white'
                }`}
              >
                Fit Height
              </button>
              <button
                type="button"
                onClick={() => setFitMode('original')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  fitMode === 'original'
                    ? 'bg-[#7C3AED] text-white'
                    : 'text-purple-300/80 hover:text-white'
                }`}
              >
                Original Size
              </button>
              <button
                type="button"
                onClick={() => setFitMode('double')}
                className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  fitMode === 'double'
                    ? 'bg-[#7C3AED] text-white'
                    : 'text-purple-300/80 hover:text-white'
                }`}
              >
                <Columns size={12} />
                <span>Double-Page</span>
              </button>
            </div>

            {/* Reader Zoom Controls */}
            <div className="flex items-center gap-1 bg-[#080410] border border-purple-900/60 rounded-lg p-1">
              <button
                type="button"
                onClick={() =>
                  setReaderZoom((z) => Math.max(0.5, Number((z - 0.2).toFixed(2))))
                }
                aria-label="Zoom out reader"
                className="p-1 text-purple-200 hover:text-white rounded cursor-pointer"
              >
                <ZoomOut size={14} />
              </button>
              <button
                type="button"
                onClick={() => setReaderZoom(1)}
                className="px-1.5 text-xs font-mono-tabular text-purple-100 cursor-pointer"
              >
                {Math.round(readerZoom * 100)}%
              </button>
              <button
                type="button"
                onClick={() =>
                  setReaderZoom((z) => Math.min(3, Number((z + 0.2).toFixed(2))))
                }
                aria-label="Zoom in reader"
                className="p-1 text-purple-200 hover:text-white rounded cursor-pointer"
              >
                <ZoomIn size={14} />
              </button>
            </div>
          </div>

          {/* Right: Reading Direction + Slideshow + Night Invert + Fullscreen */}
          <div className="flex items-center gap-2">
            <div
              className="flex items-center gap-1 bg-[#080410] border border-purple-900/60 rounded-lg p-1"
              role="group"
              aria-label="Reading direction"
            >
              <button
                type="button"
                onClick={() => setDirection('ltr')}
                className={`px-2 py-1 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  direction === 'ltr'
                    ? 'bg-[#9333EA] text-white'
                    : 'text-purple-300/80 hover:text-white'
                }`}
              >
                LTR →
              </button>
              <button
                type="button"
                onClick={() => setDirection('rtl')}
                className={`px-2 py-1 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  direction === 'rtl'
                    ? 'bg-[#9333EA] text-white'
                    : 'text-purple-300/80 hover:text-white'
                }`}
              >
                ← RTL
              </button>
              <button
                type="button"
                onClick={() => setDirection('vertical')}
                className={`inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  direction === 'vertical'
                    ? 'bg-[#9333EA] text-white'
                    : 'text-purple-300/80 hover:text-white'
                }`}
              >
                <ScrollText size={12} />
                <span>Scroll</span>
              </button>
            </div>

            {/* Slideshow play/pause & speed selector */}
            <div className="flex items-center gap-1 bg-[#1A0E30] border border-purple-800/60 rounded-lg p-0.5">
              <button
                type="button"
                onClick={() => setSlideshowPlaying((s) => !s)}
                className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  slideshowPlaying
                    ? 'bg-[#7C3AED] text-white'
                    : 'text-purple-200 hover:text-white'
                }`}
              >
                {slideshowPlaying ? <Pause size={13} /> : <Play size={13} />}
                <span>Slide</span>
              </button>
              <select
                aria-label="Slideshow speed"
                value={slideshowSpeed}
                onChange={(e) => setSlideshowSpeed(Number(e.target.value))}
                className="bg-[#0D0618] text-purple-200 text-xs px-1.5 py-1 rounded border border-purple-900/60 cursor-pointer focus:outline-none"
              >
                <option value={1}>1s</option>
                <option value={2}>2s</option>
                <option value={3}>3s</option>
                <option value={4}>4s</option>
                <option value={5}>5s</option>
                <option value={7}>7s</option>
                <option value={10}>10s</option>
              </select>
            </div>

            {/* Night Invert Toggle */}
            <button
              type="button"
              onClick={() => setReaderInvert((v) => !v)}
              title="Night Reading Invert Mode"
              className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                readerInvert
                  ? 'bg-[#7C3AED] text-white border-[#C084FC]'
                  : 'bg-[#1A0E30] text-purple-200 border-purple-800/60 hover:text-white'
              }`}
            >
              {readerInvert ? <Moon size={15} /> : <Sun size={15} />}
            </button>

            {/* Fullscreen Button */}
            <button
              type="button"
              onClick={toggleFullscreen}
              aria-label="Toggle reader fullscreen"
              className="p-2 bg-[#1A0E30] border border-purple-800/60 rounded-lg text-purple-200 hover:text-white transition-colors cursor-pointer"
            >
              <Maximize2 size={15} />
            </button>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* Floating Auto-Hiding Controls for Buttonless Fullscreen Mode   */}
      {/* ------------------------------------------------------------- */}
      {isFullscreen && (
        <div
          className={`absolute top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-3 bg-[#0B0516]/90 border-b border-purple-900/60 backdrop-blur-md shadow-2xl transition-opacity duration-300 ${
            fullscreenControlsVisible
              ? 'opacity-100 pointer-events-auto'
              : 'opacity-0 pointer-events-none'
          }`}
        >
          {/* Left: Exit Fullscreen + Page / Total + Active Page Rating */}
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={toggleFullscreen}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-[#7C3AED] hover:bg-[#8B5CF6] text-white rounded-lg transition-colors cursor-pointer shadow-lg"
            >
              <Minimize2 size={14} />
              <span>Exit Fullscreen</span>
            </button>

            <span className="text-xs font-mono font-medium text-purple-200">
              Page {currentPage} of {totalPages}
            </span>

            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-[#120A20] border border-purple-800/60 rounded-lg">
              <span className="text-[11px] font-mono text-[#C084FC]">Rate Page:</span>
              <StarRating
                rating={activePageObj?.rating || 0}
                onChange={(r) => onRatePage?.(item.id, currentPage, r)}
                size="sm"
                itemTitle={`Page ${currentPage}`}
              />
            </div>
          </div>

          {/* Center: View Modes that stay active when entering/exiting fullscreen */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-[#080410] border border-purple-900/60 rounded-lg p-1">
              <button
                type="button"
                onClick={() => setFitMode('height')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                  fitMode === 'height' ? 'bg-[#7C3AED] text-white' : 'text-purple-300/80 hover:text-white'
                }`}
              >
                Fit Height
              </button>
              <button
                type="button"
                onClick={() => setFitMode('width')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                  fitMode === 'width' ? 'bg-[#7C3AED] text-white' : 'text-purple-300/80 hover:text-white'
                }`}
              >
                Fit Width
              </button>
              <button
                type="button"
                onClick={() => setFitMode('original')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                  fitMode === 'original' ? 'bg-[#7C3AED] text-white' : 'text-purple-300/80 hover:text-white'
                }`}
              >
                Original
              </button>
              <button
                type="button"
                onClick={() => setFitMode('double')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                  fitMode === 'double' ? 'bg-[#7C3AED] text-white' : 'text-purple-300/80 hover:text-white'
                }`}
              >
                Double
              </button>
            </div>

            <div className="flex items-center gap-1 bg-[#080410] border border-purple-900/60 rounded-lg p-1">
              <button
                type="button"
                onClick={() => setDirection('ltr')}
                className={`px-2 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                  direction === 'ltr' ? 'bg-[#9333EA] text-white' : 'text-purple-300/80 hover:text-white'
                }`}
              >
                LTR
              </button>
              <button
                type="button"
                onClick={() => setDirection('rtl')}
                className={`px-2 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                  direction === 'rtl' ? 'bg-[#9333EA] text-white' : 'text-purple-300/80 hover:text-white'
                }`}
              >
                RTL
              </button>
              <button
                type="button"
                onClick={() => setDirection('vertical')}
                className={`px-2 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                  direction === 'vertical' ? 'bg-[#9333EA] text-white' : 'text-purple-300/80 hover:text-white'
                }`}
              >
                Scroll
              </button>
            </div>
          </div>

          {/* Right: Slideshow + Invert */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setSlideshowPlaying((s) => !s)}
              className={`inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                slideshowPlaying
                  ? 'bg-[#7C3AED] text-white border-[#C084FC]'
                  : 'bg-[#1A0E30] text-purple-200 border-purple-800/60 hover:text-white'
              }`}
            >
              {slideshowPlaying ? <Pause size={13} /> : <Play size={13} />}
              <span>{slideshowPlaying ? 'Pause' : 'Slideshow'}</span>
            </button>
            <select
              aria-label="Fullscreen slideshow speed"
              value={slideshowSpeed}
              onChange={(e) => setSlideshowSpeed(Number(e.target.value))}
              className="bg-[#0D0618] text-purple-200 text-xs px-2 py-1.5 rounded-lg border border-purple-900/60 cursor-pointer focus:outline-none"
            >
              <option value={1}>1s</option>
              <option value={2}>2s</option>
              <option value={3}>3s</option>
              <option value={4}>4s</option>
              <option value={5}>5s</option>
              <option value={7}>7s</option>
              <option value={10}>10s</option>
            </select>
            <button
              type="button"
              onClick={() => setReaderInvert((v) => !v)}
              className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                readerInvert
                  ? 'bg-[#7C3AED] text-white border-[#C084FC]'
                  : 'bg-[#1A0E30] text-purple-200 border-purple-800/60 hover:text-white'
              }`}
            >
              {readerInvert ? <Moon size={14} /> : <Sun size={14} />}
            </button>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* Main Reader Stage: Thumbnail Drawer + Viewport               */}
      {/* ------------------------------------------------------------- */}
      <div className="flex-1 flex min-h-0 overflow-hidden relative">
        {/* Quick Thumbnail Sidebar Drawer */}
        {drawerOpen && !isFullscreen && (
          <aside
            aria-label="Reader Page Thumbnails"
            className="w-52 bg-[#0D0618] border-r border-purple-900/60 overflow-y-auto p-3 space-y-2.5 shrink-0"
          >
            <div className="text-[11px] font-mono text-purple-300/80 px-1 flex items-center justify-between">
              <span>THUMBNAIL INDEX</span>
              <span>{totalPages} PLATES</span>
            </div>
            {pages.map((p) => {
              const isCurrent =
                p.pageNumber === currentPage ||
                (fitMode === 'double' && p.pageNumber === currentPage + 1);
              const isRead = isComic && readSet.has(p.pageNumber);
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setCurrentPage(p.pageNumber)}
                  aria-label={`Jump to Page ${p.pageNumber}`}
                  className={`w-full text-left rounded-lg overflow-hidden border transition-all cursor-pointer ${
                    isCurrent
                      ? 'border-[#C084FC] ring-1 ring-[#C084FC] bg-[#1F0F3A]'
                      : 'border-purple-900/50 bg-[#120A20] hover:border-purple-700'
                  }`}
                >
                  <div className="aspect-[3/4] bg-[#080410] overflow-hidden">
                    <img
                      src={p.url}
                      alt={`Page ${p.pageNumber}`}
                      referrerPolicy="no-referrer"
                      className={`w-full h-full object-cover ${
                        panicBlur ? 'blur-lg' : ''
                      }`}
                    />
                  </div>
                  <div className="px-2.5 py-1.5 flex items-center justify-between text-[11px] font-mono-tabular">
                    <span
                      className={
                        isCurrent
                          ? 'text-[#C084FC] font-semibold'
                          : 'text-purple-200'
                      }
                    >
                      Page {String(p.pageNumber).padStart(2, '0')}
                    </span>
                    <span className="text-purple-400/70">
                      {p.rating ? `★ ${p.rating}` : isRead ? 'READ' : p.format}
                    </span>
                  </div>
                </button>
              );
            })}
          </aside>
        )}

        {/* Primary Reading Canvas */}
        <div className="relative flex-1 overflow-auto flex flex-col items-center justify-center bg-[#05020a]">
          {direction === 'vertical' ? (
            /* Vertical Webtoon Continuous Scroll Mode */
            <div
              className={`w-full flex flex-col items-center py-6 gap-4 ${
                isFullscreen ? 'h-full overflow-y-auto' : ''
              }`}
              style={{ transform: `scale(${readerZoom})`, transformOrigin: 'top center' }}
            >
              {pages.map((p) => (
                <div
                  key={p.id}
                  onMouseEnter={() => setCurrentPage(p.pageNumber)}
                  className={
                    fitMode === 'width'
                      ? 'w-full max-w-4xl px-4'
                      : fitMode === 'original'
                      ? 'w-auto'
                      : isFullscreen
                      ? 'h-screen max-w-full'
                      : 'h-[85vh]'
                  }
                >
                  <img
                    src={p.url}
                    alt={`Page ${p.pageNumber}`}
                    referrerPolicy="no-referrer"
                    style={imageFilterStyle}
                    className={`${
                      fitMode === 'width'
                        ? 'w-full h-auto'
                        : fitMode === 'original'
                        ? 'max-w-none'
                        : isFullscreen
                        ? 'h-full w-auto mx-auto object-contain'
                        : 'h-full w-auto mx-auto object-contain'
                    } rounded border border-purple-900/60 shadow-2xl ${
                      panicBlur ? 'blur-2xl' : ''
                    }`}
                  />
                </div>
              ))}
            </div>
          ) : (
            /* Horizontal Paginated Flip Mode (LTR / RTL & Single / Double Spread) */
            <div className="flex-1 w-full h-full flex items-center justify-center p-2 sm:p-4 min-h-0 relative">
              {/* Left Flip Button (hidden in buttonless fullscreen unless hovered) */}
              {!isFullscreen && (
                <button
                  type="button"
                  onClick={direction === 'rtl' ? goNextPage : goPrevPage}
                  disabled={
                    direction === 'rtl'
                      ? currentPage >= totalPages
                      : currentPage <= 1
                  }
                  aria-label={direction === 'rtl' ? 'Next page' : 'Previous page'}
                  className="p-3 mr-3 bg-[#120A20]/90 hover:bg-[#7C3AED] disabled:opacity-25 text-white border border-purple-800/70 rounded-full transition-colors cursor-pointer shrink-0 z-10"
                >
                  <ChevronLeft size={22} />
                </button>
              )}

              {/* In Fullscreen: Left and Right Invisible Click Zones for Seamless Navigation */}
              {isFullscreen && (
                <>
                  <div
                    onClick={direction === 'rtl' ? goNextPage : goPrevPage}
                    className="absolute left-0 top-0 bottom-0 w-1/4 z-20 cursor-w-resize"
                    title="Click left side to go back"
                  />
                  <div
                    onClick={direction === 'rtl' ? goPrevPage : goNextPage}
                    className="absolute right-0 top-0 bottom-0 w-1/4 z-20 cursor-e-resize"
                    title="Click right side to go forward"
                  />
                </>
              )}

              {/* Page Plate(s) */}
              <div
                style={{
                  transform: `scale(${readerZoom})`,
                  ...imageFilterStyle,
                }}
                className={`flex items-center justify-center gap-3 transition-transform duration-100 ${
                  direction === 'rtl' ? 'flex-row-reverse' : 'flex-row'
                } max-h-full max-w-full overflow-hidden`}
              >
                {activePageObj && (
                  <img
                    src={activePageObj.url}
                    alt={`Page ${activePageObj.pageNumber}`}
                    referrerPolicy="no-referrer"
                    className={`${
                      fitMode === 'width'
                        ? 'w-full max-w-5xl h-auto'
                        : fitMode === 'original'
                        ? 'max-w-none max-h-none'
                        : fitMode === 'double'
                        ? isFullscreen
                          ? 'max-h-screen w-auto max-w-[49vw]'
                          : 'max-h-[80vh] w-auto max-w-[45vw]'
                        : isFullscreen
                        ? 'max-h-screen max-w-screen object-contain'
                        : 'max-h-[82vh] w-auto max-w-[85vw]'
                    } object-contain rounded border ${
                      isFullscreen ? 'border-transparent shadow-none' : 'border-purple-900/60 shadow-2xl'
                    } ${panicBlur ? 'blur-2xl' : ''}`}
                  />
                )}

                {secondSpreadPageObj && (
                  <img
                    src={secondSpreadPageObj.url}
                    alt={`Page ${secondSpreadPageObj.pageNumber}`}
                    referrerPolicy="no-referrer"
                    className={`${
                      isFullscreen
                        ? 'max-h-screen w-auto max-w-[49vw]'
                        : 'max-h-[80vh] w-auto max-w-[45vw]'
                    } object-contain rounded border ${
                      isFullscreen ? 'border-transparent shadow-none' : 'border-purple-900/60 shadow-2xl'
                    } ${panicBlur ? 'blur-2xl' : ''}`}
                  />
                )}
              </div>

              {/* Right Flip Button (hidden in buttonless fullscreen) */}
              {!isFullscreen && (
                <button
                  type="button"
                  onClick={direction === 'rtl' ? goPrevPage : goNextPage}
                  disabled={
                    direction === 'rtl'
                      ? currentPage <= 1
                      : currentPage >= totalPages
                  }
                  aria-label={direction === 'rtl' ? 'Previous page' : 'Next page'}
                  className="p-3 ml-3 bg-[#120A20]/90 hover:bg-[#7C3AED] disabled:opacity-25 text-white border border-purple-800/70 rounded-full transition-colors cursor-pointer shrink-0 z-10"
                >
                  <ChevronRight size={22} />
                </button>
              )}
            </div>
          )}

          {/* Bottom Scrubber & Reading Status Bar (Hidden in buttonless fullscreen mode) */}
          {!isFullscreen && (
            <div className="w-full px-6 py-2.5 bg-[#10081E] border-t border-purple-900/60 flex items-center justify-between gap-4 shrink-0">
              <div className="flex items-center gap-2 text-xs font-mono-tabular text-purple-100 whitespace-nowrap shrink-0">
                <BookOpen size={13} className="text-[#C084FC]" />
                <span>
                  Page {currentPage}
                  {secondSpreadPageObj ? `–${secondSpreadPageObj.pageNumber}` : ''}{' '}
                  of {totalPages}
                </span>
              </div>

              <input
                type="range"
                min={1}
                max={Math.max(1, totalPages)}
                value={currentPage}
                onChange={(e) => setCurrentPage(Number(e.target.value))}
                aria-label="Page scrubber"
                className="flex-1 max-w-xl h-1.5 bg-purple-950 rounded-lg accent-[#A855F7] cursor-pointer"
              />

              {isComic && comicProgress && (
                <div className="text-xs font-mono-tabular text-[#C084FC] whitespace-nowrap shrink-0">
                  Read: {comicProgress.readCount}/{totalPages} ({comicProgress.percent}%)
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
