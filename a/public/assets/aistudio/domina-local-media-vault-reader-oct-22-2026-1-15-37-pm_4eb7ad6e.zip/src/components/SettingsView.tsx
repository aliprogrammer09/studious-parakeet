import React, { useEffect, useRef, useState } from 'react';
import {
  BookOpen,
  CheckCircle2,
  Code2,
  Database,
  Download,
  FolderOpen,
  FolderPlus,
  HardDrive,
  Keyboard,
  Palette,
  PowerOff,
  RefreshCw,
  ShieldAlert,
  Sliders,
  Trash2,
  Upload,
} from 'lucide-react';
import {
  AppearanceConfig,
  DirectoryConfig,
  MediaItem,
  MediaType,
  ReaderDirection,
  ReaderFitMode,
} from '../types/media';
import { DirectoryPickerModal } from './DirectoryPickerModal';

interface SettingsViewProps {
  directories: DirectoryConfig;
  appearance: AppearanceConfig;
  mediaItems: MediaItem[];
  onUpdateDirectories: (next: DirectoryConfig) => Promise<void>;
  onUpdateAppearance: (next: AppearanceConfig) => Promise<void>;
  onTriggerServerScan: (customDirs?: DirectoryConfig) => Promise<number>;
  onImportLocalFiles: (
    files: FileList,
    type: MediaType,
    collectionName?: string
  ) => void;
  onExportDatabase: () => void;
  onImportDatabaseJson: (jsonString: string) => Promise<boolean>;
  onClearLibrary: () => Promise<void>;
  onPanicClose: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  directories,
  appearance,
  mediaItems,
  onUpdateDirectories,
  onUpdateAppearance,
  onTriggerServerScan,
  onImportLocalFiles,
  onExportDatabase,
  onImportDatabaseJson,
  onClearLibrary,
  onPanicClose,
}) => {
  const [activeTab, setActiveTab] = useState<
    'general' | 'shortcuts' | 'architecture'
  >('general');
  const [dirDrafts, setDirDrafts] = useState<DirectoryConfig>(directories);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanStatusText, setScanStatusText] = useState<string | null>(null);
  const [dbFeedback, setDbFeedback] = useState<string | null>(null);

  useEffect(() => {
    setDirDrafts(directories);
  }, [directories]);

  // Server Directory Browser Modal state
  const [pickerTarget, setPickerTarget] = useState<{
    key: keyof Pick<
      DirectoryConfig,
      'imagesPath' | 'videosPath' | 'comicsPath' | 'imageSetsPath'
    >;
    label: string;
  } | null>(null);

  const jsonInputRef = useRef<HTMLInputElement | null>(null);
  const folderInputRefs = {
    image: useRef<HTMLInputElement | null>(null),
    video: useRef<HTMLInputElement | null>(null),
    comic: useRef<HTMLInputElement | null>(null),
    imageset: useRef<HTMLInputElement | null>(null),
  };

  const handleRealLibraryRescan = async () => {
    if (isScanning) return;
    setIsScanning(true);
    setScanProgress(25);
    setScanStatusText('Scanning configured filesystem directories on disk...');

    try {
      await onUpdateDirectories(dirDrafts);
      setScanProgress(65);
      setScanStatusText(
        'Parsing subfolder collections & extracting dimensions...'
      );
      const totalFound = await onTriggerServerScan(dirDrafts);
      setScanProgress(100);
      setScanStatusText(
        `Filesystem scan complete — ${totalFound} media items indexed from disk.`
      );
    } catch (err) {
      setScanStatusText(
        `Scan error: ${err instanceof Error ? err.message : 'Unknown error'}`
      );
    } finally {
      setIsScanning(false);
    }
  };

  const handleJsonUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const ok = await onImportDatabaseJson(String(reader.result || ''));
      setDbFeedback(
        ok
          ? 'Database backup imported and persisted to server.'
          : 'Invalid JSON schema — could not import backup.'
      );
      window.setTimeout(() => setDbFeedback(null), 4000);
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const directoryFields: Array<{
    key: 'imagesPath' | 'videosPath' | 'comicsPath' | 'imageSetsPath';
    label: string;
    type: MediaType;
  }> = [
    {
      key: 'imagesPath',
      label: 'Images Root Directory (Recursive)',
      type: 'image',
    },
    {
      key: 'videosPath',
      label: 'Videos Root Directory (Recursive)',
      type: 'video',
    },
    {
      key: 'comicsPath',
      label: 'Comics Library Directory (Subfolder per Comic)',
      type: 'comic',
    },
    {
      key: 'imageSetsPath',
      label: 'Image Sets Directory (Subfolder per Set)',
      type: 'imageset',
    },
  ];

  const shortcutGroups = [
    {
      title: 'Global & Privacy Shortcuts',
      items: [
        { keys: 'Ctrl + D', action: 'Panic Close (immediately closes this tab/page)' },
        { keys: 'Ctrl + K / Cmd + K', action: 'Open Global Quick Search modal' },
        { keys: 'Shift + L', action: 'Engage / disengage full-screen Privacy Lock' },
        { keys: '1 – 5', action: 'Assign 1 to 5 star rating to active item' },
      ],
    },
    {
      title: 'Image Details Inspector',
      items: [
        { keys: 'Mouse Wheel', action: 'Smooth zoom in and zoom out (40% – 600%)' },
        { keys: 'Left Click + Drag', action: 'Pan around zoomed image canvas' },
        { keys: '← / → Arrows', action: 'Navigate to previous or next image' },
        { keys: 'F', action: 'Toggle pure fullscreen image view (hides all UI)' },
        { keys: 'R', action: 'Rotate image 90° clockwise' },
        { keys: '0', action: 'Reset zoom, pan, and rotation to default' },
        { keys: 'Esc', action: 'Exit fullscreen or return to gallery' },
      ],
    },
    {
      title: 'Video Studio Player',
      items: [
        { keys: 'Spacebar', action: 'Play / Pause video stream' },
        { keys: '← / → Arrows', action: 'Seek backward / forward by 5 seconds' },
        { keys: 'F', action: 'Toggle fullscreen video (hover bottom edge for controls)' },
        { keys: 'L', action: 'Toggle infinite video loop' },
        { keys: '1 – 5', action: 'Rate current video inline' },
      ],
    },
    {
      title: 'Comics & Image Sets Reader',
      items: [
        { keys: '← / → Arrows', action: 'Flip to previous or next page (respects LTR / RTL)' },
        { keys: 'W', action: 'Switch display mode to Fit to Width' },
        { keys: 'H', action: 'Switch display mode to Fit to Height' },
        { keys: 'D', action: 'Switch display mode to Double-Page Spread' },
        { keys: 'F', action: 'Toggle fullscreen reader mode' },
        { keys: 'Esc', action: 'Exit fullscreen or return to collection overview' },
      ],
    },
  ];

  return (
    <div className="max-w-[1440px] mx-auto px-6 py-8 space-y-8">
      {/* Header & Section Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-purple-900/60 pb-5">
        <div>
          <h1 className="text-2xl md:text-3xl font-display font-semibold text-purple-50">
            Settings
          </h1>
          <p className="text-sm text-purple-300/75 mt-1">
            Configure local media storage directories, appearance & grid density, reader defaults, keyboard shortcuts, and database backups.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1 bg-[#120A20] border border-purple-900/60 rounded-xl p-1 self-start">
          <button
            type="button"
            onClick={() => setActiveTab('general')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'general'
                ? 'bg-[#7C3AED] text-white'
                : 'text-purple-300 hover:text-white'
            }`}
          >
            Settings & Appearance
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('shortcuts')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'shortcuts'
                ? 'bg-[#7C3AED] text-white'
                : 'text-purple-300 hover:text-white'
            }`}
          >
            <Keyboard size={13} />
            <span>Shortcuts Reference</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('architecture')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'architecture'
                ? 'bg-[#7C3AED] text-white'
                : 'text-purple-300 hover:text-white'
            }`}
          >
            <Code2 size={13} />
            <span>Architecture Blueprint</span>
          </button>
        </div>
      </div>

      {activeTab === 'general' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column (7 cols): Local Directory Paths, Reader Defaults & Database */}
          <div className="lg:col-span-7 space-y-6">
            <section className="bg-[#120A20]/95 border border-purple-900/60 domina-glow-card rounded-2xl p-6 space-y-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <HardDrive size={18} className="text-[#C084FC]" />
                  <h2 className="text-base font-display font-semibold text-purple-50">
                    Local Storage Directories
                  </h2>
                </div>
                <span className="text-xs font-mono-tabular text-purple-300/75">
                  {directories.lastIndexedAt
                    ? `Last Indexed: ${new Date(
                        directories.lastIndexedAt
                      ).toLocaleTimeString()}`
                    : 'Not yet indexed'}
                </span>
              </div>

              <p className="text-xs text-purple-300/75 leading-relaxed">
                Point Domina to any local directory paths on the machine using <strong>Browse Disk</strong>, or click <strong>Mount Folder</strong> to import local files/subfolders directly into the vault directory and index them.
              </p>

              <div className="space-y-4">
                {directoryFields.map((entry) => (
                  <div key={entry.key} className="space-y-1.5">
                    <label
                      htmlFor={`dir-${entry.key}`}
                      className="block text-xs font-medium text-purple-200"
                    >
                      {entry.label}
                    </label>
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        id={`dir-${entry.key}`}
                        type="text"
                        value={dirDrafts[entry.key]}
                        onChange={(e) => {
                          const nextVal = e.target.value;
                          setDirDrafts((prev) => ({
                            ...prev,
                            [entry.key]: nextVal,
                          }));
                        }}
                        onBlur={() => {
                          if (dirDrafts[entry.key] !== directories[entry.key]) {
                            onUpdateDirectories(dirDrafts);
                          }
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            onUpdateDirectories(dirDrafts);
                          }
                        }}
                        className="flex-1 min-w-[220px] px-3 py-2 text-xs font-mono bg-[#080410] border border-purple-900/60 rounded-lg text-purple-50 focus:outline-none focus:border-[#A855F7]"
                      />

                      <button
                        type="button"
                        onClick={() =>
                          setPickerTarget({
                            key: entry.key,
                            label: entry.label,
                          })
                        }
                        className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#1A0E30] hover:bg-purple-900 text-purple-100 border border-purple-800/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
                      >
                        <FolderOpen size={14} className="text-[#C084FC]" />
                        <span>Browse Disk</span>
                      </button>

                      <input
                        ref={folderInputRefs[entry.type]}
                        type="file"
                        multiple
                        // @ts-expect-error webkitdirectory support
                        webkitdirectory=""
                        directory=""
                        className="hidden"
                        onChange={(e) => {
                          if (e.target.files && e.target.files.length > 0) {
                            onImportLocalFiles(e.target.files, entry.type);
                            e.target.value = '';
                          }
                        }}
                      />
                      <button
                        type="button"
                        onClick={() => folderInputRefs[entry.type].current?.click()}
                        className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#080410] hover:bg-purple-950 text-purple-200 border border-purple-900/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
                      >
                        <FolderPlus size={14} className="text-[#A855F7]" />
                        <span>Mount Folder</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Auto-Scan on Startup Toggle & Rescan Button */}
              <div className="pt-4 border-t border-purple-900/50 space-y-4">
                <label className="flex items-center justify-between gap-3 cursor-pointer">
                  <div>
                    <div className="text-xs font-semibold text-purple-100">
                      Automatically Scan Directories on Startup
                    </div>
                    <div className="text-xs text-purple-300/70">
                      Index new files in configured vault paths whenever Domina starts
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={dirDrafts.autoScanOnStartup}
                    onChange={(e) => {
                      const next = {
                        ...dirDrafts,
                        autoScanOnStartup: e.target.checked,
                      };
                      setDirDrafts(next);
                      onUpdateDirectories(next);
                    }}
                    className="w-4 h-4 accent-[#8B5CF6] rounded cursor-pointer"
                  />
                </label>

                <div className="flex items-center justify-between gap-4 pt-2 border-t border-purple-900/40">
                  <div>
                    <div className="text-xs font-semibold text-purple-100">
                      Filesystem Indexer & Subfolder Scanner
                    </div>
                    <div className="text-xs text-purple-300/70">
                      Scan configured directories on disk, parse image headers, and group Comic/Image Set subfolders.
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleRealLibraryRescan}
                    disabled={isScanning}
                    className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold bg-[#7C3AED] hover:bg-[#8B5CF6] disabled:opacity-60 text-white rounded-lg shadow-lg shadow-purple-950/60 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <RefreshCw
                      size={14}
                      className={isScanning ? 'animate-spin' : ''}
                    />
                    <span>
                      {isScanning
                        ? `Scanning (${scanProgress}%)`
                        : 'Rescan / Re-Index Library'}
                    </span>
                  </button>
                </div>

                {(isScanning || scanStatusText) && (
                  <div className="space-y-1.5 bg-[#080410] border border-purple-800/60 rounded-lg p-3">
                    <div className="flex items-center justify-between text-xs font-mono-tabular">
                      <span className="text-purple-100 flex items-center gap-1.5">
                        {scanProgress === 100 && (
                          <CheckCircle2 size={14} className="text-emerald-400" />
                        )}
                        {scanStatusText}
                      </span>
                      <span className="text-[#C084FC] font-semibold">
                        {scanProgress}%
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-purple-950 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-[#7C3AED] to-[#C084FC] transition-all duration-300"
                        style={{ width: `${scanProgress}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>
            </section>

            {/* Reader, Slideshow & Video Playback Defaults */}
            <section className="bg-[#120A20]/95 border border-purple-900/60 rounded-2xl p-6 space-y-5">
              <div className="flex items-center gap-2.5">
                <BookOpen size={18} className="text-[#C084FC]" />
                <h2 className="text-base font-display font-semibold text-purple-50">
                  Reader, Slideshow & Video Defaults
                </h2>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label
                    htmlFor="pref-reader-fit"
                    className="block text-xs font-medium text-purple-200"
                  >
                    Default Reader Fit Mode
                  </label>
                  <select
                    id="pref-reader-fit"
                    value={appearance.defaultReaderFit || 'height'}
                    onChange={(e) =>
                      onUpdateAppearance({
                        ...appearance,
                        defaultReaderFit: e.target.value as ReaderFitMode,
                      })
                    }
                    className="w-full bg-[#080410] border border-purple-900/60 rounded-lg px-3 py-2 text-xs text-purple-100 focus:outline-none focus:border-[#A855F7]"
                  >
                    <option value="height">Fit to Height</option>
                    <option value="width">Fit to Width</option>
                    <option value="original">Original Pixel Size</option>
                    <option value="double">Double-Page Spread</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label
                    htmlFor="pref-reader-dir"
                    className="block text-xs font-medium text-purple-200"
                  >
                    Default Reading Direction
                  </label>
                  <select
                    id="pref-reader-dir"
                    value={appearance.defaultReaderDirection || 'ltr'}
                    onChange={(e) =>
                      onUpdateAppearance({
                        ...appearance,
                        defaultReaderDirection: e.target
                          .value as ReaderDirection,
                      })
                    }
                    className="w-full bg-[#080410] border border-purple-900/60 rounded-lg px-3 py-2 text-xs text-purple-100 focus:outline-none focus:border-[#A855F7]"
                  >
                    <option value="ltr">Left to Right (LTR)</option>
                    <option value="rtl">Right to Left (Manga RTL)</option>
                    <option value="vertical">Webtoon Vertical Scroll</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label
                    htmlFor="pref-slideshow"
                    className="block text-xs font-medium text-purple-200"
                  >
                    Slideshow Interval
                  </label>
                  <select
                    id="pref-slideshow"
                    value={appearance.slideshowIntervalSeconds || 4}
                    onChange={(e) =>
                      onUpdateAppearance({
                        ...appearance,
                        slideshowIntervalSeconds: Number(e.target.value),
                      })
                    }
                    className="w-full bg-[#080410] border border-purple-900/60 rounded-lg px-3 py-2 text-xs text-purple-100 focus:outline-none focus:border-[#A855F7]"
                  >
                    <option value={2}>Every 2 Seconds</option>
                    <option value={3}>Every 3 Seconds</option>
                    <option value={4}>Every 4 Seconds</option>
                    <option value={6}>Every 6 Seconds</option>
                    <option value={10}>Every 10 Seconds</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-purple-900/40">
                <label className="flex items-center justify-between gap-2 p-3 bg-[#080410] border border-purple-900/50 rounded-xl cursor-pointer">
                  <span className="text-xs text-purple-100">
                    Loop Videos by Default
                  </span>
                  <input
                    type="checkbox"
                    checked={Boolean(appearance.defaultVideoLoop)}
                    onChange={(e) =>
                      onUpdateAppearance({
                        ...appearance,
                        defaultVideoLoop: e.target.checked,
                      })
                    }
                    className="w-4 h-4 accent-[#8B5CF6] rounded cursor-pointer"
                  />
                </label>

                <label className="flex items-center justify-between gap-2 p-3 bg-[#080410] border border-purple-900/50 rounded-xl cursor-pointer">
                  <span className="text-xs text-purple-100">
                    Auto-Play Next Video by Default
                  </span>
                  <input
                    type="checkbox"
                    checked={appearance.defaultAutoPlayNext ?? true}
                    onChange={(e) =>
                      onUpdateAppearance({
                        ...appearance,
                        defaultAutoPlayNext: e.target.checked,
                      })
                    }
                    className="w-4 h-4 accent-[#8B5CF6] rounded cursor-pointer"
                  />
                </label>
              </div>
            </section>

            {/* Database Backup / Export / Import / Clear */}
            <section className="bg-[#120A20]/95 border border-purple-900/60 rounded-2xl p-6 space-y-4">
              <div className="flex items-center gap-2.5">
                <Database size={18} className="text-[#C084FC]" />
                <h2 className="text-base font-display font-semibold text-purple-50">
                  Database Backup, Export & Clear
                </h2>
              </div>
              <p className="text-xs text-purple-300/75">
                Export all 5-star ratings, boolean tags, comic reading progress, favorites, and directory mappings (`vault/domina-db.json`) as a portable JSON snapshot, restore from backup, or clear the index.
              </p>

              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={onExportDatabase}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium bg-[#1A0E30] hover:bg-purple-900 text-purple-100 border border-purple-800/60 rounded-lg transition-colors cursor-pointer"
                >
                  <Download size={14} className="text-[#C084FC]" />
                  <span>Export Database JSON ({mediaItems.length} items)</span>
                </button>

                <input
                  ref={jsonInputRef}
                  type="file"
                  accept="application/json,.json"
                  className="hidden"
                  onChange={handleJsonUpload}
                />
                <button
                  type="button"
                  onClick={() => jsonInputRef.current?.click()}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium bg-[#1A0E30] hover:bg-purple-900 text-purple-100 border border-purple-800/60 rounded-lg transition-colors cursor-pointer"
                >
                  <Upload size={14} className="text-[#A855F7]" />
                  <span>Import Database JSON</span>
                </button>

                <button
                  type="button"
                  onClick={async () => {
                    await onClearLibrary();
                    setDbFeedback('Vault index cleared (0 items).');
                    window.setTimeout(() => setDbFeedback(null), 3500);
                  }}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-rose-300 hover:text-white hover:bg-rose-950/70 border border-rose-800/50 rounded-lg transition-colors cursor-pointer ml-auto"
                >
                  <Trash2 size={14} />
                  <span>Clear Indexed Vault</span>
                </button>
              </div>

              {dbFeedback && (
                <div className="p-2.5 bg-[#080410] border border-purple-800/60 rounded text-xs font-mono text-emerald-400">
                  {dbFeedback}
                </div>
              )}
            </section>
          </div>

          {/* Right Column (5 cols): Appearance & Grid Density + Panic Close */}
          <div className="lg:col-span-5 space-y-6">
            <section className="bg-[#120A20]/95 border border-purple-900/60 domina-glow-card rounded-2xl p-6 space-y-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Palette size={18} className="text-[#C084FC]" />
                  <h2 className="text-base font-display font-semibold text-purple-50">
                    Appearance & Grid Density
                  </h2>
                </div>
                <span className="text-[11px] font-mono text-[#C084FC]">
                  LIVE SYNC
                </span>
              </div>

              {/* Theme Color Preset */}
              <div className="space-y-2">
                <span className="block text-xs font-medium text-purple-200">
                  Purple & Accent Palette Preset
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {(
                    [
                      {
                        id: 'violet',
                        label: 'Royal Violet',
                        swatch: 'bg-[#8B5CF6]',
                      },
                      {
                        id: 'amethyst',
                        label: 'Amethyst Orchid',
                        swatch: 'bg-[#C084FC]',
                      },
                      {
                        id: 'indigo',
                        label: 'Midnight Indigo',
                        swatch: 'bg-[#6366F1]',
                      },
                      {
                        id: 'crimson',
                        label: 'Violet & Crimson',
                        swatch: 'bg-[#E11D48]',
                      },
                    ] as const
                  ).map((theme) => (
                    <button
                      key={theme.id}
                      type="button"
                      onClick={() =>
                        onUpdateAppearance({
                          ...appearance,
                          accentColor: theme.id,
                        })
                      }
                      aria-pressed={appearance.accentColor === theme.id}
                      className={`flex items-center gap-2 py-2 px-3 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                        appearance.accentColor === theme.id
                          ? 'bg-[#7C3AED] text-white border-[#C084FC]'
                          : 'bg-[#080410] text-purple-200 border-purple-900/60 hover:border-purple-700'
                      }`}
                    >
                      <span
                        className={`w-3 h-3 rounded-full ${theme.swatch} shrink-0`}
                      />
                      <span>{theme.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Accent Intensity Slider */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <label
                    htmlFor="accent-intensity"
                    className="text-purple-200 font-medium"
                  >
                    Purple Ambient & Border Glow Intensity
                  </label>
                  <span className="font-mono-tabular text-[#C084FC] font-semibold">
                    {appearance.accentIntensity}%
                  </span>
                </div>
                <input
                  id="accent-intensity"
                  type="range"
                  min={20}
                  max={100}
                  step={5}
                  value={appearance.accentIntensity}
                  onChange={(e) =>
                    onUpdateAppearance({
                      ...appearance,
                      accentIntensity: Number(e.target.value),
                    })
                  }
                  className="w-full h-1.5 bg-purple-950 rounded-lg accent-[#A855F7] cursor-pointer"
                />
              </div>

              {/* Gallery Grid Density Preset */}
              <div className="space-y-2">
                <span className="block text-xs font-medium text-purple-200">
                  Gallery Grid Density (Thumbnail Size)
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(
                    [
                      { id: 'ultra-compact', label: 'Ultra' },
                      { id: 'compact', label: 'Compact' },
                      { id: 'standard', label: 'Standard' },
                      { id: 'spacious', label: 'Spacious' },
                    ] as const
                  ).map((density) => (
                    <button
                      key={density.id}
                      type="button"
                      onClick={() =>
                        onUpdateAppearance({
                          ...appearance,
                          gridDensity: density.id,
                          gridColumns: 0,
                        })
                      }
                      aria-pressed={
                        appearance.gridDensity === density.id &&
                        !appearance.gridColumns
                      }
                      className={`py-2 px-2.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                        appearance.gridDensity === density.id &&
                        !appearance.gridColumns
                          ? 'bg-[#7C3AED] text-white border-[#C084FC]'
                          : 'bg-[#080410] text-purple-200 border-purple-900/60 hover:border-purple-700'
                      }`}
                    >
                      {density.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Exact Columns Per Row Override */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-purple-200">
                    Custom Columns Per Row
                  </span>
                  <span className="font-mono text-[#C084FC]">
                    {appearance.gridColumns && appearance.gridColumns > 0
                      ? `${appearance.gridColumns} Columns`
                      : `Auto (${appearance.gridDensity})`}
                  </span>
                </div>
                <div className="grid grid-cols-6 gap-1.5">
                  {[0, 2, 3, 4, 5, 6].map((cols) => (
                    <button
                      key={cols}
                      type="button"
                      onClick={() =>
                        onUpdateAppearance({
                          ...appearance,
                          gridColumns: cols,
                        })
                      }
                      aria-pressed={(appearance.gridColumns || 0) === cols}
                      className={`py-1.5 text-xs font-mono rounded-lg border transition-colors cursor-pointer ${
                        (appearance.gridColumns || 0) === cols
                          ? 'bg-[#8B5CF6] text-white border-[#C084FC]'
                          : 'bg-[#080410] text-purple-200 border-purple-900/60 hover:border-purple-700'
                      }`}
                    >
                      {cols === 0 ? 'Auto' : `${cols}x`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Default Thumbnail Aspect */}
              <div className="space-y-2">
                <span className="block text-xs font-medium text-purple-200">
                  Gallery Thumbnail Aspect Ratio
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {(['portrait', 'landscape', 'square'] as const).map(
                    (aspect) => (
                      <button
                        key={aspect}
                        type="button"
                        onClick={() =>
                          onUpdateAppearance({
                            ...appearance,
                            thumbnailAspect: aspect,
                          })
                        }
                        aria-pressed={appearance.thumbnailAspect === aspect}
                        className={`py-2 px-3 text-xs font-medium rounded-lg border capitalize transition-colors cursor-pointer ${
                          appearance.thumbnailAspect === aspect
                            ? 'bg-[#7C3AED] text-white border-[#C084FC]'
                            : 'bg-[#080410] text-purple-200 border-purple-900/60 hover:border-purple-700'
                        }`}
                      >
                        {aspect}
                      </button>
                    )
                  )}
                </div>
              </div>

              {/* Thumbnail Fit Mode & Card Spacing & Card Radius */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-purple-900/40">
                <div className="space-y-1">
                  <label
                    htmlFor="app-thumb-fit"
                    className="block text-xs font-medium text-purple-200"
                  >
                    Image Cropping
                  </label>
                  <select
                    id="app-thumb-fit"
                    value={appearance.thumbnailFit || 'cover'}
                    onChange={(e) =>
                      onUpdateAppearance({
                        ...appearance,
                        thumbnailFit: e.target.value as 'cover' | 'contain',
                      })
                    }
                    className="w-full bg-[#080410] border border-purple-900/60 rounded-lg px-2.5 py-2 text-xs text-purple-100"
                  >
                    <option value="cover">Cover (Fill Card)</option>
                    <option value="contain">Contain (Full Frame)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label
                    htmlFor="app-card-gap"
                    className="block text-xs font-medium text-purple-200"
                  >
                    Grid Spacing
                  </label>
                  <select
                    id="app-card-gap"
                    value={appearance.cardGap || 'standard'}
                    onChange={(e) =>
                      onUpdateAppearance({
                        ...appearance,
                        cardGap: e.target.value as
                          | 'tight'
                          | 'standard'
                          | 'relaxed',
                      })
                    }
                    className="w-full bg-[#080410] border border-purple-900/60 rounded-lg px-2.5 py-2 text-xs text-purple-100"
                  >
                    <option value="tight">Tight Gap</option>
                    <option value="standard">Standard Gap</option>
                    <option value="relaxed">Relaxed Gap</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label
                    htmlFor="app-card-radius"
                    className="block text-xs font-medium text-purple-200"
                  >
                    Corner Style
                  </label>
                  <select
                    id="app-card-radius"
                    value={appearance.cardRadius || 'rounded'}
                    onChange={(e) =>
                      onUpdateAppearance({
                        ...appearance,
                        cardRadius: e.target.value as
                          | 'sharp'
                          | 'rounded'
                          | 'lux',
                      })
                    }
                    className="w-full bg-[#080410] border border-purple-900/60 rounded-lg px-2.5 py-2 text-xs text-purple-100"
                  >
                    <option value="sharp">Sharp Corners</option>
                    <option value="rounded">Rounded Corners</option>
                    <option value="lux">Luxury Curved</option>
                  </select>
                </div>
              </div>

              {/* Viewport & Theme Personalization: Darkness & Border Style */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-purple-900/40">
                <div className="space-y-1">
                  <label
                    htmlFor="app-bg-darkness"
                    className="block text-xs font-medium text-purple-200"
                  >
                    Background Tone
                  </label>
                  <select
                    id="app-bg-darkness"
                    value={appearance.bgDarkness || 'obsidian'}
                    onChange={(e) =>
                      onUpdateAppearance({
                        ...appearance,
                        bgDarkness: e.target.value as 'pitch-black' | 'obsidian' | 'charcoal',
                      })
                    }
                    className="w-full bg-[#080410] border border-purple-900/60 rounded-lg px-2.5 py-2 text-xs text-purple-100"
                  >
                    <option value="pitch-black">Pitch Black (#000000)</option>
                    <option value="obsidian">Deep Obsidian Purple</option>
                    <option value="charcoal">Charcoal Violet</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label
                    htmlFor="app-border-style"
                    className="block text-xs font-medium text-purple-200"
                  >
                    Card Border Style
                  </label>
                  <select
                    id="app-border-style"
                    value={appearance.borderStyle || 'neon-glow'}
                    onChange={(e) =>
                      onUpdateAppearance({
                        ...appearance,
                        borderStyle: e.target.value as 'neon-glow' | 'minimal' | 'glass',
                      })
                    }
                    className="w-full bg-[#080410] border border-purple-900/60 rounded-lg px-2.5 py-2 text-xs text-purple-100"
                  >
                    <option value="neon-glow">Vibrant Neon Glow</option>
                    <option value="minimal">Minimal Accent</option>
                    <option value="glass">Frosted Glass</option>
                  </select>
                </div>
              </div>

              {/* Card Metadata & Animation Toggles */}
              <div className="space-y-2 pt-2 border-t border-purple-900/40">
                <div className="flex items-center gap-1.5 text-xs font-medium text-purple-200">
                  <Sliders size={13} className="text-[#C084FC]" />
                  <span>Gallery Card Elements</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <label className="flex items-center gap-2 p-2.5 bg-[#080410] border border-purple-900/50 rounded-lg cursor-pointer">
                    <input
                      type="checkbox"
                      checked={appearance.showCardRating ?? true}
                      onChange={(e) =>
                        onUpdateAppearance({
                          ...appearance,
                          showCardRating: e.target.checked,
                        })
                      }
                      className="accent-[#8B5CF6] cursor-pointer"
                    />
                    <span className="text-purple-100">Show 5-Star Rating</span>
                  </label>

                  <label className="flex items-center gap-2 p-2.5 bg-[#080410] border border-purple-900/50 rounded-lg cursor-pointer">
                    <input
                      type="checkbox"
                      checked={appearance.showCardSize ?? true}
                      onChange={(e) =>
                        onUpdateAppearance({
                          ...appearance,
                          showCardSize: e.target.checked,
                        })
                      }
                      className="accent-[#8B5CF6] cursor-pointer"
                    />
                    <span className="text-purple-100">Show File Size</span>
                  </label>

                  <label className="flex items-center gap-2 p-2.5 bg-[#080410] border border-purple-900/50 rounded-lg cursor-pointer">
                    <input
                      type="checkbox"
                      checked={appearance.showCardTags ?? true}
                      onChange={(e) =>
                        onUpdateAppearance({
                          ...appearance,
                          showCardTags: e.target.checked,
                        })
                      }
                      className="accent-[#8B5CF6] cursor-pointer"
                    />
                    <span className="text-purple-100">Show Tag Chips</span>
                  </label>

                  <label className="flex items-center gap-2 p-2.5 bg-[#080410] border border-purple-900/50 rounded-lg cursor-pointer">
                    <input
                      type="checkbox"
                      checked={appearance.hoverZoom ?? true}
                      onChange={(e) =>
                        onUpdateAppearance({
                          ...appearance,
                          hoverZoom: e.target.checked,
                        })
                      }
                      className="accent-[#8B5CF6] cursor-pointer"
                    />
                    <span className="text-purple-100">Hover Zoom Effect</span>
                  </label>
                </div>
              </div>
            </section>

            {/* Panic Close & Privacy Controls */}
            <section className="bg-[#120A20]/95 border border-purple-900/60 rounded-2xl p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <ShieldAlert size={18} className="text-rose-400" />
                  <h2 className="text-base font-display font-semibold text-purple-50">
                    Panic Close & Thumbnail Concealment
                  </h2>
                </div>
                <span className="text-xs font-mono text-[#C084FC]">
                  Hotkey: Ctrl + D
                </span>
              </div>

              <p className="text-xs text-purple-300/75 leading-relaxed">
                Press <strong>Ctrl + D</strong> anywhere or click <strong>Panic Close</strong> to immediately close this page tab without affecting other Chrome tabs. You can also toggle thumbnail blur below.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={onPanicClose}
                  className="inline-flex items-center justify-center gap-2 py-2.5 px-4 text-xs font-semibold bg-rose-900 hover:bg-rose-700 text-white border border-rose-600 rounded-lg transition-colors cursor-pointer"
                >
                  <PowerOff size={14} />
                  <span>Panic Close Page (Ctrl+D)</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    onUpdateAppearance({
                      ...appearance,
                      panicModeBlur: !appearance.panicModeBlur,
                    })
                  }
                  aria-pressed={appearance.panicModeBlur}
                  className={`py-2.5 px-4 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                    appearance.panicModeBlur
                      ? 'bg-[#7C3AED] text-white border-[#C084FC]'
                      : 'bg-[#080410] text-purple-200 border-purple-900/60 hover:border-purple-700'
                  }`}
                >
                  {appearance.panicModeBlur
                    ? 'Disable Thumbnail Blur'
                    : 'Enable Thumbnail Blur'}
                </button>
              </div>
            </section>
          </div>
        </div>
      ) : activeTab === 'shortcuts' ? (
        /* Keyboard Shortcuts & Mouse Controls Reference Tab (Exclusive location for shortcut explanations) */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {shortcutGroups.map((group) => (
            <section
              key={group.title}
              className="bg-[#120A20]/95 border border-purple-900/60 domina-glow-card rounded-2xl p-6 space-y-4"
            >
              <div className="flex items-center gap-2.5 border-b border-purple-900/50 pb-3">
                <Keyboard size={17} className="text-[#C084FC]" />
                <h2 className="text-base font-display font-semibold text-purple-50">
                  {group.title}
                </h2>
              </div>
              <div className="divide-y divide-purple-900/40">
                {group.items.map((sc) => (
                  <div
                    key={sc.keys}
                    className="py-2.5 flex items-center justify-between gap-4 text-xs"
                  >
                    <span className="text-purple-200">{sc.action}</span>
                    <kbd className="px-2.5 py-1 font-mono text-[11px] bg-[#080410] border border-purple-800/70 rounded text-[#C084FC] whitespace-nowrap shrink-0">
                      {sc.keys}
                    </kbd>
                  </div>
                ))}
              </div>
            </section>
          ))}
        </div>
      ) : (
        /* Architecture & SQLite / JSON Schema Reference Tab */
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <section className="bg-[#120A20]/95 border border-purple-900/60 rounded-2xl p-6 space-y-4">
            <h2 className="text-lg font-display font-semibold text-purple-50">
              1. Local-First Full-Stack Architecture
            </h2>
            <div className="space-y-3 text-xs text-purple-200/85 leading-relaxed">
              <p>
                <strong className="text-white">Backend Server (`server.ts`):</strong>{' '}
                Express + Node.js filesystem engine running on port 3000 with recursive directory walkers (`POST /api/scan`), interactive disk directory browser (`GET /api/fs/browse`), HTTP 206 byte-range media streaming (`GET /api/file`), direct binary file uploader (`POST /api/upload-raw`), and persistent disk storage (`vault/domina-db.json`).
              </p>
              <p>
                <strong className="text-white">Local Indexing & Subfolder Parser:</strong>{' '}
                Recursive directory scanner for single Images and Videos, paired with a Subfolder Collection Scanner for Comics and Image Sets where each subdirectory becomes a Comic/Set entity and its natural-sorted image files populate ordered pages.
              </p>
              <p>
                <strong className="text-white">Boolean Tag & Multi-Star Query Engine:</strong>{' '}
                Deterministic parser supporting `+include`, `-exclude`, and `tagA OR tagB` boolean clauses alongside concurrent multi-rating arrays (`rating IN (4, 5)`).
              </p>
            </div>
          </section>

          <section className="bg-[#120A20]/95 border border-purple-900/60 rounded-2xl p-6 space-y-4">
            <h2 className="text-lg font-display font-semibold text-purple-50">
              2. SQLite Relational Schema (DDL)
            </h2>
            <pre className="p-4 bg-[#080410] border border-purple-900/60 rounded-lg font-mono text-[11px] text-purple-200 overflow-x-auto leading-relaxed">
{`CREATE TABLE media_items (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL CHECK(type IN ('image','video','comic','imageset')),
  title TEXT NOT NULL,
  filename TEXT NOT NULL,
  local_path TEXT UNIQUE NOT NULL,
  folder_path TEXT NOT NULL,
  rating INTEGER DEFAULT 0 CHECK(rating BETWEEN 0 AND 5),
  is_favorite INTEGER DEFAULT 0,
  size_bytes INTEGER NOT NULL,
  format TEXT NOT NULL,
  width INTEGER,
  height INTEGER,
  duration_seconds REAL,
  page_count INTEGER DEFAULT 1,
  last_read_page INTEGER DEFAULT 1,
  read_pages_json TEXT DEFAULT '[]',
  date_added TEXT NOT NULL
);`}
            </pre>
          </section>
        </div>
      )}

      {/* Interactive Server Filesystem Directory Browser Modal */}
      <DirectoryPickerModal
        isOpen={pickerTarget !== null}
        title={pickerTarget ? `Select ${pickerTarget.label}` : 'Select Directory'}
        initialPath={
          pickerTarget ? dirDrafts[pickerTarget.key] : dirDrafts.imagesPath
        }
        onClose={() => setPickerTarget(null)}
        onSelectPath={async (newPath) => {
          if (!pickerTarget) return;
          const updated = {
            ...dirDrafts,
            [pickerTarget.key]: newPath,
          };
          setDirDrafts(updated);
          await onUpdateDirectories(updated);
          await onTriggerServerScan(updated);
        }}
      />
    </div>
  );
};
