import React, { useState } from 'react';
import { Star } from 'lucide-react';

interface StarRatingProps {
  rating: number;
  onChange?: (newRating: number) => void;
  size?: 'sm' | 'md' | 'lg';
  itemTitle?: string;
  readOnly?: boolean;
}

export const StarRating: React.FC<StarRatingProps> = ({
  rating,
  onChange,
  size = 'sm',
  itemTitle = 'media item',
  readOnly = false,
}) => {
  const [hoverRating, setHoverRating] = useState<number | null>(null);

  const iconSize = size === 'sm' ? 14 : size === 'md' ? 17 : 20;
  const displayRating = hoverRating !== null ? hoverRating : rating;

  return (
    <div
      className="inline-flex items-center gap-0.5 select-none"
      role="group"
      aria-label={`Rating for ${itemTitle}: ${rating} out of 5 stars`}
      onMouseLeave={() => setHoverRating(null)}
      onClick={(e) => e.stopPropagation()}
    >
      {[1, 2, 3, 4, 5].map((star) => {
        const isFilled = star <= displayRating;
        if (readOnly || !onChange) {
          return (
            <span key={star} className="inline-flex p-0.5">
              <Star
                size={iconSize}
                style={
                  isFilled
                    ? {
                        fill: 'var(--domina-star-fill, #A855F7)',
                        color: 'var(--domina-star-stroke, #C084FC)',
                      }
                    : undefined
                }
                className={
                  isFilled ? '' : 'fill-transparent text-purple-900/60'
                }
              />
            </span>
          );
        }

        return (
          <button
            key={star}
            type="button"
            aria-label={`Rate ${itemTitle} ${star} out of 5 stars`}
            onMouseEnter={() => setHoverRating(star)}
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onChange(rating === star ? 0 : star);
            }}
            className="p-0.5 rounded focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#A855F7] transition-transform duration-150 hover:scale-115 cursor-pointer"
          >
            <Star
              size={iconSize}
              style={
                isFilled
                  ? {
                      fill: 'var(--domina-star-fill, #A855F7)',
                      color: 'var(--domina-star-stroke, #C084FC)',
                    }
                  : undefined
              }
              className={
                isFilled
                  ? 'drop-shadow-[0_0_7px_var(--domina-accent-glow)]'
                  : 'fill-transparent text-purple-900/70 hover:text-purple-400'
              }
            />
          </button>
        );
      })}
    </div>
  );
};
