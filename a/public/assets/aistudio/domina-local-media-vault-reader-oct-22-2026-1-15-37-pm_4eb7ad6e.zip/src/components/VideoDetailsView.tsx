import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  Camera,
  ExternalLink,
  FastForward,
  Heart,
  Maximize2,
  Minimize2,
  Pause,
  Play,
  Plus,
  Repeat,
  RotateCcw,
  RotateCw,
  SkipForward,
  Trash2,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { MediaItem } from '../types/media';
import { formatDuration, formatFileSize } from '../utils/mediaLogic';
import { openPathInOsExplorer } from '../utils/localMediaClient';
import { StarRating } from './StarRating';

interface VideoDetailsViewProps {
  item: MediaItem;
  nextVideoItem?: MediaItem;
  defaultLoop?: boolean;
  defaultAutoPlayNext?: boolean;
  onClose: () => void;
  onSelectVideo: (item: MediaItem) => void;
  onRate: (id: string, rating: number) => void;
  onToggleFavorite?: (id: string, nextFav: boolean) => void;
  onUpdateTags: (id: string, nextTags: string[]) => void;
  onUpdateProbedMeta?: (
    id: string,
    meta: { durationSeconds: number; width: number; height: number }
  ) => void;
  onDelete: (id: string) => void;
  panicBlur?: boolean;
}

export const VideoDetailsView: React.FC<VideoDetailsViewProps> = ({
  item,
  nextVideoItem,
  defaultLoop = false,
  defaultAutoPlayNext = true,
  onClose,
  onSelectVideo,
  onRate,
  onToggleFavorite,
  onUpdateTags,
  onUpdateProbedMeta,
  onDelete,
  panicBlur = false,
}) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(item.durationSeconds || 0);
  const [isLooping, setIsLooping] = useState(defaultLoop);
  const [autoPlayNext, setAutoPlayNext] = useState(defaultAutoPlayNext);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  // Volume booster: 0 to 200% via Web Audio API GainNode
  const [volumePercent, setVolumePercent] = useState(100);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showFsControls, setShowFsControls] = useState(false);
  // A-B Segment Loop state
  const [pointA, setPointA] = useState<number | null>(null);
  const [pointB, setPointB] = useState<number | null>(null);

  const [newTagInput, setNewTagInput] = useState('');
  const [explorerNotice, setExplorerNotice] = useState<string | null>(null);

  const playerContainerRef = useRef<HTMLDivElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const sourceAttachedRef = useRef(false);
  const fsHideTimeoutRef = useRef<number | null>(null);

  // Reset playback state when switching video item
  useEffect(() => {
    setCurrentTime(0);
    setDuration(item.durationSeconds || 0);
    setPointA(null);
    setPointB(null);
    setIsPlaying(true);
  }, [item.id, item.durationSeconds]);

  // Sync browser fullscreenchange
  useEffect(() => {
    const handleFsChange = () => {
      if (!document.fullscreenElement) {
        setIsFullscreen(false);
        setShowFsControls(false);
      }
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFsChange);
      if (fsHideTimeoutRef.current !== null) {
        window.clearTimeout(fsHideTimeoutRef.current);
      }
    };
  }, []);

  // Synchronize HTML5 <video> element and Web Audio API GainNode booster (0% - 200%)
  useEffect(() => {
    const vid = videoRef.current;
    if (!vid) return;

    vid.playbackRate = playbackSpeed;
    vid.loop = isLooping;
    vid.muted = isMuted;

    if (volumePercent > 100 && !sourceAttachedRef.current) {
      try {
        const AudioCtx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext })
            .webkitAudioContext;
        if (AudioCtx) {
          const ctx = new AudioCtx();
          const source = ctx.createMediaElementSource(vid);
          const gain = ctx.createGain();
          source.connect(gain);
          gain.connect(ctx.destination);
          audioCtxRef.current = ctx;
          gainNodeRef.current = gain;
          sourceAttachedRef.current = true;
        }
      } catch {
        // Fallback to standard HTMLMediaElement volume
      }
    }

    if (gainNodeRef.current && audioCtxRef.current) {
      if (audioCtxRef.current.state === 'suspended' && isPlaying) {
        audioCtxRef.current.resume().catch(() => {});
      }
      vid.volume = 1;
      gainNodeRef.current.gain.value = isMuted ? 0 : volumePercent / 100;
    } else {
      vid.volume = isMuted ? 0 : Math.min(1, volumePercent / 100);
    }

    if (isPlaying) {
      vid.play().catch(() => {
        setIsPlaying(false);
      });
    } else {
      vid.pause();
    }
  }, [isPlaying, playbackSpeed, isLooping, isMuted, volumePercent, item.id]);

  const enterFullscreen = () => {
    setIsFullscreen(true);
    setShowFsControls(false);
    if (!document.fullscreenElement && playerContainerRef.current) {
      playerContainerRef.current.requestFullscreen?.().catch(() => {});
    }
  };

  const exitFullscreen = () => {
    setIsFullscreen(false);
    setShowFsControls(false);
    if (fsHideTimeoutRef.current !== null) {
      window.clearTimeout(fsHideTimeoutRef.current);
      fsHideTimeoutRef.current = null;
    }
    if (document.fullscreenElement) {
      document.exitFullscreen?.().catch(() => {});
    }
  };

  const toggleFullscreen = () => {
    if (isFullscreen) {
      exitFullscreen();
    } else {
      enterFullscreen();
    }
  };

  // Fullscreen bottom-section hover detection:
  // Show controls ONLY when hovering the bottom section of the video;
  // hide controls 1 second (1000ms) after the mouse leaves the bottom section.
  const handleStageMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isFullscreen) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const relativeY = e.clientY - rect.top;
    const isBottomSection = relativeY >= rect.height * 0.75;

    if (isBottomSection) {
      if (fsHideTimeoutRef.current !== null) {
        window.clearTimeout(fsHideTimeoutRef.current);
        fsHideTimeoutRef.current = null;
      }
      if (!showFsControls) {
        setShowFsControls(true);
      }
    } else if (showFsControls && fsHideTimeoutRef.current === null) {
      fsHideTimeoutRef.current = window.setTimeout(() => {
        setShowFsControls(false);
        fsHideTimeoutRef.current = null;
      }, 1000);
    }
  };

  const handleStageMouseLeave = () => {
    if (!isFullscreen) return;
    if (showFsControls && fsHideTimeoutRef.current === null) {
      fsHideTimeoutRef.current = window.setTimeout(() => {
        setShowFsControls(false);
        fsHideTimeoutRef.current = null;
      }, 1000);
    }
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'TEXTAREA'
      ) {
        return;
      }
      if (e.key === 'Escape') {
        if (isFullscreen) {
          exitFullscreen();
        } else {
          onClose();
        }
      } else if (e.key === ' ') {
        e.preventDefault();
        setIsPlaying((p) => !p);
      } else if (e.key === 'ArrowLeft') {
        seekBy(-5);
      } else if (e.key === 'ArrowRight') {
        seekBy(5);
      } else if (e.key === 'f' || e.key === 'F') {
        toggleFullscreen();
      } else if (e.key === 'l' || e.key === 'L') {
        setIsLooping((l) => !l);
      } else if (['1', '2', '3', '4', '5'].includes(e.key)) {
        onRate(item.id, Number(e.key));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  });

  const seekBy = (deltaSec: number) => {
    const vid = videoRef.current;
    if (!vid) return;
    const next = Math.max(0, Math.min(duration || 3600, vid.currentTime + deltaSec));
    vid.currentTime = next;
    setCurrentTime(next);
  };

  const handleCaptureSnapshot = () => {
    const vid = videoRef.current;
    if (!vid) return;
    try {
      const canvas = document.createElement('canvas');
      canvas.width = vid.videoWidth || 1280;
      canvas.height = vid.videoHeight || 720;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(vid, 0, 0, canvas.width, canvas.height);
        const url = canvas.toDataURL('image/png');
        const a = document.createElement('a');
        a.href = url;
        a.download = `${item.title}-frame-${Math.round(currentTime)}s.png`;
        a.click();
      }
    } catch {
      // ignore
    }
  };

  const handleAddTag = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = newTagInput
      .trim()
      .toLowerCase()
      .replace(/^#/, '')
      .replace(/\s+/g, '-');
    if (!cleaned) return;
    if (!item.tags.includes(cleaned)) {
      onUpdateTags(item.id, [...item.tags, cleaned]);
    }
    setNewTagInput('');
  };

  const handleOpenInExplorer = async () => {
    navigator.clipboard?.writeText(item.localPath).catch(() => {});
    await openPathInOsExplorer(item.localPath).catch(() => {});
    setExplorerNotice(`Opened local directory for: ${item.localPath}`);
    window.setTimeout(() => setExplorerNotice(null), 3500);
  };

  const renderControlDeck = (inFullscreenOverlay: boolean) => (
    <div
      className={
        inFullscreenOverlay
          ? 'w-full max-w-5xl mx-auto bg-[#110820]/95 border border-purple-700/70 rounded-2xl p-4 space-y-3 backdrop-blur-md shadow-2xl'
          : 'w-full max-w-5xl mx-auto mt-4 bg-[#120A20] border border-purple-900/60 rounded-xl p-4 space-y-3'
      }
      onClick={(e) => e.stopPropagation()}
    >
      {/* Timeline Scrubber */}
      <div className="flex items-center gap-3">
        <span className="text-xs font-mono-tabular text-purple-200 w-12">
          {formatDuration(currentTime)}
        </span>
        <input
          type="range"
          min={0}
          max={Math.max(1, duration)}
          step={0.1}
          value={currentTime}
          onChange={(e) => {
            const val = Number(e.target.value);
            setCurrentTime(val);
            if (videoRef.current) {
              videoRef.current.currentTime = val;
            }
          }}
          aria-label="Seek video timeline"
          className="flex-1 h-1.5 bg-purple-950 rounded-lg accent-[#A855F7] cursor-pointer"
        />
        <span className="text-xs font-mono-tabular text-purple-300/70 w-12 text-right">
          {formatDuration(duration)}
        </span>
      </div>

      {/* Transport, Skip, A-B Loop, Speed, Volume Booster (0% - 200%), Next Video, Fullscreen */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => setIsPlaying((p) => !p)}
            aria-label={isPlaying ? 'Pause video' : 'Play video'}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-[#7C3AED] hover:bg-[#8B5CF6] text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            {isPlaying ? <Pause size={14} /> : <Play size={14} />}
            <span>{isPlaying ? 'Pause' : 'Play'}</span>
          </button>

          <button
            type="button"
            onClick={() => seekBy(-10)}
            aria-label="Rewind 10 seconds"
            className="inline-flex items-center gap-1 px-2.5 py-2 text-xs font-mono bg-[#090412] hover:bg-purple-950 text-purple-200 border border-purple-900/60 rounded-lg transition-colors cursor-pointer"
          >
            <RotateCcw size={13} />
            <span>-10s</span>
          </button>

          <button
            type="button"
            onClick={() => seekBy(10)}
            aria-label="Forward 10 seconds"
            className="inline-flex items-center gap-1 px-2.5 py-2 text-xs font-mono bg-[#090412] hover:bg-purple-950 text-purple-200 border border-purple-900/60 rounded-lg transition-colors cursor-pointer"
          >
            <RotateCw size={13} />
            <span>+10s</span>
          </button>

          {/* A-B Segment Loop */}
          <div className="flex items-center gap-1 bg-[#090412] border border-purple-900/60 rounded-lg p-1 text-xs font-mono">
            <button
              type="button"
              onClick={() => setPointA(currentTime)}
              className={`px-2 py-1 rounded cursor-pointer ${
                pointA !== null
                  ? 'bg-[#7C3AED] text-white'
                  : 'text-purple-300 hover:text-white'
              }`}
            >
              {pointA !== null ? `A:${formatDuration(pointA)}` : 'Set A'}
            </button>
            <button
              type="button"
              onClick={() => {
                if (pointA !== null && currentTime > pointA) {
                  setPointB(currentTime);
                }
              }}
              className={`px-2 py-1 rounded cursor-pointer ${
                pointB !== null
                  ? 'bg-[#9333EA] text-white'
                  : 'text-purple-300 hover:text-white'
              }`}
            >
              {pointB !== null ? `B:${formatDuration(pointB)}` : 'Set B'}
            </button>
            {(pointA !== null || pointB !== null) && (
              <button
                type="button"
                onClick={() => {
                  setPointA(null);
                  setPointB(null);
                }}
                aria-label="Clear A-B loop"
                className="px-1.5 py-1 text-rose-400 hover:text-rose-200 cursor-pointer"
              >
                <X size={12} />
              </button>
            )}
          </div>

          {nextVideoItem && nextVideoItem.id !== item.id && (
            <button
              type="button"
              onClick={() => onSelectVideo(nextVideoItem)}
              aria-label={`Play next video: ${nextVideoItem.title}`}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#090412] hover:bg-purple-950 text-purple-100 border border-purple-900/60 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <SkipForward size={14} />
              <span>Next</span>
            </button>
          )}
        </div>

        {/* Volume Booster (up to 200%) */}
        <div className="flex items-center gap-2 bg-[#090412] border border-purple-900/60 rounded-lg px-3 py-1.5">
          <button
            type="button"
            onClick={() => setIsMuted((m) => !m)}
            aria-label={isMuted ? 'Unmute audio' : 'Mute audio'}
            className="text-purple-200 hover:text-white cursor-pointer"
          >
            {isMuted || volumePercent === 0 ? (
              <VolumeX size={15} className="text-rose-400" />
            ) : (
              <Volume2
                size={15}
                className={
                  volumePercent > 100 ? 'text-[#C084FC]' : 'text-purple-200'
                }
              />
            )}
          </button>
          <input
            type="range"
            min={0}
            max={200}
            step={5}
            value={isMuted ? 0 : volumePercent}
            onChange={(e) => {
              setIsMuted(false);
              setVolumePercent(Number(e.target.value));
            }}
            aria-label="Volume booster percentage"
            className="w-24 h-1.5 bg-purple-950 rounded-lg accent-[#A855F7] cursor-pointer"
          />
          <span
            className={`text-xs font-mono-tabular w-16 text-right ${
              volumePercent > 100
                ? 'text-[#C084FC] font-semibold'
                : 'text-purple-200'
            }`}
          >
            {isMuted ? 'MUTED' : `${volumePercent}%`}
            {volumePercent > 100 && !isMuted ? ' BOOST' : ''}
          </span>
        </div>

        {/* Playback Speed Selector + Snapshot + Fullscreen */}
        <div className="flex items-center gap-1.5">
          <div className="flex items-center gap-1 bg-[#090412] border border-purple-900/60 rounded-lg p-1">
            <FastForward size={13} className="text-purple-400 ml-1.5 mr-1" />
            {[0.5, 1, 1.25, 1.5, 2].map((rate) => (
              <button
                key={rate}
                type="button"
                onClick={() => setPlaybackSpeed(rate)}
                className={`px-2 py-1 text-xs font-mono-tabular rounded transition-colors cursor-pointer ${
                  playbackSpeed === rate
                    ? 'bg-[#7C3AED] text-white font-semibold'
                    : 'text-purple-300/80 hover:text-white'
                }`}
              >
                {rate}x
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={handleCaptureSnapshot}
            aria-label="Save video frame snapshot"
            className="p-2 bg-[#090412] border border-purple-900/60 rounded-lg text-purple-200 hover:text-white transition-colors cursor-pointer"
          >
            <Camera size={15} />
          </button>

          <button
            type="button"
            onClick={toggleFullscreen}
            aria-label="Toggle video fullscreen"
            className="p-2 bg-[#090412] border border-purple-900/60 rounded-lg text-purple-200 hover:text-white transition-colors cursor-pointer"
          >
            {isFullscreen ? <Minimize2 size={15} /> : <Maximize2 size={15} />}
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div
      data-fullscreen={isFullscreen ? 'true' : 'false'}
      data-fs-controls={showFsControls ? 'visible' : 'hidden'}
      className={
        isFullscreen
          ? 'fixed inset-0 z-50 w-screen h-screen bg-black overflow-hidden'
          : 'flex flex-col lg:flex-row h-[calc(100vh-4.25rem)] bg-[#07040E] overflow-hidden'
      }
    >
      {/* Main Video Studio Stage */}
      <div
        ref={playerContainerRef}
        onMouseMove={handleStageMouseMove}
        onMouseLeave={handleStageMouseLeave}
        className={
          isFullscreen
            ? 'relative w-screen h-screen bg-black flex items-center justify-center overflow-hidden'
            : 'flex-1 flex flex-col justify-between bg-[#07040E] p-4 lg:p-6 overflow-y-auto'
        }
      >
        {/* Top Stage Bar — Hidden completely in Fullscreen */}
        {!isFullscreen && (
          <div className="flex items-center justify-between gap-4 mb-4">
            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium bg-[#120A20] hover:bg-purple-950 text-purple-100 border border-purple-900/60 rounded-lg transition-colors cursor-pointer"
            >
              <ArrowLeft size={15} />
              <span>Back to Videos</span>
            </button>

            <div className="flex items-center gap-2">
              {/* Loop Toggle */}
              <button
                type="button"
                onClick={() => setIsLooping((l) => !l)}
                aria-pressed={isLooping}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  isLooping
                    ? 'bg-[#7C3AED] text-white border-[#C084FC]'
                    : 'bg-[#120A20] text-purple-200 border-purple-900/60 hover:border-purple-700'
                }`}
              >
                <Repeat size={13} />
                <span>Loop: {isLooping ? 'On' : 'Off'}</span>
              </button>

              {/* Auto-Play Next Toggle */}
              <button
                type="button"
                onClick={() => setAutoPlayNext((a) => !a)}
                aria-pressed={autoPlayNext}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  autoPlayNext
                    ? 'bg-[#9333EA] text-white border-[#C084FC]'
                    : 'bg-[#120A20] text-purple-200 border-purple-900/60 hover:border-purple-700'
                }`}
              >
                <SkipForward size={13} />
                <span>Auto-Play Next: {autoPlayNext ? 'On' : 'Off'}</span>
              </button>
            </div>
          </div>
        )}

        {/* Sleek Real Video Viewport */}
        <div
          onClick={() => setIsPlaying((p) => !p)}
          className={
            isFullscreen
              ? 'relative w-screen h-screen bg-black flex items-center justify-center cursor-pointer'
              : 'relative w-full max-w-5xl mx-auto aspect-video bg-[#080410] border border-purple-900/60 rounded-xl overflow-hidden shadow-2xl cursor-pointer'
          }
        >
          <div className={`w-full h-full ${panicBlur ? 'blur-2xl scale-110' : ''}`}>
            <video
              ref={videoRef}
              src={item.mediaUrl}
              playsInline
              onLoadedMetadata={(e) => {
                const vid = e.currentTarget;
                const d = Math.round(vid.duration || 0);
                setDuration(d);
                if (
                  onUpdateProbedMeta &&
                  d > 0 &&
                  (!item.durationSeconds || item.durationSeconds !== d)
                ) {
                  onUpdateProbedMeta(item.id, {
                    durationSeconds: d,
                    width: vid.videoWidth || item.width,
                    height: vid.videoHeight || item.height,
                  });
                }
              }}
              onTimeUpdate={(e) => {
                const t = e.currentTarget.currentTime;
                if (pointA !== null && pointB !== null && t >= pointB) {
                  e.currentTarget.currentTime = pointA;
                  setCurrentTime(pointA);
                } else {
                  setCurrentTime(t);
                }
              }}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              onEnded={() => {
                if (
                  !isLooping &&
                  autoPlayNext &&
                  nextVideoItem &&
                  nextVideoItem.id !== item.id
                ) {
                  onSelectVideo(nextVideoItem);
                } else if (!isLooping) {
                  setIsPlaying(false);
                }
              }}
              className="w-full h-full object-contain bg-black"
            />
          </div>

          {/* Center Play/Pause Indicator when Paused (only in non-fullscreen) */}
          {!isPlaying && !isFullscreen && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/45 backdrop-blur-[2px]">
              <div className="w-16 h-16 rounded-full bg-[#7C3AED] text-white flex items-center justify-center shadow-lg">
                <Play size={28} className="fill-white ml-1" />
              </div>
            </div>
          )}
        </div>

        {/* Normal Mode Control Deck OR Fullscreen Bottom Hover Overlay */}
        {!isFullscreen ? (
          renderControlDeck(false)
        ) : (
          <div
            className={`absolute inset-x-0 bottom-0 z-30 p-6 transition-opacity duration-200 ${
              showFsControls
                ? 'opacity-100 pointer-events-auto'
                : 'opacity-0 pointer-events-none'
            }`}
          >
            {renderControlDeck(true)}
          </div>
        )}
      </div>

      {/* Video Metadata Sidebar — Hidden completely in Fullscreen */}
      {!isFullscreen && (
        <aside
          aria-label="Video Metadata Sidebar"
          className="w-full lg:w-96 bg-[#11091F] border-t lg:border-t-0 lg:border-l border-purple-900/60 p-5 flex flex-col justify-between overflow-y-auto shrink-0"
        >
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between">
                <div className="text-xs font-mono text-[#C084FC] mb-1">
                  CINEMA STUDIO INSPECTOR
                </div>
                {onToggleFavorite && (
                  <button
                    type="button"
                    onClick={() => onToggleFavorite(item.id, !item.isFavorite)}
                    className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs border transition-colors cursor-pointer ${
                      item.isFavorite
                        ? 'bg-[#7C3AED] border-[#C084FC] text-white'
                        : 'bg-[#080410] border-purple-800/60 text-purple-300 hover:text-white'
                    }`}
                  >
                    <Heart
                      size={12}
                      className={item.isFavorite ? 'fill-white text-white' : ''}
                    />
                    <span>{item.isFavorite ? 'Favorited' : 'Favorite'}</span>
                  </button>
                )}
              </div>
              <h1 className="text-lg font-display font-semibold text-purple-50 leading-snug">
                {item.title}
              </h1>

              <div className="mt-3 pt-3 border-t border-purple-900/50 flex items-center justify-between">
                <span className="text-xs text-purple-300/80">Vault Rating</span>
                <StarRating
                  rating={item.rating}
                  onChange={(r) => onRate(item.id, r)}
                  size="lg"
                  itemTitle={item.title}
                />
              </div>
            </div>

            <div className="space-y-2 pt-3 border-t border-purple-900/50 text-xs">
              <h2 className="text-xs font-semibold text-purple-200">
                Stream & Container Telemetry
              </h2>
              <dl className="grid grid-cols-2 gap-y-2 text-purple-300/75">
                <dt>Filename</dt>
                <dd className="text-right font-mono-tabular text-purple-100 truncate">
                  {item.filename}
                </dd>
                <dt>Resolution</dt>
                <dd className="text-right font-mono-tabular text-purple-100">
                  {item.width} × {item.height}
                </dd>
                <dt>Container</dt>
                <dd className="text-right font-mono-tabular text-purple-100">
                  {item.format}
                </dd>
                <dt>Duration</dt>
                <dd className="text-right font-mono-tabular text-purple-100">
                  {formatDuration(duration)}
                </dd>
                <dt>File Size</dt>
                <dd className="text-right font-mono-tabular text-purple-100">
                  {formatFileSize(item.sizeBytes)}
                </dd>
              </dl>

              <div className="pt-2">
                <div className="text-purple-300/75 mb-1">Local Storage Path</div>
                <div className="p-2.5 bg-[#080410] border border-purple-900/60 rounded font-mono text-[11px] text-purple-200 break-all">
                  {item.localPath}
                </div>
              </div>

              <button
                type="button"
                onClick={handleOpenInExplorer}
                className="w-full mt-2 inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium bg-[#1A0E30] hover:bg-[#251444] text-purple-100 border border-purple-800/60 rounded-lg transition-colors cursor-pointer"
              >
                <ExternalLink size={14} className="text-[#C084FC]" />
                <span>Open in Explorer / Finder</span>
              </button>

              {explorerNotice && (
                <p className="text-[11px] font-mono text-emerald-300 bg-emerald-950/40 border border-emerald-800/50 rounded p-2">
                  {explorerNotice}
                </p>
              )}
            </div>

            {/* Editable Tags */}
            <div className="space-y-3 pt-4 border-t border-purple-900/50">
              <h2 className="text-xs font-semibold text-purple-200">
                Assigned Tags ({item.tags.length})
              </h2>
              <div className="flex flex-wrap gap-1.5">
                {item.tags.map((tag) => (
                  <span
                    key={tag}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono bg-[#080410] border border-purple-900/60 rounded text-purple-100"
                  >
                    <span>#{tag}</span>
                    <button
                      type="button"
                      onClick={() =>
                        onUpdateTags(
                          item.id,
                          item.tags.filter((t) => t !== tag)
                        )
                      }
                      aria-label={`Remove tag ${tag}`}
                      className="text-purple-400 hover:text-rose-400 cursor-pointer"
                    >
                      <X size={12} />
                    </button>
                  </span>
                ))}
              </div>

              <form onSubmit={handleAddTag} className="flex items-center gap-2">
                <input
                  type="text"
                  value={newTagInput}
                  onChange={(e) => setNewTagInput(e.target.value)}
                  placeholder="Add video tag..."
                  aria-label="Add video tag"
                  className="flex-1 px-3 py-1.5 text-xs bg-[#080410] border border-purple-900/60 rounded-lg text-purple-100 placeholder:text-purple-400/50 focus:outline-none focus:border-[#A855F7]"
                />
                <button
                  type="submit"
                  className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold bg-[#7C3AED] hover:bg-[#8B5CF6] text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  <Plus size={14} />
                  <span>Add</span>
                </button>
              </form>
            </div>
          </div>

          {/* Next in Queue Preview & Delete */}
          <div className="pt-4 border-t border-purple-900/50 mt-4 space-y-3">
            {nextVideoItem && nextVideoItem.id !== item.id && (
              <div className="p-3 bg-[#080410] border border-purple-900/60 rounded-lg flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="text-[10px] font-mono text-[#C084FC]">
                    UP NEXT IN QUEUE
                  </div>
                  <div className="text-xs font-medium text-purple-100 truncate">
                    {nextVideoItem.title}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onSelectVideo(nextVideoItem)}
                  className="px-2.5 py-1 text-xs font-medium bg-[#7C3AED] hover:bg-[#8B5CF6] text-white rounded transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  Play Now
                </button>
              </div>
            )}

            <button
              type="button"
              onClick={() => onDelete(item.id)}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-rose-300 hover:text-white hover:bg-rose-950/70 border border-rose-800/50 rounded-lg transition-colors cursor-pointer"
            >
              <Trash2 size={14} />
              <span>Remove from Vault</span>
            </button>
          </div>
        </aside>
      )}
    </div>
  );
};
