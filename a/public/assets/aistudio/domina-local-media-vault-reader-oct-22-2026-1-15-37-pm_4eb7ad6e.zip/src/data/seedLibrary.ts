import { AppearanceConfig, DirectoryConfig, MediaItem } from '../types/media';

export const DEFAULT_DIRECTORIES: DirectoryConfig = {
  imagesPath: '/app/applet/vault/images',
  videosPath: '/app/applet/vault/videos',
  comicsPath: '/app/applet/vault/comics',
  imageSetsPath: '/app/applet/vault/imagesets',
  lastIndexedAt: '',
  autoScanOnStartup: true,
};

export const DEFAULT_APPEARANCE: AppearanceConfig = {
  accentColor: 'violet',
  customAccentHex: '#9D4EDD',
  accentIntensity: 95,
  surfaceTheme: 'nebula',
  cardStyle: 'glass',
  headingFont: 'cinzel',
  uiScale: 'standard',
  starColorStyle: 'amethyst',
  cardTitlePosition: 'below',
  imageBackdropStyle: 'ambient',
  gridDensity: 'standard',
  gridColumns: 0,
  cardGap: 'standard',
  cardRadius: 'rounded',
  thumbnailAspect: 'portrait',
  thumbnailFit: 'cover',
  showCardSize: true,
  showCardTags: true,
  showCardRating: true,
  hoverZoom: true,
  defaultReaderFit: 'height',
  defaultReaderDirection: 'ltr',
  defaultVideoLoop: false,
  defaultAutoPlayNext: true,
  slideshowIntervalSeconds: 4,
  slideshowLoop: true,
  slideshowTransition: 'fade',
  defaultTonePreset: 'original',
  panicModeBlur: false,
};

export const INITIAL_MEDIA_LIBRARY: MediaItem[] = [];
