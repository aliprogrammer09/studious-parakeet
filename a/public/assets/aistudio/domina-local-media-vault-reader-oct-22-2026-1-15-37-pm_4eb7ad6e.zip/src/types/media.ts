export type MediaType = 'image' | 'video' | 'comic' | 'imageset';

export type PageView =
  | 'dashboard'
  | 'images'
  | 'videos'
  | 'comics'
  | 'imagesets'
  | 'advanced-search'
  | 'image-details'
  | 'video-details'
  | 'comic-pages'
  | 'imageset-images'
  | 'reader'
  | 'settings';

export type SortField =
  | 'title'
  | 'dateAdded'
  | 'rating'
  | 'size'
  | 'resolution'
  | 'pageCount';
export type SortOrder = 'asc' | 'desc';

export type ReaderFitMode = 'width' | 'height' | 'original' | 'double';
export type ReaderDirection = 'vertical' | 'ltr' | 'rtl';

export interface MediaPageItem {
  id: string;
  pageNumber: number;
  title: string;
  filename: string;
  localPath: string;
  url: string;
  width: number;
  height: number;
  sizeBytes: number;
  format: string;
  rating?: number; // 0 to 5 stars
  isFavorite?: boolean;
  tags?: string[];
  notes?: string;
}

export interface MediaItem {
  id: string;
  type: MediaType;
  title: string;
  filename: string;
  localPath: string;
  folderPath: string;
  thumbnailUrl: string;
  mediaUrl: string;
  rating: number; // 0 to 5
  isFavorite?: boolean;
  notes?: string;
  tags: string[];
  dateAdded: string; // ISO date string
  sizeBytes: number;
  format: string;
  width: number;
  height: number;
  // Video specific
  durationSeconds?: number;
  fps?: number;
  codec?: string;
  videoThemeSeed?: number;
  // Comic & Image Set specific (subfolder represents comic/set, contents are ordered pages)
  pages?: MediaPageItem[];
  pageCount?: number;
  lastReadPage?: number; // 1-indexed smart bookmark (Comics only)
  readPages?: number[]; // Unique 1-indexed page numbers actually viewed (Comics only)
  lastReadAt?: string;
  artist?: string;
  series?: string;
}

export interface DirectoryConfig {
  imagesPath: string;
  videosPath: string;
  comicsPath: string;
  imageSetsPath: string;
  lastIndexedAt: string;
  autoScanOnStartup: boolean;
}

export interface AppearanceConfig {
  accentColor:
    | 'violet'
    | 'amethyst'
    | 'crimson'
    | 'indigo'
    | 'emerald'
    | 'amber'
    | 'fuchsia';
  accentIntensity: number; // 20 to 100
  bgDarkness?: 'pitch-black' | 'obsidian' | 'charcoal';
  borderStyle?: 'glow' | 'minimal' | 'glass';
  gridDensity: 'ultra-compact' | 'compact' | 'standard' | 'spacious';
  gridColumns: number; // 0 = auto from density, or 2..8 explicit columns
  cardGap: 'tight' | 'standard' | 'relaxed';
  cardRadius: 'sharp' | 'rounded' | 'lux';
  thumbnailAspect: 'portrait' | 'comic' | 'landscape' | 'square' | 'natural';
  thumbnailFit: 'cover' | 'contain';
  showCardSize: boolean;
  showCardTags: boolean;
  showCardRating: boolean;
  showCardDimensions?: boolean;
  hoverZoom: boolean;
  defaultReaderFit: ReaderFitMode;
  defaultReaderDirection: ReaderDirection;
  readerBgColor?: 'pitch-black' | 'obsidian-purple' | 'sepia-dark' | 'charcoal';
  defaultVideoLoop: boolean;
  defaultAutoPlayNext: boolean;
  slideshowIntervalSeconds: number;
  slideshowLoop?: boolean;
  panicModeBlur: boolean;
}

export type OrientationFilter = 'all' | 'portrait' | 'landscape' | 'square';
export type ResolutionFilter = 'all' | 'hd' | 'fhd' | 'qhd' | 'uhd';
export type DurationFilter = 'all' | 'short' | 'medium' | 'long';
export type ComicProgressFilter = 'all' | 'unread' | 'reading' | 'completed';

export interface FilterState {
  searchQuery: string;
  tagExpression: string; // Supports "+tagA -tagB tagC OR tagD"
  includedTags: string[];
  excludedTags: string[];
  orTags: string[];
  tagMatchMode?: 'all' | 'any'; // Match all included tags (AND) or any (OR)
  selectedRatings: number[]; // Multi-rating selection e.g. [0, 4, 5]
  selectedTypes?: MediaType[]; // Used in Advanced Search
  favoritesOnly?: boolean;
  orientation?: OrientationFilter;
  minResolution?: ResolutionFilter;
  durationRange?: DurationFilter;
  comicProgress?: ComicProgressFilter;
  minSizeMB?: number;
  maxSizeMB?: number;
  sortBy: SortField;
  sortOrder: SortOrder;
}

export interface SavedSearchPreset {
  id: string;
  name: string;
  filter: FilterState;
  createdAt: string;
}
