/**
 * Pure TypeScript binary header parser for extracting real width & height
 * from local PNG, JPEG, GIF, and WEBP image files without native C++ dependencies.
 */

export interface ImageDimensions {
  width: number;
  height: number;
}

export function parseImageDimensionsFromBuffer(
  buf: Uint8Array
): ImageDimensions | null {
  if (!buf || buf.length < 24) return null;

  // 1. PNG: 89 50 4E 47 0D 0A 1A 0A, IHDR width at offset 16 (4 bytes BE), height at 20 (4 bytes BE)
  if (
    buf[0] === 0x89 &&
    buf[1] === 0x50 &&
    buf[2] === 0x4e &&
    buf[3] === 0x47
  ) {
    const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
    const width = view.getUint32(16, false);
    const height = view.getUint32(20, false);
    if (width > 0 && height > 0) return { width, height };
  }

  // 2. GIF: "GIF87a" or "GIF89a", width at offset 6 (2 bytes LE), height at 8 (2 bytes LE)
  if (
    buf[0] === 0x47 &&
    buf[1] === 0x49 &&
    buf[2] === 0x46 &&
    buf[3] === 0x38
  ) {
    const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
    const width = view.getUint16(6, true);
    const height = view.getUint16(8, true);
    if (width > 0 && height > 0) return { width, height };
  }

  // 3. WEBP: "RIFF" .... "WEBP"
  if (
    buf[0] === 0x52 &&
    buf[1] === 0x49 &&
    buf[2] === 0x46 &&
    buf[3] === 0x46 &&
    buf[8] === 0x57 &&
    buf[9] === 0x45 &&
    buf[10] === 0x42 &&
    buf[11] === 0x50
  ) {
    // Check VP8X, VP8, or VP8L chunk at offset 12
    const chunkHeader = String.fromCharCode(buf[12], buf[13], buf[14], buf[15]);
    if (chunkHeader === 'VP8X' && buf.length >= 30) {
      const width = 1 + (buf[24] | (buf[25] << 8) | (buf[26] << 16));
      const height = 1 + (buf[27] | (buf[28] << 8) | (buf[29] << 16));
      return { width, height };
    }
    if (chunkHeader === 'VP8 ' && buf.length >= 30) {
      const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
      const width = view.getUint16(26, true) & 0x3fff;
      const height = view.getUint16(28, true) & 0x3fff;
      if (width > 0 && height > 0) return { width, height };
    }
    if (chunkHeader === 'VP8L' && buf.length >= 25) {
      const b0 = buf[21];
      const b1 = buf[22];
      const b2 = buf[23];
      const b3 = buf[24];
      const width = 1 + (((b1 & 0x3f) << 8) | b0);
      const height = 1 + (((b3 & 0x0f) << 10) | (b2 << 2) | ((b1 & 0xc0) >> 6));
      if (width > 0 && height > 0) return { width, height };
    }
  }

  // 4. JPEG: FF D8 ... scan for SOF0..SOF2 markers (FF C0, FF C1, FF C2)
  if (buf[0] === 0xff && buf[1] === 0xd8) {
    let offset = 2;
    const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
    while (offset + 9 < buf.length) {
      if (buf[offset] !== 0xff) {
        offset += 1;
        continue;
      }
      const marker = buf[offset + 1];
      if (marker === 0xff) {
        offset += 1;
        continue;
      }
      // SOF markers that contain dimensions
      if (
        marker === 0xc0 ||
        marker === 0xc1 ||
        marker === 0xc2 ||
        marker === 0xc3
      ) {
        const height = view.getUint16(offset + 5, false);
        const width = view.getUint16(offset + 7, false);
        if (width > 0 && height > 0) return { width, height };
        break;
      }
      if (marker === 0xd9 || marker === 0xda) break;
      const segmentLength = view.getUint16(offset + 2, false);
      if (segmentLength < 2) break;
      offset += 2 + segmentLength;
    }
  }

  return null;
}
