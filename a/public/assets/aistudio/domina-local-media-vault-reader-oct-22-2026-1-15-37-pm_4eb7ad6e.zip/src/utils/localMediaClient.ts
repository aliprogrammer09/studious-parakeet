import {
  AppearanceConfig,
  DirectoryConfig,
  MediaItem,
  MediaType,
} from '../types/media';

export interface VaultStateResponse {
  version: string;
  directories: DirectoryConfig;
  appearance: AppearanceConfig;
  mediaItems: MediaItem[];
}

export async function fetchVaultState(): Promise<VaultStateResponse> {
  const res = await fetch('/api/state');
  if (!res.ok) throw new Error('Failed to load vault state');
  return res.json();
}

export async function triggerServerScan(
  directories?: DirectoryConfig
): Promise<{
  ok: boolean;
  mediaItems: MediaItem[];
  directories: DirectoryConfig;
  totalCount: number;
}> {
  const res = await fetch('/api/scan', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(directories ? { directories } : {}),
  });
  if (!res.ok) throw new Error('Failed to scan directories');
  return res.json();
}

export async function patchMediaItemOnServer(
  id: string,
  updates: Partial<
    Pick<
      MediaItem,
      | 'rating'
      | 'isFavorite'
      | 'notes'
      | 'artist'
      | 'series'
      | 'tags'
      | 'lastReadPage'
      | 'readPages'
      | 'title'
      | 'durationSeconds'
      | 'width'
      | 'height'
      | 'thumbnailUrl'
      | 'pages'
    >
  >
): Promise<MediaItem | null> {
  const res = await fetch(`/api/media/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates),
  });
  if (!res.ok) return null;
  const data = await res.json();
  return data.item || null;
}

export async function patchCollectionPageOnServer(
  collectionId: string,
  pageNumber: number,
  updates: {
    rating?: number;
    isFavorite?: boolean;
    tags?: string[];
    notes?: string;
  }
): Promise<boolean> {
  const res = await fetch(
    `/api/media/${encodeURIComponent(collectionId)}/page/${pageNumber}`,
    {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    }
  );
  return res.ok;
}

export async function deleteMediaItemOnServer(
  id: string,
  deleteFromDisk = true
): Promise<boolean> {
  const res = await fetch(
    `/api/media/${encodeURIComponent(id)}?deleteFromDisk=${deleteFromDisk}`,
    { method: 'DELETE' }
  );
  return res.ok;
}

export async function saveSettingsOnServer(payload: {
  directories?: DirectoryConfig;
  appearance?: AppearanceConfig;
}): Promise<{ directories: DirectoryConfig; appearance: AppearanceConfig }> {
  const res = await fetch('/api/settings', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error('Failed to save settings');
  return res.json();
}

export async function openPathInOsExplorer(
  localPath: string
): Promise<{ ok: boolean; openedDirectory?: string }> {
  const res = await fetch('/api/open-in-explorer', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path: localPath }),
  });
  return res.json();
}

/**
 * Probes an HTML5 video URL in the browser to extract real duration, width, height,
 * and captures a JPEG poster thumbnail frame using an offscreen canvas.
 */
export function probeVideoMetadataInBrowser(videoUrl: string): Promise<{
  durationSeconds: number;
  width: number;
  height: number;
  thumbnailDataUrl: string;
} | null> {
  return new Promise((resolve) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    video.playsInline = true;
    video.crossOrigin = 'anonymous';

    const timeout = window.setTimeout(() => {
      cleanup();
      resolve(null);
    }, 6000);

    const cleanup = () => {
      window.clearTimeout(timeout);
      video.removeAttribute('src');
      video.load();
    };

    video.onloadedmetadata = () => {
      const duration = Number.isFinite(video.duration) ? video.duration : 0;
      // Seek to 25% or 1.5s to capture a representative thumbnail frame
      video.currentTime = duration > 1 ? Math.min(2, duration * 0.25) : 0.1;
    };

    video.onseeked = () => {
      try {
        const w = video.videoWidth || 1280;
        const h = video.videoHeight || 720;
        const canvas = document.createElement('canvas');
        const targetW = 640;
        const targetH = Math.round((h / w) * targetW) || 360;
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, targetW, targetH);
        }
        const thumbnailDataUrl = canvas.toDataURL('image/jpeg', 0.8);
        const result = {
          durationSeconds: Math.round(video.duration || 0),
          width: w,
          height: h,
          thumbnailDataUrl,
        };
        cleanup();
        resolve(result);
      } catch {
        cleanup();
        resolve(null);
      }
    };

    video.onerror = () => {
      cleanup();
      resolve(null);
    };

    video.src = videoUrl;
  });
}

/**
 * Uploads a batch of File objects (from folder picker, file picker, or drag-and-drop)
 * to the local backend server and triggers a filesystem scan.
 */
export async function uploadFilesToVaultAndScan(
  files: File[],
  targetType: MediaType,
  collectionName?: string,
  onProgress?: (completed: number, total: number, currentFilename: string) => void
): Promise<MediaItem[]> {
  const validFiles = files.filter((f) => {
    if (f.name.startsWith('.')) return false;
    if (targetType === 'video') {
      return /\.(mp4|webm|mkv|mov|avi|m4v|ogv)$/i.test(f.name);
    }
    return /\.(png|jpe?g|webp|gif|avif|bmp|svg)$/i.test(f.name);
  });

  const total = validFiles.length;
  for (let i = 0; i < total; i++) {
    const file = validFiles[i];
    const relPath =
      (file as File & { webkitRelativePath?: string }).webkitRelativePath ||
      file.name;

    if (onProgress) {
      onProgress(i + 1, total, file.name);
    }

    const params = new URLSearchParams({
      type: targetType,
      relativePath: relPath,
    });
    if (collectionName) {
      params.set('collectionName', collectionName);
    }

    await fetch(`/api/upload-raw?${params.toString()}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/octet-stream' },
      body: file,
    });
  }

  const scanRes = await triggerServerScan();
  return scanRes.mediaItems;
}
