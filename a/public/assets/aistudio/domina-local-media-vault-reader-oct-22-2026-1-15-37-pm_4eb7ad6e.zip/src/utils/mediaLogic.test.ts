import test from 'node:test';
import assert from 'node:assert/strict';
import {
  parseTagExpression,
  matchesTagFilter,
  matchesRatingFilter,
  filterAndSortMedia,
  getTagSuggestions,
  computeBookmarkProgress,
  groupSubfolderFilesIntoCollections,
} from './mediaLogic';
import { FilterState, MediaItem } from '../types/media';
import { parseImageDimensionsFromBuffer } from './imageHeaderParser';

test('parseTagExpression parses +include, -exclude, and OR groups accurately', () => {
  const parsed = parseTagExpression('+gothic -daylight crimson OR velvet OR lace');
  assert.deepEqual(parsed.include, ['gothic']);
  assert.deepEqual(parsed.exclude, ['daylight']);
  assert.deepEqual(parsed.orGroups, [['crimson', 'velvet', 'lace']]);
});

test('matchesTagFilter evaluates boolean AND, NOT, and OR logic', () => {
  const baseFilter = {
    tagExpression: '+obsidian -pastel ruby OR violet',
    includedTags: ['noir'],
    excludedTags: ['bright'],
    orTags: [],
  };

  assert.equal(
    matchesTagFilter(['obsidian', 'noir', 'violet', 'portrait'], baseFilter),
    true
  );
  // Missing 'ruby' or 'violet'
  assert.equal(
    matchesTagFilter(['obsidian', 'noir', 'portrait'], baseFilter),
    false
  );
  // Contains excluded 'pastel'
  assert.equal(
    matchesTagFilter(['obsidian', 'noir', 'ruby', 'pastel'], baseFilter),
    false
  );

  // Test orTags without requiring both
  const orFilter = {
    tagExpression: '',
    includedTags: [],
    excludedTags: [],
    orTags: ['amethyst', 'crimson'],
  };
  assert.equal(matchesTagFilter(['amethyst'], orFilter), true);
  assert.equal(matchesTagFilter(['crimson'], orFilter), true);
  assert.equal(matchesTagFilter(['unrelated'], orFilter), false);

  // Test tagMatchMode: 'any'
  const anyFilter = {
    tagExpression: '',
    includedTags: ['leather', 'silk'],
    excludedTags: [],
    orTags: [],
    tagMatchMode: 'any' as const,
  };
  assert.equal(matchesTagFilter(['leather'], anyFilter), true);
  assert.equal(matchesTagFilter(['silk'], anyFilter), true);
  assert.equal(matchesTagFilter(['cotton'], anyFilter), false);

  // Test first tag in includedTags (+gothic) and second tag in orTags (OR:cyberpunk)
  const mixedChipOrFilter = {
    tagExpression: '',
    includedTags: ['gothic'],
    excludedTags: [],
    orTags: ['cyberpunk'],
  };
  assert.equal(matchesTagFilter(['gothic'], mixedChipOrFilter), true);
  assert.equal(matchesTagFilter(['cyberpunk'], mixedChipOrFilter), true);
  assert.equal(matchesTagFilter(['pastel'], mixedChipOrFilter), false);
});

test('matchesRatingFilter supports concurrent multi-star selection', () => {
  assert.equal(matchesRatingFilter(5, [4, 5]), true);
  assert.equal(matchesRatingFilter(4, [4, 5]), true);
  assert.equal(matchesRatingFilter(3, [4, 5]), false);
  assert.equal(matchesRatingFilter(2, []), true); // Empty selection matches all
});

test('filterAndSortMedia filters and sorts items deterministically', () => {
  const sampleItems: MediaItem[] = [
    {
      id: '1',
      type: 'image',
      title: 'Crimson Cathedral',
      filename: 'cathedral.png',
      localPath: '/vault/images/cathedral.png',
      folderPath: '/vault/images',
      thumbnailUrl: '',
      mediaUrl: '',
      rating: 4,
      tags: ['architecture', 'crimson', 'gothic'],
      dateAdded: '2026-10-10T10:00:00Z',
      sizeBytes: 1000,
      format: 'PNG',
      width: 1920,
      height: 1080,
    },
    {
      id: '2',
      type: 'image',
      title: 'Obsidian Throne',
      filename: 'throne.png',
      localPath: '/vault/images/throne.png',
      folderPath: '/vault/images',
      thumbnailUrl: '',
      mediaUrl: '',
      rating: 5,
      tags: ['architecture', 'obsidian', 'gothic'],
      dateAdded: '2026-10-15T10:00:00Z',
      sizeBytes: 2000,
      format: 'PNG',
      width: 1920,
      height: 1080,
    },
    {
      id: '3',
      type: 'image',
      title: 'Sunlit Meadow',
      filename: 'meadow.png',
      localPath: '/vault/images/meadow.png',
      folderPath: '/vault/images',
      thumbnailUrl: '',
      mediaUrl: '',
      rating: 3,
      tags: ['nature', 'daylight'],
      dateAdded: '2026-10-18T10:00:00Z',
      sizeBytes: 1500,
      format: 'PNG',
      width: 1920,
      height: 1080,
    },
  ];

  const filter: FilterState = {
    searchQuery: '',
    tagExpression: '+gothic -daylight',
    includedTags: [],
    excludedTags: [],
    orTags: [],
    selectedRatings: [4, 5],
    sortBy: 'rating',
    sortOrder: 'desc',
  };

  const results = filterAndSortMedia(sampleItems, filter);
  assert.equal(results.length, 2);
  assert.equal(results[0].id, '2'); // 5-star first
  assert.equal(results[1].id, '1'); // 4-star second
});

test('getTagSuggestions ranks prefix matches before substring matches', () => {
  const tags = ['dark-ambient', 'crimson-velvet', 'velvet-noir', 'gothic'];
  const suggestions = getTagSuggestions(tags, '+vel');
  assert.deepEqual(suggestions, ['velvet-noir', 'crimson-velvet']);
});

test('computeBookmarkProgress calculates reading progress based on actual readPages', () => {
  // Unread comic with empty readPages
  assert.deepEqual(computeBookmarkProgress(1, 10, []), {
    percent: 0,
    readCount: 0,
    isStarted: false,
    isCompleted: false,
  });

  // Jumping straight to the last page (page 10 of 10) without reading pages 1..9
  // must report 10% (1/10 pages read), NOT 100%!
  assert.deepEqual(computeBookmarkProgress(10, 10, [10]), {
    percent: 10,
    readCount: 1,
    isStarted: true,
    isCompleted: false,
  });

  // Reading 5 distinct pages out of 10
  assert.deepEqual(computeBookmarkProgress(8, 10, [1, 2, 3, 5, 8]), {
    percent: 50,
    readCount: 5,
    isStarted: true,
    isCompleted: false,
  });

  // Reading all 4 pages of a 4-page comic
  assert.deepEqual(computeBookmarkProgress(4, 4, [1, 2, 3, 4]), {
    percent: 100,
    readCount: 4,
    isStarted: true,
    isCompleted: true,
  });
});

test('groupSubfolderFilesIntoCollections creates ordered comic pages per subfolder', () => {
  const files = [
    { name: 'page_10.jpg', relativePath: 'Comics/Nocturne_Vol_1/page_10.jpg', size: 500, url: 'blob:10' },
    { name: 'page_2.jpg', relativePath: 'Comics/Nocturne_Vol_1/page_2.jpg', size: 500, url: 'blob:2' },
    { name: 'page_1.jpg', relativePath: 'Comics/Nocturne_Vol_1/page_1.jpg', size: 500, url: 'blob:1' },
  ];
  const collections = groupSubfolderFilesIntoCollections(files, 'comic', '/vault/comics');
  assert.equal(collections.length, 1);
  assert.equal(collections[0].title, 'Nocturne Vol 1');
  assert.equal(collections[0].pageCount, 3);
  assert.equal(collections[0].pages![0].filename, 'page_1.jpg');
  assert.equal(collections[0].pages![1].filename, 'page_2.jpg');
  assert.equal(collections[0].pages![2].filename, 'page_10.jpg');
});

test('parseImageDimensionsFromBuffer extracts exact width and height from PNG IHDR header', () => {
  const pngHeader = new Uint8Array([
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
    0x00, 0x00, 0x00, 0x0d, 0x49, 0x48, 0x44, 0x52,
    0x00, 0x00, 0x0a, 0x00,
    0x00, 0x00, 0x05, 0xa0,
  ]);
  const dims = parseImageDimensionsFromBuffer(pngHeader);
  assert.deepEqual(dims, { width: 2560, height: 1440 });
});
