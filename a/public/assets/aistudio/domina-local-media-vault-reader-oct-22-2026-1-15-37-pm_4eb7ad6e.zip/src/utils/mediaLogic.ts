import { FilterState, MediaItem, MediaPageItem } from '../types/media';

export interface ParsedTagQuery {
  include: string[];
  exclude: string[];
  orGroups: string[][];
}

/**
 * Parses a boolean tag query string such as:
 * "+gothic -daylight crimson OR velvet"
 * into required inclusions, exclusions, and OR groups.
 */
export function parseTagExpression(expression: string): ParsedTagQuery {
  const result: ParsedTagQuery = {
    include: [],
    exclude: [],
    orGroups: [],
  };

  const trimmed = expression.trim();
  if (!trimmed) return result;

  // Tokenize by whitespace while preserving OR keywords
  const rawTokens = trimmed.split(/\s+/).filter(Boolean);
  let i = 0;

  while (i < rawTokens.length) {
    // Check if this token starts an OR chain: token [OR nextToken]+
    if (
      i + 2 < rawTokens.length &&
      rawTokens[i + 1].toUpperCase() === 'OR'
    ) {
      const orGroup: string[] = [
        rawTokens[i].replace(/^[+-]/, '').toLowerCase(),
      ];
      while (
        i + 2 < rawTokens.length &&
        rawTokens[i + 1].toUpperCase() === 'OR'
      ) {
        orGroup.push(rawTokens[i + 2].replace(/^[+-]/, '').toLowerCase());
        i += 2;
      }
      result.orGroups.push(orGroup.filter(Boolean));
      i += 1;
      continue;
    }

    const token = rawTokens[i];
    if (token.toUpperCase() === 'OR') {
      i += 1;
      continue;
    }

    if (token.startsWith('-') && token.length > 1) {
      result.exclude.push(token.slice(1).toLowerCase());
    } else if (token.startsWith('+') && token.length > 1) {
      result.include.push(token.slice(1).toLowerCase());
    } else {
      result.include.push(token.toLowerCase());
    }
    i += 1;
  }

  return result;
}

/**
 * Checks if an item's tags satisfy both structured tag chips (Include / Exclude / OR)
 * and the freeform boolean tagExpression.
 */
export function matchesTagFilter(
  itemTags: string[],
  filter: Pick<
    FilterState,
    'tagExpression' | 'includedTags' | 'excludedTags' | 'orTags'
  > & { tagMatchMode?: 'all' | 'any' }
): boolean {
  const normalizedItemTags = new Set(itemTags.map((t) => t.toLowerCase()));
  const parsed = parseTagExpression(filter.tagExpression || '');

  // Exclude logic: None of explicit excludedTags + parsed.exclude may be present (NOT logic)
  const allExclude = [
    ...filter.excludedTags.map((t) => t.toLowerCase()),
    ...parsed.exclude,
  ];
  for (const exc of allExclude) {
    if (normalizedItemTags.has(exc)) {
      return false;
    }
  }

  // When explicit orTags are active alongside chip includedTags (e.g. user clicked +tagA then OR:tagB),
  // treat the chip tags (includedTags + orTags) as an OR group so items with EITHER tag match.
  if (filter.orTags.length > 0) {
    const unionOrTags = [
      ...filter.includedTags.map((t) => t.toLowerCase()),
      ...filter.orTags.map((t) => t.toLowerCase()),
    ];
    const matchesUnionOr = unionOrTags.some((t) => normalizedItemTags.has(t));
    if (!matchesUnionOr) return false;

    // Still enforce any explicit +tag from the freeform text expression
    if (parsed.include.length > 0) {
      if (filter.tagMatchMode === 'any') {
        if (!parsed.include.some((inc) => normalizedItemTags.has(inc))) {
          return false;
        }
      } else {
        for (const inc of parsed.include) {
          if (!normalizedItemTags.has(inc)) return false;
        }
      }
    }
  } else {
    // Standard Include logic when no explicit orTags chips are active (supports AND or OR mode)
    const allInclude = [
      ...filter.includedTags.map((t) => t.toLowerCase()),
      ...parsed.include,
    ];
    if (allInclude.length > 0) {
      if (filter.tagMatchMode === 'any') {
        const matchAny = allInclude.some((inc) => normalizedItemTags.has(inc));
        if (!matchAny) return false;
      } else {
        for (const inc of allInclude) {
          if (!normalizedItemTags.has(inc)) {
            return false;
          }
        }
      }
    }
  }

  // Every parsed OR group from the expression must have at least one matching tag
  for (const group of parsed.orGroups) {
    if (group.length > 0) {
      const groupMatch = group.some((t) => normalizedItemTags.has(t));
      if (!groupMatch) return false;
    }
  }

  return true;
}

/**
 * Supports multi-rating concurrent filtering (e.g. [4, 5] displays both 4-star and 5-star items).
 * Empty array means no rating filter is active (all items match).
 */
export function matchesRatingFilter(
  itemRating: number,
  selectedRatings: number[]
): boolean {
  if (!selectedRatings || selectedRatings.length === 0) return true;
  return selectedRatings.includes(itemRating);
}

/**
 * Fuzzy search across title, filename, artist, series, notes, and tags.
 */
export function matchesSearchQuery(item: MediaItem, query: string): boolean {
  const q = query.trim().toLowerCase();
  if (!q) return true;

  const haystack = [
    item.title,
    item.filename,
    item.localPath,
    item.artist || '',
    item.series || '',
    item.notes || '',
    ...item.tags,
  ]
    .join(' ')
    .toLowerCase();

  // Check if all space-separated search terms appear in haystack
  const terms = q.split(/\s+/).filter(Boolean);
  return terms.every((term) => haystack.includes(term));
}

/**
 * Computes reading progress percentage and status for Comics based on actual pages read.
 * If the user jumps straight to the last page without reading other pages,
 * only the actually visited pages in `readPages` count toward completion percentage.
 */
export function computeBookmarkProgress(
  lastReadPage?: number,
  pageCount?: number,
  readPages?: number[]
): {
  percent: number;
  readCount: number;
  isStarted: boolean;
  isCompleted: boolean;
} {
  if (!pageCount || pageCount <= 0) {
    return { percent: 0, readCount: 0, isStarted: false, isCompleted: false };
  }

  // When readPages array is provided, count unique valid pages actually read
  if (Array.isArray(readPages)) {
    const validSet = new Set<number>();
    for (const p of readPages) {
      if (Number.isInteger(p) && p >= 1 && p <= pageCount) {
        validSet.add(p);
      }
    }
    const readCount = validSet.size;
    if (readCount === 0) {
      return { percent: 0, readCount: 0, isStarted: false, isCompleted: false };
    }
    const percent = Math.min(100, Math.round((readCount / pageCount) * 100));
    return {
      percent,
      readCount,
      isStarted: readCount > 0,
      isCompleted: readCount >= pageCount,
    };
  }

  // Fallback when readPages is not provided
  if (!lastReadPage || lastReadPage <= 1) {
    return { percent: 0, readCount: 0, isStarted: false, isCompleted: false };
  }
  const clamped = Math.min(pageCount, Math.max(1, lastReadPage));
  const percent = Math.round((clamped / pageCount) * 100);
  return {
    percent,
    readCount: clamped,
    isStarted: clamped > 1,
    isCompleted: clamped >= pageCount,
  };
}

/**
 * Filters and sorts a list of MediaItems according to FilterState (including Advanced Search criteria).
 */
export function filterAndSortMedia(
  items: MediaItem[],
  filter: FilterState
): MediaItem[] {
  const filtered = items.filter((item) => {
    if (
      filter.selectedTypes &&
      filter.selectedTypes.length > 0 &&
      !filter.selectedTypes.includes(item.type)
    ) {
      return false;
    }
    if (filter.favoritesOnly && !item.isFavorite) {
      return false;
    }
    if (!matchesSearchQuery(item, filter.searchQuery)) return false;
    if (!matchesRatingFilter(item.rating, filter.selectedRatings)) return false;
    if (!matchesTagFilter(item.tags, filter)) return false;

    // Orientation filter
    if (filter.orientation && filter.orientation !== 'all') {
      const ratio = item.width / Math.max(1, item.height);
      if (filter.orientation === 'portrait' && ratio >= 0.95) return false;
      if (filter.orientation === 'landscape' && ratio <= 1.05) return false;
      if (filter.orientation === 'square' && (ratio < 0.95 || ratio > 1.05))
        return false;
    }

    // Resolution filter
    if (filter.minResolution && filter.minResolution !== 'all') {
      const minDim = Math.min(item.width || 0, item.height || 0);
      const maxDim = Math.max(item.width || 0, item.height || 0);
      if (filter.minResolution === 'hd' && maxDim < 1280 && minDim < 720)
        return false;
      if (filter.minResolution === 'fhd' && maxDim < 1920 && minDim < 1080)
        return false;
      if (filter.minResolution === 'qhd' && maxDim < 2560 && minDim < 1440)
        return false;
      if (filter.minResolution === 'uhd' && maxDim < 3840 && minDim < 2160)
        return false;
    }

    // File Size range filter (MB)
    const sizeMB = item.sizeBytes / (1024 * 1024);
    if (
      filter.minSizeMB !== undefined &&
      filter.minSizeMB > 0 &&
      sizeMB < filter.minSizeMB
    ) {
      return false;
    }
    if (
      filter.maxSizeMB !== undefined &&
      filter.maxSizeMB > 0 &&
      sizeMB > filter.maxSizeMB
    ) {
      return false;
    }

    // Video Duration filter
    if (filter.durationRange && filter.durationRange !== 'all') {
      if (item.type !== 'video') return false;
      const secs = item.durationSeconds || 0;
      if (filter.durationRange === 'short' && secs >= 60) return false;
      if (filter.durationRange === 'medium' && (secs < 60 || secs > 600))
        return false;
      if (filter.durationRange === 'long' && secs <= 600) return false;
    }

    // Comic Reading Progress filter
    if (filter.comicProgress && filter.comicProgress !== 'all') {
      if (item.type !== 'comic') return false;
      const prog = computeBookmarkProgress(
        item.lastReadPage,
        item.pageCount,
        item.readPages
      );
      if (filter.comicProgress === 'unread' && prog.isStarted) return false;
      if (
        filter.comicProgress === 'reading' &&
        (!prog.isStarted || prog.isCompleted)
      )
        return false;
      if (filter.comicProgress === 'completed' && !prog.isCompleted)
        return false;
    }

    return true;
  });

  const dir = filter.sortOrder === 'asc' ? 1 : -1;

  return [...filtered].sort((a, b) => {
    switch (filter.sortBy) {
      case 'title':
        return (
          a.title.localeCompare(b.title, undefined, { numeric: true }) * dir
        );
      case 'rating':
        if (a.rating !== b.rating) {
          return (a.rating - b.rating) * dir;
        }
        return a.title.localeCompare(b.title) * dir;
      case 'size':
        return (a.sizeBytes - b.sizeBytes) * dir;
      case 'resolution':
        return (a.width * a.height - b.width * b.height) * dir;
      case 'pageCount':
        return (
          ((a.pageCount || a.durationSeconds || 1) -
            (b.pageCount || b.durationSeconds || 1)) *
          dir
        );
      case 'dateAdded':
      default:
        return (
          (new Date(a.dateAdded).getTime() - new Date(b.dateAdded).getTime()) *
          dir
        );
    }
  });
}

/**
 * Returns ranked tag auto-complete suggestions based on current token input.
 */
export function getTagSuggestions(
  allAvailableTags: string[],
  rawInput: string,
  excludeAlreadyChosen: string[] = []
): string[] {
  const excludedSet = new Set(excludeAlreadyChosen.map((t) => t.toLowerCase()));
  const tokens = rawInput.split(/\s+/);
  const lastToken = (tokens[tokens.length - 1] || '')
    .replace(/^[+-]/, '')
    .toLowerCase();

  if (!lastToken || lastToken === 'or') {
    return allAvailableTags
      .filter((t) => !excludedSet.has(t.toLowerCase()))
      .slice(0, 12);
  }

  const startsWith: string[] = [];
  const contains: string[] = [];

  for (const tag of allAvailableTags) {
    const lower = tag.toLowerCase();
    if (excludedSet.has(lower)) continue;
    if (lower.startsWith(lastToken)) {
      startsWith.push(tag);
    } else if (lower.includes(lastToken)) {
      contains.push(tag);
    }
  }

  return [...startsWith, ...contains].slice(0, 12);
}

/**
 * Formats duration in seconds to MM:SS or HH:MM:SS.
 */
export function formatDuration(seconds?: number): string {
  if (!seconds || seconds <= 0) return '00:00';
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);

  const mm = String(mins).padStart(2, '0');
  const ss = String(secs).padStart(2, '0');
  if (hrs > 0) {
    return `${hrs}:${mm}:${ss}`;
  }
  return `${mm}:${ss}`;
}

/**
 * Formats file size in bytes to human-readable string (KB, MB, GB).
 */
export function formatFileSize(bytes?: number): string {
  const safeBytes = Number.isFinite(bytes) && (bytes as number) >= 0 ? (bytes as number) : 0;
  if (safeBytes < 1024) return `${safeBytes} B`;
  const kb = safeBytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  const mb = kb / 1024;
  if (mb < 1024) return `${mb.toFixed(1)} MB`;
  const gb = mb / 1024;
  return `${gb.toFixed(2)} GB`;
}

/**
 * Groups local subfolder files into Comics or Image Sets:
 * Each subfolder inside the selected directory represents a comic or image set.
 * The folder name acts as the Comic/Set title, and its contents are the ordered image pages.
 */
export function groupSubfolderFilesIntoCollections(
  files: Array<{
    name: string;
    relativePath: string;
    size: number;
    url: string;
  }>,
  collectionType: 'comic' | 'imageset',
  baseRootPath: string
): MediaItem[] {
  const folderMap = new Map<
    string,
    Array<{ name: string; relativePath: string; size: number; url: string }>
  >();

  for (const file of files) {
    const parts = file.relativePath.split('/').filter(Boolean);
    const folderName =
      parts.length >= 2 ? parts[parts.length - 2] : 'Imported Collection';
    if (!folderMap.has(folderName)) {
      folderMap.set(folderName, []);
    }
    folderMap.get(folderName)!.push(file);
  }

  const collections: MediaItem[] = [];
  let index = 0;

  for (const [folderName, folderFiles] of folderMap.entries()) {
    const sorted = [...folderFiles].sort((a, b) =>
      a.name.localeCompare(b.name, undefined, {
        numeric: true,
        sensitivity: 'base',
      })
    );

    if (sorted.length === 0) continue;

    const pages: MediaPageItem[] = sorted.map((f, idx) => {
      const ext = (f.name.split('.').pop() || 'JPG').toUpperCase();
      return {
        id: `local-${collectionType}-${index}-page-${idx + 1}`,
        pageNumber: idx + 1,
        title: `Page ${String(idx + 1).padStart(2, '0')}`,
        filename: f.name,
        localPath: `${baseRootPath}/${folderName}/${f.name}`,
        url: f.url,
        width: 1600,
        height: 2400,
        sizeBytes: f.size || 2450000,
        format: ext,
      };
    });

    const totalBytes = pages.reduce((acc, p) => acc + p.sizeBytes, 0);
    const firstPage = pages[0];

    collections.push({
      id: `local-${collectionType}-${Date.now()}-${index}`,
      type: collectionType,
      title: folderName.replace(/[-_]/g, ' '),
      filename: folderName,
      localPath: `${baseRootPath}/${folderName}`,
      folderPath: baseRootPath,
      thumbnailUrl: firstPage.url,
      mediaUrl: firstPage.url,
      rating: 0,
      tags: ['imported', collectionType === 'comic' ? 'comic' : 'photoset'],
      dateAdded: new Date().toISOString(),
      sizeBytes: totalBytes,
      format: 'FOLDER',
      width: firstPage.width,
      height: firstPage.height,
      pages,
      pageCount: pages.length,
      lastReadPage: 1,
      readPages: [],
    });

    index += 1;
  }

  return collections;
}
